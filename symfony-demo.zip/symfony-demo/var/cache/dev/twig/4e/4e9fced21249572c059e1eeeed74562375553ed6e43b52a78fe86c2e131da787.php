<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_4cb8ce75087b78bc796804f6018f750e2ecebfb5d1a92b2ce1821a42d2c5eb05 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2fafb1ab5c7fbbca2fc458fbe1f6d72201f1721b6f000ae2a30fb4ab42b9fae7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2fafb1ab5c7fbbca2fc458fbe1f6d72201f1721b6f000ae2a30fb4ab42b9fae7->enter($__internal_2fafb1ab5c7fbbca2fc458fbe1f6d72201f1721b6f000ae2a30fb4ab42b9fae7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        $__internal_1b263874b393c02608a640af93769d7b2f21d2a228c616411ea5d07ac8288edc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1b263874b393c02608a640af93769d7b2f21d2a228c616411ea5d07ac8288edc->enter($__internal_1b263874b393c02608a640af93769d7b2f21d2a228c616411ea5d07ac8288edc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_2fafb1ab5c7fbbca2fc458fbe1f6d72201f1721b6f000ae2a30fb4ab42b9fae7->leave($__internal_2fafb1ab5c7fbbca2fc458fbe1f6d72201f1721b6f000ae2a30fb4ab42b9fae7_prof);

        
        $__internal_1b263874b393c02608a640af93769d7b2f21d2a228c616411ea5d07ac8288edc->leave($__internal_1b263874b393c02608a640af93769d7b2f21d2a228c616411ea5d07ac8288edc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'text')) ?> %
", "@Framework/Form/percent_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\percent_widget.html.php");
    }
}
