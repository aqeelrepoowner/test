<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_095f3f19cbb59c74a009b08a5ed94caf0cc8a866e915d2c3f902f7451fe2dfd5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ecbd699864b3e3d0a110682169ff74397a87e50ce7aaf55285fc8ed056641781 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ecbd699864b3e3d0a110682169ff74397a87e50ce7aaf55285fc8ed056641781->enter($__internal_ecbd699864b3e3d0a110682169ff74397a87e50ce7aaf55285fc8ed056641781_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        $__internal_c60a94023104af41c6d22de9c2078bae72140cc880ecf97877affbbe15248b7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c60a94023104af41c6d22de9c2078bae72140cc880ecf97877affbbe15248b7a->enter($__internal_c60a94023104af41c6d22de9c2078bae72140cc880ecf97877affbbe15248b7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_ecbd699864b3e3d0a110682169ff74397a87e50ce7aaf55285fc8ed056641781->leave($__internal_ecbd699864b3e3d0a110682169ff74397a87e50ce7aaf55285fc8ed056641781_prof);

        
        $__internal_c60a94023104af41c6d22de9c2078bae72140cc880ecf97877affbbe15248b7a->leave($__internal_c60a94023104af41c6d22de9c2078bae72140cc880ecf97877affbbe15248b7a_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_1c470bbfb561628f78875e5f0a35df622e2217e11ee31130bc74bd0cc6d75820 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1c470bbfb561628f78875e5f0a35df622e2217e11ee31130bc74bd0cc6d75820->enter($__internal_1c470bbfb561628f78875e5f0a35df622e2217e11ee31130bc74bd0cc6d75820_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_52bc8adbfcff7c50eddabeff5e94e04c1b22f3316a70cd0d4af5b994da833e98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_52bc8adbfcff7c50eddabeff5e94e04c1b22f3316a70cd0d4af5b994da833e98->enter($__internal_52bc8adbfcff7c50eddabeff5e94e04c1b22f3316a70cd0d4af5b994da833e98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_52bc8adbfcff7c50eddabeff5e94e04c1b22f3316a70cd0d4af5b994da833e98->leave($__internal_52bc8adbfcff7c50eddabeff5e94e04c1b22f3316a70cd0d4af5b994da833e98_prof);

        
        $__internal_1c470bbfb561628f78875e5f0a35df622e2217e11ee31130bc74bd0cc6d75820->leave($__internal_1c470bbfb561628f78875e5f0a35df622e2217e11ee31130bc74bd0cc6d75820_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "WebProfilerBundle:Profiler:ajax_layout.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/ajax_layout.html.twig");
    }
}
