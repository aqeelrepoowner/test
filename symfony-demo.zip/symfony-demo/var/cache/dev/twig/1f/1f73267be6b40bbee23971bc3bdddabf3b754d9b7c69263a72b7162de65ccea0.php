<?php

/* @Framework/Form/form_widget.html.php */
class __TwigTemplate_869a1218447ae2e3dc8f899a55a7d6a529e1fa86a18f0f3c2e56927d8c2ece80 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cfb54c5d8d48c2d5fe15f5cf8847990257e1a37d985db2687645d9a92978a828 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cfb54c5d8d48c2d5fe15f5cf8847990257e1a37d985db2687645d9a92978a828->enter($__internal_cfb54c5d8d48c2d5fe15f5cf8847990257e1a37d985db2687645d9a92978a828_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        $__internal_1a7eedc704c1e8100b7528efa150723c2d2392ef3d9212e36c74527576cd90e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1a7eedc704c1e8100b7528efa150723c2d2392ef3d9212e36c74527576cd90e3->enter($__internal_1a7eedc704c1e8100b7528efa150723c2d2392ef3d9212e36c74527576cd90e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget.html.php"));

        // line 1
        echo "<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
";
        
        $__internal_cfb54c5d8d48c2d5fe15f5cf8847990257e1a37d985db2687645d9a92978a828->leave($__internal_cfb54c5d8d48c2d5fe15f5cf8847990257e1a37d985db2687645d9a92978a828_prof);

        
        $__internal_1a7eedc704c1e8100b7528efa150723c2d2392ef3d9212e36c74527576cd90e3->leave($__internal_1a7eedc704c1e8100b7528efa150723c2d2392ef3d9212e36c74527576cd90e3_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$compound): ?>
<?php echo \$view['form']->block(\$form, 'form_widget_compound')?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'form_widget_simple')?>
<?php endif ?>
", "@Framework/Form/form_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget.html.php");
    }
}
