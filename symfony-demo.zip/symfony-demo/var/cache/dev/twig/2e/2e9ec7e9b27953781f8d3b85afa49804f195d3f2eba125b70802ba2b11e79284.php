<?php

/* :form:fields.html.twig */
class __TwigTemplate_47455449d02748a1e3c65d6099569ac5b94bf48b1c55a348005214568fb01fa0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5b57bccee2386db6043e1b32369dec7ac18217335963fb25eb58f8c441c88521 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5b57bccee2386db6043e1b32369dec7ac18217335963fb25eb58f8c441c88521->enter($__internal_5b57bccee2386db6043e1b32369dec7ac18217335963fb25eb58f8c441c88521_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":form:fields.html.twig"));

        $__internal_ee2a96b88f4886a29939410c4fb477e3c1aef28ad5cb34537f402c44c4b46f11 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee2a96b88f4886a29939410c4fb477e3c1aef28ad5cb34537f402c44c4b46f11->enter($__internal_ee2a96b88f4886a29939410c4fb477e3c1aef28ad5cb34537f402c44c4b46f11_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":form:fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        
        $__internal_5b57bccee2386db6043e1b32369dec7ac18217335963fb25eb58f8c441c88521->leave($__internal_5b57bccee2386db6043e1b32369dec7ac18217335963fb25eb58f8c441c88521_prof);

        
        $__internal_ee2a96b88f4886a29939410c4fb477e3c1aef28ad5cb34537f402c44c4b46f11->leave($__internal_ee2a96b88f4886a29939410c4fb477e3c1aef28ad5cb34537f402c44c4b46f11_prof);

    }

    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_59c4408008128a48e2493463ac0c5f5178ed19e4d50716d939801b2b03967042 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59c4408008128a48e2493463ac0c5f5178ed19e4d50716d939801b2b03967042->enter($__internal_59c4408008128a48e2493463ac0c5f5178ed19e4d50716d939801b2b03967042_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        $__internal_23bc1e40f1628f32745a081f2539080466b51b742ad1d677ceb7d09f55ee1238 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23bc1e40f1628f32745a081f2539080466b51b742ad1d677ceb7d09f55ee1238->enter($__internal_23bc1e40f1628f32745a081f2539080466b51b742ad1d677ceb7d09f55ee1238_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        ";
        // line 12
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
";
        
        $__internal_23bc1e40f1628f32745a081f2539080466b51b742ad1d677ceb7d09f55ee1238->leave($__internal_23bc1e40f1628f32745a081f2539080466b51b742ad1d677ceb7d09f55ee1238_prof);

        
        $__internal_59c4408008128a48e2493463ac0c5f5178ed19e4d50716d939801b2b03967042->leave($__internal_59c4408008128a48e2493463ac0c5f5178ed19e4d50716d939801b2b03967042_prof);

    }

    public function getTemplateName()
    {
        return ":form:fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  50 => 12,  47 => 11,  29 => 10,  26 => 9,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        {{ block('datetime_widget') }}
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
{% endblock %}
", ":form:fields.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/form/fields.html.twig");
    }
}
