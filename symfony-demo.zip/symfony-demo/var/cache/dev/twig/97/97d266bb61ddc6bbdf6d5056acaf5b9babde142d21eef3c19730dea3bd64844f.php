<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_bc2815cad45098bc579d5b1cc2a9b6b6dacf71742d46aa6c49d67be86b71515f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f041103d16ca9f805bec74749c1d837ff5d53bfa7ecbe563f5bb2344f06e744b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f041103d16ca9f805bec74749c1d837ff5d53bfa7ecbe563f5bb2344f06e744b->enter($__internal_f041103d16ca9f805bec74749c1d837ff5d53bfa7ecbe563f5bb2344f06e744b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        $__internal_0dea75ca69f015d43ab0502756968d309654825cc0c9c8456246be7b37020e6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0dea75ca69f015d43ab0502756968d309654825cc0c9c8456246be7b37020e6c->enter($__internal_0dea75ca69f015d43ab0502756968d309654825cc0c9c8456246be7b37020e6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_f041103d16ca9f805bec74749c1d837ff5d53bfa7ecbe563f5bb2344f06e744b->leave($__internal_f041103d16ca9f805bec74749c1d837ff5d53bfa7ecbe563f5bb2344f06e744b_prof);

        
        $__internal_0dea75ca69f015d43ab0502756968d309654825cc0c9c8456246be7b37020e6c->leave($__internal_0dea75ca69f015d43ab0502756968d309654825cc0c9c8456246be7b37020e6c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
", "@Framework/Form/form_row.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_row.html.php");
    }
}
