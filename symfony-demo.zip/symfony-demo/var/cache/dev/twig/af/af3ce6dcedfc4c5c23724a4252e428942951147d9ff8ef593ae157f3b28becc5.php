<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_f444fbd372eff8586cd4a1c12467382e8e339ab9e2166cf45aafa00acb4d29e3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_49f1d7184e48752a62b580035146fe746e0bbcf5968aaf9934bb5f9922d210fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_49f1d7184e48752a62b580035146fe746e0bbcf5968aaf9934bb5f9922d210fe->enter($__internal_49f1d7184e48752a62b580035146fe746e0bbcf5968aaf9934bb5f9922d210fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        $__internal_c5780dbcea4350ccb42426b287633b93ad011b64e525b1631aa15c951794a1bd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c5780dbcea4350ccb42426b287633b93ad011b64e525b1631aa15c951794a1bd->enter($__internal_c5780dbcea4350ccb42426b287633b93ad011b64e525b1631aa15c951794a1bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_49f1d7184e48752a62b580035146fe746e0bbcf5968aaf9934bb5f9922d210fe->leave($__internal_49f1d7184e48752a62b580035146fe746e0bbcf5968aaf9934bb5f9922d210fe_prof);

        
        $__internal_c5780dbcea4350ccb42426b287633b93ad011b64e525b1631aa15c951794a1bd->leave($__internal_c5780dbcea4350ccb42426b287633b93ad011b64e525b1631aa15c951794a1bd_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "TwigBundle:Exception:error.txt.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.txt.twig");
    }
}
