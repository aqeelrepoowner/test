<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_dea5c27d498b4554c8d2c277b081ae57a4f2e591ede7236641c0bf96a861a22e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_69e26d338f2164d0f0267e4e2c51d2136d583ba506d12cc620bb776159d65d16 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_69e26d338f2164d0f0267e4e2c51d2136d583ba506d12cc620bb776159d65d16->enter($__internal_69e26d338f2164d0f0267e4e2c51d2136d583ba506d12cc620bb776159d65d16_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        $__internal_50d9046ca38d2521d50f68a0cae98c20a748f8dacf8733eb3141b95acee0ab71 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50d9046ca38d2521d50f68a0cae98c20a748f8dacf8733eb3141b95acee0ab71->enter($__internal_50d9046ca38d2521d50f68a0cae98c20a748f8dacf8733eb3141b95acee0ab71_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_69e26d338f2164d0f0267e4e2c51d2136d583ba506d12cc620bb776159d65d16->leave($__internal_69e26d338f2164d0f0267e4e2c51d2136d583ba506d12cc620bb776159d65d16_prof);

        
        $__internal_50d9046ca38d2521d50f68a0cae98c20a748f8dacf8733eb3141b95acee0ab71->leave($__internal_50d9046ca38d2521d50f68a0cae98c20a748f8dacf8733eb3141b95acee0ab71_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
", "@Framework/Form/form_widget_compound.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_widget_compound.html.php");
    }
}
