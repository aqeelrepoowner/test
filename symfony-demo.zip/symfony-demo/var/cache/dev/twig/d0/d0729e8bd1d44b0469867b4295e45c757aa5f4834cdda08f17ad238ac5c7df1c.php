<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_9fc2cae0f66182a6922fd3b647b7644759df7a50c0cd9105027573dcded76e0a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_022304ab47adfa6d0c8ed8e250ccb1c61e0242a7687a211bb2613e793e94503d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_022304ab47adfa6d0c8ed8e250ccb1c61e0242a7687a211bb2613e793e94503d->enter($__internal_022304ab47adfa6d0c8ed8e250ccb1c61e0242a7687a211bb2613e793e94503d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        $__internal_941cd00b380e443fb15056c187e05666098ff5c5196c31731e10486f2af34bf9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_941cd00b380e443fb15056c187e05666098ff5c5196c31731e10486f2af34bf9->enter($__internal_941cd00b380e443fb15056c187e05666098ff5c5196c31731e10486f2af34bf9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_022304ab47adfa6d0c8ed8e250ccb1c61e0242a7687a211bb2613e793e94503d->leave($__internal_022304ab47adfa6d0c8ed8e250ccb1c61e0242a7687a211bb2613e793e94503d_prof);

        
        $__internal_941cd00b380e443fb15056c187e05666098ff5c5196c31731e10486f2af34bf9->leave($__internal_941cd00b380e443fb15056c187e05666098ff5c5196c31731e10486f2af34bf9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
", "@Framework/Form/choice_widget_expanded.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_widget_expanded.html.php");
    }
}
