<?php

/* admin/blog/new.html.twig */
class __TwigTemplate_09641cdb70bf4ee780bf515cfbd6ddf6f605afdd1ccd02c057d53b64a059b458 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/blog/new.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2f868ec86adaf2dd7698d9992ccf6c9fb646e3fc4d866a0724b46da95d208e46 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2f868ec86adaf2dd7698d9992ccf6c9fb646e3fc4d866a0724b46da95d208e46->enter($__internal_2f868ec86adaf2dd7698d9992ccf6c9fb646e3fc4d866a0724b46da95d208e46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/new.html.twig"));

        $__internal_48e1a92499ba11e51e9703e0876ca0f2aa373f7a56289f0f797506283b254c22 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48e1a92499ba11e51e9703e0876ca0f2aa373f7a56289f0f797506283b254c22->enter($__internal_48e1a92499ba11e51e9703e0876ca0f2aa373f7a56289f0f797506283b254c22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2f868ec86adaf2dd7698d9992ccf6c9fb646e3fc4d866a0724b46da95d208e46->leave($__internal_2f868ec86adaf2dd7698d9992ccf6c9fb646e3fc4d866a0724b46da95d208e46_prof);

        
        $__internal_48e1a92499ba11e51e9703e0876ca0f2aa373f7a56289f0f797506283b254c22->leave($__internal_48e1a92499ba11e51e9703e0876ca0f2aa373f7a56289f0f797506283b254c22_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_62af7193dfc9a23c1348deb597f4bfe13704d93f992dc53c5827763167b47553 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_62af7193dfc9a23c1348deb597f4bfe13704d93f992dc53c5827763167b47553->enter($__internal_62af7193dfc9a23c1348deb597f4bfe13704d93f992dc53c5827763167b47553_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_e74558356c74cb15f62da809f6e43c713426c5ecea92abe2a2437e9796e00c57 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e74558356c74cb15f62da809f6e43c713426c5ecea92abe2a2437e9796e00c57->enter($__internal_e74558356c74cb15f62da809f6e43c713426c5ecea92abe2a2437e9796e00c57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_new";
        
        $__internal_e74558356c74cb15f62da809f6e43c713426c5ecea92abe2a2437e9796e00c57->leave($__internal_e74558356c74cb15f62da809f6e43c713426c5ecea92abe2a2437e9796e00c57_prof);

        
        $__internal_62af7193dfc9a23c1348deb597f4bfe13704d93f992dc53c5827763167b47553->leave($__internal_62af7193dfc9a23c1348deb597f4bfe13704d93f992dc53c5827763167b47553_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_60c3b06256fe5563faa80b60be3809e9eaee116423c2639626cef663650d9b4b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_60c3b06256fe5563faa80b60be3809e9eaee116423c2639626cef663650d9b4b->enter($__internal_60c3b06256fe5563faa80b60be3809e9eaee116423c2639626cef663650d9b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_443bbd807ce666b4410b8374fca7effc3955ba6d4f279d5e381a161a07bac391 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_443bbd807ce666b4410b8374fca7effc3955ba6d4f279d5e381a161a07bac391->enter($__internal_443bbd807ce666b4410b8374fca7effc3955ba6d4f279d5e381a161a07bac391_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.post_new"), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "title", array()), 'row');
        echo "
        ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "summary", array()), 'row');
        echo "
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "content", array()), 'row');
        echo "
        ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "publishedAt", array()), 'row');
        echo "

        <input type=\"submit\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.create_post"), "html", null, true);
        echo "\" class=\"btn btn-primary\" />
        ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveAndCreateNew", array()), 'widget', array("label" => "label.save_and_create_new", "attr" => array("class" => "btn btn-primary")));
        echo "
        <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\" class=\"btn btn-link\">
            ";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.back_to_list"), "html", null, true);
        echo "
        </a>
    ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_443bbd807ce666b4410b8374fca7effc3955ba6d4f279d5e381a161a07bac391->leave($__internal_443bbd807ce666b4410b8374fca7effc3955ba6d4f279d5e381a161a07bac391_prof);

        
        $__internal_60c3b06256fe5563faa80b60be3809e9eaee116423c2639626cef663650d9b4b->leave($__internal_60c3b06256fe5563faa80b60be3809e9eaee116423c2639626cef663650d9b4b_prof);

    }

    // line 22
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_cb81553c64e10d74d1e413cd1ba47f69530e2a56571ea688b0dc57b9a26c53ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb81553c64e10d74d1e413cd1ba47f69530e2a56571ea688b0dc57b9a26c53ba->enter($__internal_cb81553c64e10d74d1e413cd1ba47f69530e2a56571ea688b0dc57b9a26c53ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_d5231b0d3ff772908a7bc4e365984afb38abe7e24609c367bdf061cc16a99e9c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d5231b0d3ff772908a7bc4e365984afb38abe7e24609c367bdf061cc16a99e9c->enter($__internal_d5231b0d3ff772908a7bc4e365984afb38abe7e24609c367bdf061cc16a99e9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 23
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 25
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_d5231b0d3ff772908a7bc4e365984afb38abe7e24609c367bdf061cc16a99e9c->leave($__internal_d5231b0d3ff772908a7bc4e365984afb38abe7e24609c367bdf061cc16a99e9c_prof);

        
        $__internal_cb81553c64e10d74d1e413cd1ba47f69530e2a56571ea688b0dc57b9a26c53ba->leave($__internal_cb81553c64e10d74d1e413cd1ba47f69530e2a56571ea688b0dc57b9a26c53ba_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 25,  134 => 23,  125 => 22,  113 => 19,  108 => 17,  104 => 16,  100 => 15,  96 => 14,  91 => 12,  87 => 11,  83 => 10,  79 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_new' %}

{% block main %}
    <h1>{{ 'title.post_new'|trans }}</h1>

    {{ form_start(form) }}
        {{ form_row(form.title) }}
        {{ form_row(form.summary) }}
        {{ form_row(form.content) }}
        {{ form_row(form.publishedAt) }}

        <input type=\"submit\" value=\"{{ 'label.create_post'|trans }}\" class=\"btn btn-primary\" />
        {{ form_widget(form.saveAndCreateNew, { label: 'label.save_and_create_new', attr: { class: 'btn btn-primary' } }) }}
        <a href=\"{{ path('admin_post_index') }}\" class=\"btn btn-link\">
            {{ 'action.back_to_list'|trans }}
        </a>
    {{ form_end(form) }}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "admin/blog/new.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\admin\\blog\\new.html.twig");
    }
}
