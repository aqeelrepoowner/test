<?php

/* @Framework/FormTable/form_row.html.php */
class __TwigTemplate_a785840fbc29d8f56c63545d542f00258fb7ba7b795b350eba1db922c7d9dd0d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_750d0b4a351513885781ca9ce7a295f6b6af814c5a4f2f334b0ecd8ebd1429eb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_750d0b4a351513885781ca9ce7a295f6b6af814c5a4f2f334b0ecd8ebd1429eb->enter($__internal_750d0b4a351513885781ca9ce7a295f6b6af814c5a4f2f334b0ecd8ebd1429eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        $__internal_1576569bf4a47444b186790c0751e1783b49af88bc51ae40752fd5e3face3c4b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1576569bf4a47444b186790c0751e1783b49af88bc51ae40752fd5e3face3c4b->enter($__internal_1576569bf4a47444b186790c0751e1783b49af88bc51ae40752fd5e3face3c4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_row.html.php"));

        // line 1
        echo "<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_750d0b4a351513885781ca9ce7a295f6b6af814c5a4f2f334b0ecd8ebd1429eb->leave($__internal_750d0b4a351513885781ca9ce7a295f6b6af814c5a4f2f334b0ecd8ebd1429eb_prof);

        
        $__internal_1576569bf4a47444b186790c0751e1783b49af88bc51ae40752fd5e3face3c4b->leave($__internal_1576569bf4a47444b186790c0751e1783b49af88bc51ae40752fd5e3face3c4b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td>
        <?php echo \$view['form']->label(\$form) ?>
    </td>
    <td>
        <?php echo \$view['form']->errors(\$form) ?>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/form_row.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_row.html.php");
    }
}
