<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_31b01bef267f5433d21b5f41ae3a7e34adac56e0169454beb46880568b94a894 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_42fdc12d3292a89998ae34a95b675693fb78b711f288025161fd97b59c9c4e83 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_42fdc12d3292a89998ae34a95b675693fb78b711f288025161fd97b59c9c4e83->enter($__internal_42fdc12d3292a89998ae34a95b675693fb78b711f288025161fd97b59c9c4e83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        $__internal_01d89b6ae6f163bb1283059944a6b7c6887665c9913ec3df01f0d691d92c8b60 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_01d89b6ae6f163bb1283059944a6b7c6887665c9913ec3df01f0d691d92c8b60->enter($__internal_01d89b6ae6f163bb1283059944a6b7c6887665c9913ec3df01f0d691d92c8b60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_42fdc12d3292a89998ae34a95b675693fb78b711f288025161fd97b59c9c4e83->leave($__internal_42fdc12d3292a89998ae34a95b675693fb78b711f288025161fd97b59c9c4e83_prof);

        
        $__internal_01d89b6ae6f163bb1283059944a6b7c6887665c9913ec3df01f0d691d92c8b60->leave($__internal_01d89b6ae6f163bb1283059944a6b7c6887665c9913ec3df01f0d691d92c8b60_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'search')) ?>
", "@Framework/Form/search_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\search_widget.html.php");
    }
}
