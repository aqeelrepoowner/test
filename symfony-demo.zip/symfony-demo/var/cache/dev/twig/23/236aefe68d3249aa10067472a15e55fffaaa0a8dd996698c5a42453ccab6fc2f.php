<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_d1d0133e82325d3c548575d0e097c96151efc81bd3b8dada72bf47eac9217bf9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a2a82d47dac969d20fb9bb33139a9a4fa5546969843969db8ac47dff142ebe41 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2a82d47dac969d20fb9bb33139a9a4fa5546969843969db8ac47dff142ebe41->enter($__internal_a2a82d47dac969d20fb9bb33139a9a4fa5546969843969db8ac47dff142ebe41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        $__internal_0cfd94a59fdb87f3dc2a94349eb7845398192413ffe4dedd61e51d64dfb7c796 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0cfd94a59fdb87f3dc2a94349eb7845398192413ffe4dedd61e51d64dfb7c796->enter($__internal_0cfd94a59fdb87f3dc2a94349eb7845398192413ffe4dedd61e51d64dfb7c796_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_a2a82d47dac969d20fb9bb33139a9a4fa5546969843969db8ac47dff142ebe41->leave($__internal_a2a82d47dac969d20fb9bb33139a9a4fa5546969843969db8ac47dff142ebe41_prof);

        
        $__internal_0cfd94a59fdb87f3dc2a94349eb7845398192413ffe4dedd61e51d64dfb7c796->leave($__internal_0cfd94a59fdb87f3dc2a94349eb7845398192413ffe4dedd61e51d64dfb7c796_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
", "@Framework/Form/form.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form.html.php");
    }
}
