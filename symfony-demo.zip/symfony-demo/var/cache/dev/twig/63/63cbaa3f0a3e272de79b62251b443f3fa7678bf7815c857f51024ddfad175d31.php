<?php

/* :admin/students:new.html.twig */
class __TwigTemplate_0bc751f062369d645c5f528f30998ce6c48fe7f74063955a19eb850b40af5d22 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", ":admin/students:new.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6e99609e7b6ca5a0b5921a1fba81df98fa249277820d3775973d0f014d18eca2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e99609e7b6ca5a0b5921a1fba81df98fa249277820d3775973d0f014d18eca2->enter($__internal_6e99609e7b6ca5a0b5921a1fba81df98fa249277820d3775973d0f014d18eca2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/students:new.html.twig"));

        $__internal_955c3439264bec26db962b8a4ee8c37d658da075de0012dc553d88903c536ea1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_955c3439264bec26db962b8a4ee8c37d658da075de0012dc553d88903c536ea1->enter($__internal_955c3439264bec26db962b8a4ee8c37d658da075de0012dc553d88903c536ea1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/students:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6e99609e7b6ca5a0b5921a1fba81df98fa249277820d3775973d0f014d18eca2->leave($__internal_6e99609e7b6ca5a0b5921a1fba81df98fa249277820d3775973d0f014d18eca2_prof);

        
        $__internal_955c3439264bec26db962b8a4ee8c37d658da075de0012dc553d88903c536ea1->leave($__internal_955c3439264bec26db962b8a4ee8c37d658da075de0012dc553d88903c536ea1_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_0e8c972580e5e5ca0179a55085e47b462b91bcf5478ed9c28ae0b7c1050f4a22 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e8c972580e5e5ca0179a55085e47b462b91bcf5478ed9c28ae0b7c1050f4a22->enter($__internal_0e8c972580e5e5ca0179a55085e47b462b91bcf5478ed9c28ae0b7c1050f4a22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_fc08a2388ef5837222493a2501080d61c0312536e88fe002bbf56b060e26c056 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc08a2388ef5837222493a2501080d61c0312536e88fe002bbf56b060e26c056->enter($__internal_fc08a2388ef5837222493a2501080d61c0312536e88fe002bbf56b060e26c056_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_new";
        
        $__internal_fc08a2388ef5837222493a2501080d61c0312536e88fe002bbf56b060e26c056->leave($__internal_fc08a2388ef5837222493a2501080d61c0312536e88fe002bbf56b060e26c056_prof);

        
        $__internal_0e8c972580e5e5ca0179a55085e47b462b91bcf5478ed9c28ae0b7c1050f4a22->leave($__internal_0e8c972580e5e5ca0179a55085e47b462b91bcf5478ed9c28ae0b7c1050f4a22_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_63cdb72082745a0bb6b332d844d43c6124800d7ff06e62401ab6366cacbe39ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63cdb72082745a0bb6b332d844d43c6124800d7ff06e62401ab6366cacbe39ef->enter($__internal_63cdb72082745a0bb6b332d844d43c6124800d7ff06e62401ab6366cacbe39ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_fc4c00106e2c76bbf190dc8c12e1551c096f8b8e8ad5790d80de74f84c196d43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc4c00106e2c76bbf190dc8c12e1551c096f8b8e8ad5790d80de74f84c196d43->enter($__internal_fc4c00106e2c76bbf190dc8c12e1551c096f8b8e8ad5790d80de74f84c196d43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.student_new"), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "first_name", array()), 'row');
        echo "
        ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "last_name", array()), 'row');
        echo "
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'row');
        echo "
        ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fatherName", array()), 'row');
        echo "
        ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dob", array()), 'row');
        echo "
        ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "gender", array()), 'row');
        echo "
        ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "registered_date", array()), 'row');
        echo "
        ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "contact_no", array()), 'row');
        echo "
        ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "maktabId", array()), 'row');
        echo "
        ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "courseId", array()), 'row');
        echo "
        ";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "teacherId", array()), 'row');
        echo "

        <input type=\"submit\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.create_student"), "html", null, true);
        echo "\" class=\"btn btn-primary\" />
        ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveAndCreateNew", array()), 'widget', array("label" => "label.save_and_create_new", "attr" => array("class" => "btn btn-primary")));
        echo "
        <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_index");
        echo "\" class=\"btn btn-link\">
            ";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.back_to_list"), "html", null, true);
        echo "
        </a>
    ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_fc4c00106e2c76bbf190dc8c12e1551c096f8b8e8ad5790d80de74f84c196d43->leave($__internal_fc4c00106e2c76bbf190dc8c12e1551c096f8b8e8ad5790d80de74f84c196d43_prof);

        
        $__internal_63cdb72082745a0bb6b332d844d43c6124800d7ff06e62401ab6366cacbe39ef->leave($__internal_63cdb72082745a0bb6b332d844d43c6124800d7ff06e62401ab6366cacbe39ef_prof);

    }

    // line 29
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_f115ec0b9448f50c2ca4e3f016829f509d5263f131bdad36b7686316cb3bde49 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f115ec0b9448f50c2ca4e3f016829f509d5263f131bdad36b7686316cb3bde49->enter($__internal_f115ec0b9448f50c2ca4e3f016829f509d5263f131bdad36b7686316cb3bde49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_86521260ab19bf2b8418ffe66a661fd609329d75774a3f78a0c9d8d5174782de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_86521260ab19bf2b8418ffe66a661fd609329d75774a3f78a0c9d8d5174782de->enter($__internal_86521260ab19bf2b8418ffe66a661fd609329d75774a3f78a0c9d8d5174782de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 30
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 32
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_86521260ab19bf2b8418ffe66a661fd609329d75774a3f78a0c9d8d5174782de->leave($__internal_86521260ab19bf2b8418ffe66a661fd609329d75774a3f78a0c9d8d5174782de_prof);

        
        $__internal_f115ec0b9448f50c2ca4e3f016829f509d5263f131bdad36b7686316cb3bde49->leave($__internal_f115ec0b9448f50c2ca4e3f016829f509d5263f131bdad36b7686316cb3bde49_prof);

    }

    public function getTemplateName()
    {
        return ":admin/students:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 32,  162 => 30,  153 => 29,  141 => 26,  136 => 24,  132 => 23,  128 => 22,  124 => 21,  119 => 19,  115 => 18,  111 => 17,  107 => 16,  103 => 15,  99 => 14,  95 => 13,  91 => 12,  87 => 11,  83 => 10,  79 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_new' %}

{% block main %}
    <h1>{{ 'title.student_new'|trans }}</h1>

    {{ form_start(form) }}
        {{ form_row(form.first_name) }}
        {{ form_row(form.last_name) }}
        {{ form_row(form.email) }}
        {{ form_row(form.fatherName) }}
        {{ form_row(form.dob) }}
        {{ form_row(form.gender) }}
        {{ form_row(form.registered_date) }}
        {{ form_row(form.contact_no) }}
        {{ form_row(form.maktabId) }}
        {{ form_row(form.courseId) }}
        {{ form_row(form.teacherId) }}

        <input type=\"submit\" value=\"{{ 'label.create_student'|trans }}\" class=\"btn btn-primary\" />
        {{ form_widget(form.saveAndCreateNew, { label: 'label.save_and_create_new', attr: { class: 'btn btn-primary' } }) }}
        <a href=\"{{ path('admin_student_index') }}\" class=\"btn btn-link\">
            {{ 'action.back_to_list'|trans }}
        </a>
    {{ form_end(form) }}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", ":admin/students:new.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/admin/students/new.html.twig");
    }
}
