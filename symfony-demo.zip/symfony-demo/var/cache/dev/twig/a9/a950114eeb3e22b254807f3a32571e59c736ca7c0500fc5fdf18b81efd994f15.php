<?php

/* @Twig/Exception/error.html.twig */
class __TwigTemplate_fe96994c635b2bf8d35329a1c4af1897368206dbbc70efdf169ea4d71311fc39 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "@Twig/Exception/error.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_05656b8279566b68de0865713ada8e7f4d651f7fee648a549fa84e64cd905eb8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_05656b8279566b68de0865713ada8e7f4d651f7fee648a549fa84e64cd905eb8->enter($__internal_05656b8279566b68de0865713ada8e7f4d651f7fee648a549fa84e64cd905eb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.html.twig"));

        $__internal_ac22acb2b336526dcf2c1850e578ebac7b1c25eccd12854b032f2e824fa36c6f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac22acb2b336526dcf2c1850e578ebac7b1c25eccd12854b032f2e824fa36c6f->enter($__internal_ac22acb2b336526dcf2c1850e578ebac7b1c25eccd12854b032f2e824fa36c6f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_05656b8279566b68de0865713ada8e7f4d651f7fee648a549fa84e64cd905eb8->leave($__internal_05656b8279566b68de0865713ada8e7f4d651f7fee648a549fa84e64cd905eb8_prof);

        
        $__internal_ac22acb2b336526dcf2c1850e578ebac7b1c25eccd12854b032f2e824fa36c6f->leave($__internal_ac22acb2b336526dcf2c1850e578ebac7b1c25eccd12854b032f2e824fa36c6f_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_9071d4f817ec6c45a2fb15d29ab8952ab1acdf2fdf58d3820267eee5410fca44 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9071d4f817ec6c45a2fb15d29ab8952ab1acdf2fdf58d3820267eee5410fca44->enter($__internal_9071d4f817ec6c45a2fb15d29ab8952ab1acdf2fdf58d3820267eee5410fca44_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_67b007f3bb6dd1bd71a5ca766e4cdd257076a18396482e11935956ff848e43eb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_67b007f3bb6dd1bd71a5ca766e4cdd257076a18396482e11935956ff848e43eb->enter($__internal_67b007f3bb6dd1bd71a5ca766e4cdd257076a18396482e11935956ff848e43eb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_67b007f3bb6dd1bd71a5ca766e4cdd257076a18396482e11935956ff848e43eb->leave($__internal_67b007f3bb6dd1bd71a5ca766e4cdd257076a18396482e11935956ff848e43eb_prof);

        
        $__internal_9071d4f817ec6c45a2fb15d29ab8952ab1acdf2fdf58d3820267eee5410fca44->leave($__internal_9071d4f817ec6c45a2fb15d29ab8952ab1acdf2fdf58d3820267eee5410fca44_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_f50a721986d7c6cb5591abd1c4c701a17b204061e6d800a873203156848cb8a9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f50a721986d7c6cb5591abd1c4c701a17b204061e6d800a873203156848cb8a9->enter($__internal_f50a721986d7c6cb5591abd1c4c701a17b204061e6d800a873203156848cb8a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_fea8b22640212265cf3e0d7ef4b97d767bb26634a062e7a085a9359d8e98de81 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fea8b22640212265cf3e0d7ef4b97d767bb26634a062e7a085a9359d8e98de81->enter($__internal_fea8b22640212265cf3e0d7ef4b97d767bb26634a062e7a085a9359d8e98de81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")))), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.description", array("%status_code%" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")))), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.suggestion", array("%url%" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index")));
        echo "
    </p>
";
        
        $__internal_fea8b22640212265cf3e0d7ef4b97d767bb26634a062e7a085a9359d8e98de81->leave($__internal_fea8b22640212265cf3e0d7ef4b97d767bb26634a062e7a085a9359d8e98de81_prof);

        
        $__internal_f50a721986d7c6cb5591abd1c4c701a17b204061e6d800a873203156848cb8a9->leave($__internal_f50a721986d7c6cb5591abd1c4c701a17b204061e6d800a873203156848cb8a9_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_c57e9e5f8469a4fc33e7f04103ab07d2e57a5667964f6571f494f755b9e1868b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c57e9e5f8469a4fc33e7f04103ab07d2e57a5667964f6571f494f755b9e1868b->enter($__internal_c57e9e5f8469a4fc33e7f04103ab07d2e57a5667964f6571f494f755b9e1868b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_c4ef316cafbfe2604fc0d3d1566d0919f4e132534f5bcbc73c9a4dacceece949 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4ef316cafbfe2604fc0d3d1566d0919f4e132534f5bcbc73c9a4dacceece949->enter($__internal_c4ef316cafbfe2604fc0d3d1566d0919f4e132534f5bcbc73c9a4dacceece949_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_c4ef316cafbfe2604fc0d3d1566d0919f4e132534f5bcbc73c9a4dacceece949->leave($__internal_c4ef316cafbfe2604fc0d3d1566d0919f4e132534f5bcbc73c9a4dacceece949_prof);

        
        $__internal_c57e9e5f8469a4fc33e7f04103ab07d2e57a5667964f6571f494f755b9e1868b->leave($__internal_c57e9e5f8469a4fc33e7f04103ab07d2e57a5667964f6571f494f755b9e1868b_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render any error different from 403, 404 and 500.

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See http://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'http_error.name'|trans({ '%status_code%': status_code }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error.description'|trans({ '%status_code%': status_code }) }}
    </p>
    <p>
        {{ 'http_error.suggestion'|trans({ '%url%': path('blog_index') })|raw }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "@Twig/Exception/error.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\TwigBundle\\views\\Exception\\error.html.twig");
    }
}
