<?php

/* TwigBundle:Exception:error.html.twig */
class __TwigTemplate_ccc6a7cadacc28393b8dba477711424b76fbfad5698dc5fc8ef067c253e01254 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb4d440bf9880d1eaafee50f98a3172dde7849984cfe6ca409edd7951b4b22b1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bb4d440bf9880d1eaafee50f98a3172dde7849984cfe6ca409edd7951b4b22b1->enter($__internal_bb4d440bf9880d1eaafee50f98a3172dde7849984cfe6ca409edd7951b4b22b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.html.twig"));

        $__internal_5822fc25896cc719db24f4693d5623517550cea8180f9a7d945e2ce546f74a9f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5822fc25896cc719db24f4693d5623517550cea8180f9a7d945e2ce546f74a9f->enter($__internal_5822fc25896cc719db24f4693d5623517550cea8180f9a7d945e2ce546f74a9f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bb4d440bf9880d1eaafee50f98a3172dde7849984cfe6ca409edd7951b4b22b1->leave($__internal_bb4d440bf9880d1eaafee50f98a3172dde7849984cfe6ca409edd7951b4b22b1_prof);

        
        $__internal_5822fc25896cc719db24f4693d5623517550cea8180f9a7d945e2ce546f74a9f->leave($__internal_5822fc25896cc719db24f4693d5623517550cea8180f9a7d945e2ce546f74a9f_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_51dfb34fd42b1e1d393afdee00860f219010162cc2a9f2eee9bc23aac78fe500 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51dfb34fd42b1e1d393afdee00860f219010162cc2a9f2eee9bc23aac78fe500->enter($__internal_51dfb34fd42b1e1d393afdee00860f219010162cc2a9f2eee9bc23aac78fe500_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_972a08a0709973a4c2606347d5b5b67720af4147552bff98b44a77953a13181e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_972a08a0709973a4c2606347d5b5b67720af4147552bff98b44a77953a13181e->enter($__internal_972a08a0709973a4c2606347d5b5b67720af4147552bff98b44a77953a13181e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_972a08a0709973a4c2606347d5b5b67720af4147552bff98b44a77953a13181e->leave($__internal_972a08a0709973a4c2606347d5b5b67720af4147552bff98b44a77953a13181e_prof);

        
        $__internal_51dfb34fd42b1e1d393afdee00860f219010162cc2a9f2eee9bc23aac78fe500->leave($__internal_51dfb34fd42b1e1d393afdee00860f219010162cc2a9f2eee9bc23aac78fe500_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_f8e7ada760736c11d1d8c52173439bd160a9e01a73f01e9b6c5dca8dd1717b92 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f8e7ada760736c11d1d8c52173439bd160a9e01a73f01e9b6c5dca8dd1717b92->enter($__internal_f8e7ada760736c11d1d8c52173439bd160a9e01a73f01e9b6c5dca8dd1717b92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_4f8c6c4db09530eef7e760db73a280f7139e23ba45ca25b7f9d46ada991f3f83 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4f8c6c4db09530eef7e760db73a280f7139e23ba45ca25b7f9d46ada991f3f83->enter($__internal_4f8c6c4db09530eef7e760db73a280f7139e23ba45ca25b7f9d46ada991f3f83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")))), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.description", array("%status_code%" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")))), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.suggestion", array("%url%" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index")));
        echo "
    </p>
";
        
        $__internal_4f8c6c4db09530eef7e760db73a280f7139e23ba45ca25b7f9d46ada991f3f83->leave($__internal_4f8c6c4db09530eef7e760db73a280f7139e23ba45ca25b7f9d46ada991f3f83_prof);

        
        $__internal_f8e7ada760736c11d1d8c52173439bd160a9e01a73f01e9b6c5dca8dd1717b92->leave($__internal_f8e7ada760736c11d1d8c52173439bd160a9e01a73f01e9b6c5dca8dd1717b92_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_04f32dbdbf193219e98e08343d129de807e079aebc6daf5e66efa8043cfdf52c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_04f32dbdbf193219e98e08343d129de807e079aebc6daf5e66efa8043cfdf52c->enter($__internal_04f32dbdbf193219e98e08343d129de807e079aebc6daf5e66efa8043cfdf52c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_12e34d6c63a16167c88cfddf127f936589c1e76678686df15686ed590722f5f8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12e34d6c63a16167c88cfddf127f936589c1e76678686df15686ed590722f5f8->enter($__internal_12e34d6c63a16167c88cfddf127f936589c1e76678686df15686ed590722f5f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_12e34d6c63a16167c88cfddf127f936589c1e76678686df15686ed590722f5f8->leave($__internal_12e34d6c63a16167c88cfddf127f936589c1e76678686df15686ed590722f5f8_prof);

        
        $__internal_04f32dbdbf193219e98e08343d129de807e079aebc6daf5e66efa8043cfdf52c->leave($__internal_04f32dbdbf193219e98e08343d129de807e079aebc6daf5e66efa8043cfdf52c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render any error different from 403, 404 and 500.

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See http://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'http_error.name'|trans({ '%status_code%': status_code }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error.description'|trans({ '%status_code%': status_code }) }}
    </p>
    <p>
        {{ 'http_error.suggestion'|trans({ '%url%': path('blog_index') })|raw }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources/TwigBundle/views/Exception/error.html.twig");
    }
}
