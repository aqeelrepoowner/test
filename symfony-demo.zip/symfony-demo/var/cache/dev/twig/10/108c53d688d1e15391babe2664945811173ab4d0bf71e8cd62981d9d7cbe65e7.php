<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_6a271d0a3adc1ba27b56c28c3d3fc25c0bd5dd1df5d63e03d13cd682c3834c00 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80afbf674b587c02e382d48409a607327f6d5af93ef50a1fdbf15ab31c3dc01c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_80afbf674b587c02e382d48409a607327f6d5af93ef50a1fdbf15ab31c3dc01c->enter($__internal_80afbf674b587c02e382d48409a607327f6d5af93ef50a1fdbf15ab31c3dc01c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        $__internal_3b1be6ba384d7f977b5655f3d58e282e1d3d8557dde9e2a889e0c84a9c0cd331 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3b1be6ba384d7f977b5655f3d58e282e1d3d8557dde9e2a889e0c84a9c0cd331->enter($__internal_3b1be6ba384d7f977b5655f3d58e282e1d3d8557dde9e2a889e0c84a9c0cd331_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_80afbf674b587c02e382d48409a607327f6d5af93ef50a1fdbf15ab31c3dc01c->leave($__internal_80afbf674b587c02e382d48409a607327f6d5af93ef50a1fdbf15ab31c3dc01c_prof);

        
        $__internal_3b1be6ba384d7f977b5655f3d58e282e1d3d8557dde9e2a889e0c84a9c0cd331->leave($__internal_3b1be6ba384d7f977b5655f3d58e282e1d3d8557dde9e2a889e0c84a9c0cd331_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
", "@Framework/Form/attributes.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\attributes.html.php");
    }
}
