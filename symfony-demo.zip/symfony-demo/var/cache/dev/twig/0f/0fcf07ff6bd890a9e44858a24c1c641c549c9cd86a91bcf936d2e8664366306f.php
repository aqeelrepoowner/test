<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_c94d6512c9020694f6718b06df2294c9bd7d9c06eb366f1add70b6c4c682ea86 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_06565d6fb29d25772ce6f9d1f9230e35482922eeb2720a2addaf37955e18df24 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06565d6fb29d25772ce6f9d1f9230e35482922eeb2720a2addaf37955e18df24->enter($__internal_06565d6fb29d25772ce6f9d1f9230e35482922eeb2720a2addaf37955e18df24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        $__internal_4ae3ee9bc8d2ed0464ab34e9f2cd167844d5ad18b6a6b53fb2bb1d2627600a6b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4ae3ee9bc8d2ed0464ab34e9f2cd167844d5ad18b6a6b53fb2bb1d2627600a6b->enter($__internal_4ae3ee9bc8d2ed0464ab34e9f2cd167844d5ad18b6a6b53fb2bb1d2627600a6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_06565d6fb29d25772ce6f9d1f9230e35482922eeb2720a2addaf37955e18df24->leave($__internal_06565d6fb29d25772ce6f9d1f9230e35482922eeb2720a2addaf37955e18df24_prof);

        
        $__internal_4ae3ee9bc8d2ed0464ab34e9f2cd167844d5ad18b6a6b53fb2bb1d2627600a6b->leave($__internal_4ae3ee9bc8d2ed0464ab34e9f2cd167844d5ad18b6a6b53fb2bb1d2627600a6b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
", "@Framework/Form/email_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\email_widget.html.php");
    }
}
