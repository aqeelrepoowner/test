<?php

/* :admin/students:index.html.twig */
class __TwigTemplate_7b4d3268b83b2511993a751dfe331c50b5b5569e9bb77f481d596537c2ae4508 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", ":admin/students:index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4144a8f0030bd883ff578fa0341191f48878a687243155628c8bdf5dbb8f6e37 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4144a8f0030bd883ff578fa0341191f48878a687243155628c8bdf5dbb8f6e37->enter($__internal_4144a8f0030bd883ff578fa0341191f48878a687243155628c8bdf5dbb8f6e37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/students:index.html.twig"));

        $__internal_e7282f4f98cf18244c271c00a080ae09a3c3ceccf8054536cdceb4c45e34b01e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e7282f4f98cf18244c271c00a080ae09a3c3ceccf8054536cdceb4c45e34b01e->enter($__internal_e7282f4f98cf18244c271c00a080ae09a3c3ceccf8054536cdceb4c45e34b01e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/students:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_4144a8f0030bd883ff578fa0341191f48878a687243155628c8bdf5dbb8f6e37->leave($__internal_4144a8f0030bd883ff578fa0341191f48878a687243155628c8bdf5dbb8f6e37_prof);

        
        $__internal_e7282f4f98cf18244c271c00a080ae09a3c3ceccf8054536cdceb4c45e34b01e->leave($__internal_e7282f4f98cf18244c271c00a080ae09a3c3ceccf8054536cdceb4c45e34b01e_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_cda2005dc3e88f63d7dc97545a709e0803c5e010f3844564ae8e46df9384f8b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cda2005dc3e88f63d7dc97545a709e0803c5e010f3844564ae8e46df9384f8b8->enter($__internal_cda2005dc3e88f63d7dc97545a709e0803c5e010f3844564ae8e46df9384f8b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_9200d496e519219f0964bac1abd6dcc4261d2de504c4d8f67f519c33371fb655 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9200d496e519219f0964bac1abd6dcc4261d2de504c4d8f67f519c33371fb655->enter($__internal_9200d496e519219f0964bac1abd6dcc4261d2de504c4d8f67f519c33371fb655_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_student_index";
        
        $__internal_9200d496e519219f0964bac1abd6dcc4261d2de504c4d8f67f519c33371fb655->leave($__internal_9200d496e519219f0964bac1abd6dcc4261d2de504c4d8f67f519c33371fb655_prof);

        
        $__internal_cda2005dc3e88f63d7dc97545a709e0803c5e010f3844564ae8e46df9384f8b8->leave($__internal_cda2005dc3e88f63d7dc97545a709e0803c5e010f3844564ae8e46df9384f8b8_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_76838284caa9aab7261a45ce1a1462d0f0af7ca9fbf0e1021b336bbdfdd95cd5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_76838284caa9aab7261a45ce1a1462d0f0af7ca9fbf0e1021b336bbdfdd95cd5->enter($__internal_76838284caa9aab7261a45ce1a1462d0f0af7ca9fbf0e1021b336bbdfdd95cd5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_45cb8f0ca59e6f1b909b2963e79d2f12dc66427edf68c4ce75d429f7acf98f01 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45cb8f0ca59e6f1b909b2963e79d2f12dc66427edf68c4ce75d429f7acf98f01->enter($__internal_45cb8f0ca59e6f1b909b2963e79d2f12dc66427edf68c4ce75d429f7acf98f01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.student_list"), "html", null, true);
        echo "</h1>

    <table class=\"table table-striped table-middle-aligned\">
        <thead>
            <tr>
                <th scope=\"col\">";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_first_name"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_fatherName"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_last_name"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_email"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_gender"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_dob"), "html", null, true);
        echo "</th>
                <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> ";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.actions"), "html", null, true);
        echo "</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["students"]) ? $context["students"] : $this->getContext($context, "students")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["student"]) {
            // line 22
            echo "            <tr>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "first_name", array()), "html", null, true);
            echo "</td>
                ";
            // line 27
            echo "                <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "father_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "last_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "email", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "gender", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "dob", array()), "html", null, true);
            echo "</td>
                <td class=\"text-right\">
                    <div class=\"item-actions\">
                        <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_show", array("id" => $this->getAttribute($context["student"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-default\">
                            ";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.show"), "html", null, true);
            echo "
                        </a>

                        <a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_edit", array("id" => $this->getAttribute($context["student"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit"), "html", null, true);
            echo "
                        </a>
                    </div>
                </td>
            </tr>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 45
            echo "            <tr>
                <td colspan=\"4\" align=\"center\">";
            // line 46
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("student.no_students_found"), "html", null, true);
            echo "</td>
           </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['student'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "        </tbody>
    </table>
";
        
        $__internal_45cb8f0ca59e6f1b909b2963e79d2f12dc66427edf68c4ce75d429f7acf98f01->leave($__internal_45cb8f0ca59e6f1b909b2963e79d2f12dc66427edf68c4ce75d429f7acf98f01_prof);

        
        $__internal_76838284caa9aab7261a45ce1a1462d0f0af7ca9fbf0e1021b336bbdfdd95cd5->leave($__internal_76838284caa9aab7261a45ce1a1462d0f0af7ca9fbf0e1021b336bbdfdd95cd5_prof);

    }

    // line 53
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_7ce57d3a070ff46845710b05d809caa36466e6d3f652109e2d7d74348eb1d47e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ce57d3a070ff46845710b05d809caa36466e6d3f652109e2d7d74348eb1d47e->enter($__internal_7ce57d3a070ff46845710b05d809caa36466e6d3f652109e2d7d74348eb1d47e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_7c7fcd138ce98717446df2b3cce2029319e249696c2131471c30d28682948b41 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c7fcd138ce98717446df2b3cce2029319e249696c2131471c30d28682948b41->enter($__internal_7c7fcd138ce98717446df2b3cce2029319e249696c2131471c30d28682948b41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 54
        echo "    <div class=\"section actions\">
        <a href=\"";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_new");
        echo "\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> ";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.create_student"), "html", null, true);
        echo "
        </a>
    </div>

    ";
        // line 60
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 62
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_7c7fcd138ce98717446df2b3cce2029319e249696c2131471c30d28682948b41->leave($__internal_7c7fcd138ce98717446df2b3cce2029319e249696c2131471c30d28682948b41_prof);

        
        $__internal_7ce57d3a070ff46845710b05d809caa36466e6d3f652109e2d7d74348eb1d47e->leave($__internal_7ce57d3a070ff46845710b05d809caa36466e6d3f652109e2d7d74348eb1d47e_prof);

    }

    public function getTemplateName()
    {
        return ":admin/students:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  221 => 62,  216 => 60,  209 => 56,  205 => 55,  202 => 54,  193 => 53,  181 => 49,  172 => 46,  169 => 45,  158 => 39,  154 => 38,  148 => 35,  144 => 34,  138 => 31,  134 => 30,  130 => 29,  126 => 28,  121 => 27,  117 => 23,  114 => 22,  109 => 21,  102 => 17,  98 => 16,  94 => 15,  90 => 14,  86 => 13,  82 => 12,  78 => 11,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_student_index' %}

{% block main %}
    <h1>{{ 'title.student_list'|trans }}</h1>

    <table class=\"table table-striped table-middle-aligned\">
        <thead>
            <tr>
                <th scope=\"col\">{{ 'label.student_first_name'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_fatherName'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_last_name'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_email'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_gender'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_dob'|trans }}</th>
                <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> {{ 'label.actions'|trans }}</th>
            </tr>
        </thead>
        <tbody>
        {% for student in students %}
            <tr>
                <td>{{ student.first_name }}</td>
                {# it's not mandatory to set the timezone in localizeddate(). This is done to
                   avoid errors when the 'intl' PHP extension is not available and the application
                   is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
                <td>{{ student.father_name }}</td>
                <td>{{ student.last_name }}</td>
                <td>{{ student.email }}</td>
                <td>{{ student.gender }}</td>
                <td>{{ student.dob }}</td>
                <td class=\"text-right\">
                    <div class=\"item-actions\">
                        <a href=\"{{ path('admin_student_show', { id: student.id }) }}\" class=\"btn btn-sm btn-default\">
                            {{ 'action.show'|trans }}
                        </a>

                        <a href=\"{{ path('admin_student_edit', { id: student.id }) }}\" class=\"btn btn-sm btn-primary\">
                            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit'|trans }}
                        </a>
                    </div>
                </td>
            </tr>
        {% else %}
            <tr>
                <td colspan=\"4\" align=\"center\">{{ 'student.no_students_found'|trans }}</td>
           </tr>
        {% endfor %}
        </tbody>
    </table>
{% endblock %}

{% block sidebar %}
    <div class=\"section actions\">
        <a href=\"{{ path('admin_student_new') }}\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> {{ 'action.create_student'|trans }}
        </a>
    </div>

    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", ":admin/students:index.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/admin/students/index.html.twig");
    }
}
