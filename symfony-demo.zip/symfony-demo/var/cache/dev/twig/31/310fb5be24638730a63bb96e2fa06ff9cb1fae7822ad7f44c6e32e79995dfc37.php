<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_5dc9fb1a2a190c7196172e81ce6a04fe27debbd4b7295a4466a7789eadceff4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_65709db4ac42e021c4a2fd0a0302ff5f4338a834b0cc7df452bd5fc4009b6597 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65709db4ac42e021c4a2fd0a0302ff5f4338a834b0cc7df452bd5fc4009b6597->enter($__internal_65709db4ac42e021c4a2fd0a0302ff5f4338a834b0cc7df452bd5fc4009b6597_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        $__internal_4bf208dc65cc5f59663ac701a24c0281df03459b19dd18d449405fcbc4693a7d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bf208dc65cc5f59663ac701a24c0281df03459b19dd18d449405fcbc4693a7d->enter($__internal_4bf208dc65cc5f59663ac701a24c0281df03459b19dd18d449405fcbc4693a7d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_65709db4ac42e021c4a2fd0a0302ff5f4338a834b0cc7df452bd5fc4009b6597->leave($__internal_65709db4ac42e021c4a2fd0a0302ff5f4338a834b0cc7df452bd5fc4009b6597_prof);

        
        $__internal_4bf208dc65cc5f59663ac701a24c0281df03459b19dd18d449405fcbc4693a7d->leave($__internal_4bf208dc65cc5f59663ac701a24c0281df03459b19dd18d449405fcbc4693a7d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("", "@Framework/Form/button_label.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\button_label.html.php");
    }
}
