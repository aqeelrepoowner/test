<?php

/* admin/blog/edit.html.twig */
class __TwigTemplate_6cd1403e8bb4e8561fb8255cd6b23499e76c70b787f25b15bffe32675a038fa4 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/blog/edit.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84767405dc3df109cbddb013cb36c97b0ec658339a1825e24145a427c93f2a05 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84767405dc3df109cbddb013cb36c97b0ec658339a1825e24145a427c93f2a05->enter($__internal_84767405dc3df109cbddb013cb36c97b0ec658339a1825e24145a427c93f2a05_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/edit.html.twig"));

        $__internal_037041f140ad8b46d6d33dc3b67da08ae7b9b16b47bd13bae136cde0d3f60e27 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_037041f140ad8b46d6d33dc3b67da08ae7b9b16b47bd13bae136cde0d3f60e27->enter($__internal_037041f140ad8b46d6d33dc3b67da08ae7b9b16b47bd13bae136cde0d3f60e27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_84767405dc3df109cbddb013cb36c97b0ec658339a1825e24145a427c93f2a05->leave($__internal_84767405dc3df109cbddb013cb36c97b0ec658339a1825e24145a427c93f2a05_prof);

        
        $__internal_037041f140ad8b46d6d33dc3b67da08ae7b9b16b47bd13bae136cde0d3f60e27->leave($__internal_037041f140ad8b46d6d33dc3b67da08ae7b9b16b47bd13bae136cde0d3f60e27_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_0e6d7c47d8bd1234e59fd731dd7de8a9621334f812dee7f91f1fad9bb0f9fb3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0e6d7c47d8bd1234e59fd731dd7de8a9621334f812dee7f91f1fad9bb0f9fb3c->enter($__internal_0e6d7c47d8bd1234e59fd731dd7de8a9621334f812dee7f91f1fad9bb0f9fb3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_a895741687dbf6b1badc3b4b8dba6a4eadab654f21890ec0cb5449e9bc962791 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a895741687dbf6b1badc3b4b8dba6a4eadab654f21890ec0cb5449e9bc962791->enter($__internal_a895741687dbf6b1badc3b4b8dba6a4eadab654f21890ec0cb5449e9bc962791_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_edit";
        
        $__internal_a895741687dbf6b1badc3b4b8dba6a4eadab654f21890ec0cb5449e9bc962791->leave($__internal_a895741687dbf6b1badc3b4b8dba6a4eadab654f21890ec0cb5449e9bc962791_prof);

        
        $__internal_0e6d7c47d8bd1234e59fd731dd7de8a9621334f812dee7f91f1fad9bb0f9fb3c->leave($__internal_0e6d7c47d8bd1234e59fd731dd7de8a9621334f812dee7f91f1fad9bb0f9fb3c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_d027900799933db08a533727c2d3cb5545bdbefaa9fad8eae6b8f2ca4cb0cf85 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d027900799933db08a533727c2d3cb5545bdbefaa9fad8eae6b8f2ca4cb0cf85->enter($__internal_d027900799933db08a533727c2d3cb5545bdbefaa9fad8eae6b8f2ca4cb0cf85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_69ac73fb6ed480878636b6690a30bc2957bf48c22ea6b8bbdd4c909ac37696b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_69ac73fb6ed480878636b6690a30bc2957bf48c22ea6b8bbdd4c909ac37696b3->enter($__internal_69ac73fb6ed480878636b6690a30bc2957bf48c22ea6b8bbdd4c909ac37696b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.edit_post", array("%id%" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo twig_include($this->env, $context, "admin/blog/_form.html.twig", array("form" =>         // line 9
(isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "button_label" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.save"), "include_back_to_home_link" => true), false);
        // line 12
        echo "
";
        
        $__internal_69ac73fb6ed480878636b6690a30bc2957bf48c22ea6b8bbdd4c909ac37696b3->leave($__internal_69ac73fb6ed480878636b6690a30bc2957bf48c22ea6b8bbdd4c909ac37696b3_prof);

        
        $__internal_d027900799933db08a533727c2d3cb5545bdbefaa9fad8eae6b8f2ca4cb0cf85->leave($__internal_d027900799933db08a533727c2d3cb5545bdbefaa9fad8eae6b8f2ca4cb0cf85_prof);

    }

    // line 15
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_0bf5752ba042c719c51b282ac2841de6984066105d2ce0408f478a700fdca922 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0bf5752ba042c719c51b282ac2841de6984066105d2ce0408f478a700fdca922->enter($__internal_0bf5752ba042c719c51b282ac2841de6984066105d2ce0408f478a700fdca922_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_4d1e2c344d2d134ae8babfb25280e79357afca3bfa65af2db2e0fe11cc29ffe1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d1e2c344d2d134ae8babfb25280e79357afca3bfa65af2db2e0fe11cc29ffe1->enter($__internal_4d1e2c344d2d134ae8babfb25280e79357afca3bfa65af2db2e0fe11cc29ffe1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 16
        echo "    <div class=\"section actions\">
        ";
        // line 17
        echo twig_include($this->env, $context, "admin/blog/_delete_form.html.twig", array("post" => (isset($context["post"]) ? $context["post"] : $this->getContext($context, "post"))), false);
        echo "
    </div>

    ";
        // line 20
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 22
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_4d1e2c344d2d134ae8babfb25280e79357afca3bfa65af2db2e0fe11cc29ffe1->leave($__internal_4d1e2c344d2d134ae8babfb25280e79357afca3bfa65af2db2e0fe11cc29ffe1_prof);

        
        $__internal_0bf5752ba042c719c51b282ac2841de6984066105d2ce0408f478a700fdca922->leave($__internal_0bf5752ba042c719c51b282ac2841de6984066105d2ce0408f478a700fdca922_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 22,  107 => 20,  101 => 17,  98 => 16,  89 => 15,  78 => 12,  76 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_edit' %}

{% block main %}
    <h1>{{ 'title.edit_post'|trans({'%id%': post.id}) }}</h1>

    {{ include('admin/blog/_form.html.twig', {
        form: form,
        button_label: 'action.save'|trans,
        include_back_to_home_link: true,
    }, with_context = false) }}
{% endblock %}

{% block sidebar %}
    <div class=\"section actions\">
        {{ include('admin/blog/_delete_form.html.twig', { post: post }, with_context = false) }}
    </div>

    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "admin/blog/edit.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\admin\\blog\\edit.html.twig");
    }
}
