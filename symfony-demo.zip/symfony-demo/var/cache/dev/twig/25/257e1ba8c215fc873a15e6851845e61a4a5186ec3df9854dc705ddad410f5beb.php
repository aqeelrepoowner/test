<?php

/* admin/blog/show.html.twig */
class __TwigTemplate_ac47a398cc7a309c8996291448e1c246150f5e633d33468d667fc40f954e813a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/blog/show.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e6b3983171aa52ea0fd9dab6f3bc32ab7832402d035fd2a6aab24ab5f3f0da90 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e6b3983171aa52ea0fd9dab6f3bc32ab7832402d035fd2a6aab24ab5f3f0da90->enter($__internal_e6b3983171aa52ea0fd9dab6f3bc32ab7832402d035fd2a6aab24ab5f3f0da90_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/show.html.twig"));

        $__internal_2271291b385f2d553342a52c3d3d6a9a0179f0112905aaec112802c32e916ff3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2271291b385f2d553342a52c3d3d6a9a0179f0112905aaec112802c32e916ff3->enter($__internal_2271291b385f2d553342a52c3d3d6a9a0179f0112905aaec112802c32e916ff3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e6b3983171aa52ea0fd9dab6f3bc32ab7832402d035fd2a6aab24ab5f3f0da90->leave($__internal_e6b3983171aa52ea0fd9dab6f3bc32ab7832402d035fd2a6aab24ab5f3f0da90_prof);

        
        $__internal_2271291b385f2d553342a52c3d3d6a9a0179f0112905aaec112802c32e916ff3->leave($__internal_2271291b385f2d553342a52c3d3d6a9a0179f0112905aaec112802c32e916ff3_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_383d38b781231807f7f46673c12b78ceaea22463e57512adcc4eadb38af58dfd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_383d38b781231807f7f46673c12b78ceaea22463e57512adcc4eadb38af58dfd->enter($__internal_383d38b781231807f7f46673c12b78ceaea22463e57512adcc4eadb38af58dfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_b676cd3ee83f54c9bbfad1b470bb397c47a12371548906d4a86449dc5456b996 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b676cd3ee83f54c9bbfad1b470bb397c47a12371548906d4a86449dc5456b996->enter($__internal_b676cd3ee83f54c9bbfad1b470bb397c47a12371548906d4a86449dc5456b996_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_show";
        
        $__internal_b676cd3ee83f54c9bbfad1b470bb397c47a12371548906d4a86449dc5456b996->leave($__internal_b676cd3ee83f54c9bbfad1b470bb397c47a12371548906d4a86449dc5456b996_prof);

        
        $__internal_383d38b781231807f7f46673c12b78ceaea22463e57512adcc4eadb38af58dfd->leave($__internal_383d38b781231807f7f46673c12b78ceaea22463e57512adcc4eadb38af58dfd_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_09a3f678c51b596ca941785b579a1a893f6367a5fdc8a33ec06f1526f3811c3d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_09a3f678c51b596ca941785b579a1a893f6367a5fdc8a33ec06f1526f3811c3d->enter($__internal_09a3f678c51b596ca941785b579a1a893f6367a5fdc8a33ec06f1526f3811c3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_e9d24f9c1cc4409770a36ac6bbcaba35d74994c618fce7601fd0a58b774206b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9d24f9c1cc4409770a36ac6bbcaba35d74994c618fce7601fd0a58b774206b6->enter($__internal_e9d24f9c1cc4409770a36ac6bbcaba35d74994c618fce7601fd0a58b774206b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo "</h1>
    <p class=\"post-metadata\">
        <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> ";
        // line 8
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
        echo "</span>
        <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "author", array()), "email", array()), "html", null, true);
        echo "</span>
    </p>

    <div class=\"well\">
        <p class=\"m-b-0\"><strong>";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.summary"), "html", null, true);
        echo "</strong>: ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "summary", array()), "html", null, true);
        echo "</p>
    </div>

    ";
        // line 16
        echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "content", array()));
        echo "
";
        
        $__internal_e9d24f9c1cc4409770a36ac6bbcaba35d74994c618fce7601fd0a58b774206b6->leave($__internal_e9d24f9c1cc4409770a36ac6bbcaba35d74994c618fce7601fd0a58b774206b6_prof);

        
        $__internal_09a3f678c51b596ca941785b579a1a893f6367a5fdc8a33ec06f1526f3811c3d->leave($__internal_09a3f678c51b596ca941785b579a1a893f6367a5fdc8a33ec06f1526f3811c3d_prof);

    }

    // line 19
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_a07f9fb44d4ac7e201549d5f5762b466152da5a1400f8ca27f6277c9546da40b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a07f9fb44d4ac7e201549d5f5762b466152da5a1400f8ca27f6277c9546da40b->enter($__internal_a07f9fb44d4ac7e201549d5f5762b466152da5a1400f8ca27f6277c9546da40b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_1145dc304491515703ad0506533798364785c207c29f4465e9ee43cc3e221fa9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1145dc304491515703ad0506533798364785c207c29f4465e9ee43cc3e221fa9->enter($__internal_1145dc304491515703ad0506533798364785c207c29f4465e9ee43cc3e221fa9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 20
        echo "    <div class=\"section\">
        <a href=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_edit", array("id" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit_contents"), "html", null, true);
        echo "
        </a>
    </div>

    <div class=\"section\">
        ";
        // line 27
        echo twig_include($this->env, $context, "admin/blog/_delete_form.html.twig", array("post" => (isset($context["post"]) ? $context["post"] : $this->getContext($context, "post"))), false);
        echo "
    </div>

    ";
        // line 30
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 32
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_1145dc304491515703ad0506533798364785c207c29f4465e9ee43cc3e221fa9->leave($__internal_1145dc304491515703ad0506533798364785c207c29f4465e9ee43cc3e221fa9_prof);

        
        $__internal_a07f9fb44d4ac7e201549d5f5762b466152da5a1400f8ca27f6277c9546da40b->leave($__internal_a07f9fb44d4ac7e201549d5f5762b466152da5a1400f8ca27f6277c9546da40b_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 32,  136 => 30,  130 => 27,  122 => 22,  118 => 21,  115 => 20,  106 => 19,  94 => 16,  86 => 13,  79 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_show' %}

{% block main %}
    <h1>{{ post.title }}</h1>
    <p class=\"post-metadata\">
        <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}</span>
        <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.author.email }}</span>
    </p>

    <div class=\"well\">
        <p class=\"m-b-0\"><strong>{{ 'label.summary'|trans }}</strong>: {{ post.summary }}</p>
    </div>

    {{ post.content|md2html }}
{% endblock %}

{% block sidebar %}
    <div class=\"section\">
        <a href=\"{{ path('admin_post_edit', { id: post.id }) }}\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit_contents'|trans }}
        </a>
    </div>

    <div class=\"section\">
        {{ include('admin/blog/_delete_form.html.twig', { post: post }, with_context = false) }}
    </div>

    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "admin/blog/show.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\admin\\blog\\show.html.twig");
    }
}
