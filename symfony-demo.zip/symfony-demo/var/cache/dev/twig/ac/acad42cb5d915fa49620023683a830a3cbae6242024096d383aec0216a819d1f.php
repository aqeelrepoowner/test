<?php

/* TwigBundle:Exception:error500.html.twig */
class __TwigTemplate_9c1d4cea0604fd736f3942fff9cc4ab215d88293b5d7064c32c073916cbc55de extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error500.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3be71b90b312cc51c47044c139d256bf62d00c31b29992f753529c39550850e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3be71b90b312cc51c47044c139d256bf62d00c31b29992f753529c39550850e0->enter($__internal_3be71b90b312cc51c47044c139d256bf62d00c31b29992f753529c39550850e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error500.html.twig"));

        $__internal_87aab84d302a00f582099bbdf48e716b4168fd03a933df8b8be0804e0bdc61bf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87aab84d302a00f582099bbdf48e716b4168fd03a933df8b8be0804e0bdc61bf->enter($__internal_87aab84d302a00f582099bbdf48e716b4168fd03a933df8b8be0804e0bdc61bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error500.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3be71b90b312cc51c47044c139d256bf62d00c31b29992f753529c39550850e0->leave($__internal_3be71b90b312cc51c47044c139d256bf62d00c31b29992f753529c39550850e0_prof);

        
        $__internal_87aab84d302a00f582099bbdf48e716b4168fd03a933df8b8be0804e0bdc61bf->leave($__internal_87aab84d302a00f582099bbdf48e716b4168fd03a933df8b8be0804e0bdc61bf_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_901f5cb4340a493512a1c483644e7b201469ccc8f60385e6680b70f7e281f866 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_901f5cb4340a493512a1c483644e7b201469ccc8f60385e6680b70f7e281f866->enter($__internal_901f5cb4340a493512a1c483644e7b201469ccc8f60385e6680b70f7e281f866_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_a785706bf283b6cc7147f5950d8308ae4f26a69da4a41f1d49a17da0e165bf63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a785706bf283b6cc7147f5950d8308ae4f26a69da4a41f1d49a17da0e165bf63->enter($__internal_a785706bf283b6cc7147f5950d8308ae4f26a69da4a41f1d49a17da0e165bf63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_a785706bf283b6cc7147f5950d8308ae4f26a69da4a41f1d49a17da0e165bf63->leave($__internal_a785706bf283b6cc7147f5950d8308ae4f26a69da4a41f1d49a17da0e165bf63_prof);

        
        $__internal_901f5cb4340a493512a1c483644e7b201469ccc8f60385e6680b70f7e281f866->leave($__internal_901f5cb4340a493512a1c483644e7b201469ccc8f60385e6680b70f7e281f866_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_aedb798258a58983c99d6add5b304fc57bd0cb4d135083bb5054914af45c4c93 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aedb798258a58983c99d6add5b304fc57bd0cb4d135083bb5054914af45c4c93->enter($__internal_aedb798258a58983c99d6add5b304fc57bd0cb4d135083bb5054914af45c4c93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_251903421c21d7a50b2e2837c9bbc52c469a1fbd7f94019b532e8ea0c1a61636 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_251903421c21d7a50b2e2837c9bbc52c469a1fbd7f94019b532e8ea0c1a61636->enter($__internal_251903421c21d7a50b2e2837c9bbc52c469a1fbd7f94019b532e8ea0c1a61636_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => 500)), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_500.description"), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_500.suggestion", array("%url%" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index")));
        echo "
    </p>
";
        
        $__internal_251903421c21d7a50b2e2837c9bbc52c469a1fbd7f94019b532e8ea0c1a61636->leave($__internal_251903421c21d7a50b2e2837c9bbc52c469a1fbd7f94019b532e8ea0c1a61636_prof);

        
        $__internal_aedb798258a58983c99d6add5b304fc57bd0cb4d135083bb5054914af45c4c93->leave($__internal_aedb798258a58983c99d6add5b304fc57bd0cb4d135083bb5054914af45c4c93_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_66ff8d7989b077768acb64671fcc33861c3114de52097e1dd15422dd7739256c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_66ff8d7989b077768acb64671fcc33861c3114de52097e1dd15422dd7739256c->enter($__internal_66ff8d7989b077768acb64671fcc33861c3114de52097e1dd15422dd7739256c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_a99acc893eac90459f571d130a394546d92f80226134c8bdb132b0c3628ac313 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a99acc893eac90459f571d130a394546d92f80226134c8bdb132b0c3628ac313->enter($__internal_a99acc893eac90459f571d130a394546d92f80226134c8bdb132b0c3628ac313_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_a99acc893eac90459f571d130a394546d92f80226134c8bdb132b0c3628ac313->leave($__internal_a99acc893eac90459f571d130a394546d92f80226134c8bdb132b0c3628ac313_prof);

        
        $__internal_66ff8d7989b077768acb64671fcc33861c3114de52097e1dd15422dd7739256c->leave($__internal_66ff8d7989b077768acb64671fcc33861c3114de52097e1dd15422dd7739256c_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error500.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render errors of type HTTP 500 (Internal Server Error)

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See http://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'http_error.name'|trans({ '%status_code%': 500 }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error_500.description'|trans }}
    </p>
    <p>
        {{ 'http_error_500.suggestion'|trans({ '%url%': path('blog_index') })|raw }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error500.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources/TwigBundle/views/Exception/error500.html.twig");
    }
}
