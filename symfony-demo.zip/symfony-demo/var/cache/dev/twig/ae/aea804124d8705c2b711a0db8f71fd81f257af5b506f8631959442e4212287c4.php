<?php

/* blog/index.html.twig */
class __TwigTemplate_faa53cec38c416106a4d3b7342926cfe6abf556d597d15843901ce901e81218d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0bf6fba0d2cb35666835a4569041d768219128b167e75a26ac08bde0bd6adfee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0bf6fba0d2cb35666835a4569041d768219128b167e75a26ac08bde0bd6adfee->enter($__internal_0bf6fba0d2cb35666835a4569041d768219128b167e75a26ac08bde0bd6adfee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $__internal_1c62f7468478b33a17b5f4f30952c89cdbe604320b7c91a7ca034b38032e9b3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1c62f7468478b33a17b5f4f30952c89cdbe604320b7c91a7ca034b38032e9b3c->enter($__internal_1c62f7468478b33a17b5f4f30952c89cdbe604320b7c91a7ca034b38032e9b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0bf6fba0d2cb35666835a4569041d768219128b167e75a26ac08bde0bd6adfee->leave($__internal_0bf6fba0d2cb35666835a4569041d768219128b167e75a26ac08bde0bd6adfee_prof);

        
        $__internal_1c62f7468478b33a17b5f4f30952c89cdbe604320b7c91a7ca034b38032e9b3c->leave($__internal_1c62f7468478b33a17b5f4f30952c89cdbe604320b7c91a7ca034b38032e9b3c_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_3c36d392e0a2a127e734c32337b33a87f713337f8e1a7f828187618718c9a97c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3c36d392e0a2a127e734c32337b33a87f713337f8e1a7f828187618718c9a97c->enter($__internal_3c36d392e0a2a127e734c32337b33a87f713337f8e1a7f828187618718c9a97c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_3920f6b7d9b44642b2b0dd4afaaec2cfd979c7e20a5ef115edc970e258f500a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3920f6b7d9b44642b2b0dd4afaaec2cfd979c7e20a5ef115edc970e258f500a7->enter($__internal_3920f6b7d9b44642b2b0dd4afaaec2cfd979c7e20a5ef115edc970e258f500a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "blog_index";
        
        $__internal_3920f6b7d9b44642b2b0dd4afaaec2cfd979c7e20a5ef115edc970e258f500a7->leave($__internal_3920f6b7d9b44642b2b0dd4afaaec2cfd979c7e20a5ef115edc970e258f500a7_prof);

        
        $__internal_3c36d392e0a2a127e734c32337b33a87f713337f8e1a7f828187618718c9a97c->leave($__internal_3c36d392e0a2a127e734c32337b33a87f713337f8e1a7f828187618718c9a97c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_6887ec7d1c110a13b1054e36c25360ad53a29664bee0950b481fae9470a0844b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6887ec7d1c110a13b1054e36c25360ad53a29664bee0950b481fae9470a0844b->enter($__internal_6887ec7d1c110a13b1054e36c25360ad53a29664bee0950b481fae9470a0844b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_08f01c946cdbd161cd23039200ca2f2640a81efa6532b6e080bbc2d7c290846c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08f01c946cdbd161cd23039200ca2f2640a81efa6532b6e080bbc2d7c290846c->enter($__internal_08f01c946cdbd161cd23039200ca2f2640a81efa6532b6e080bbc2d7c290846c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 7
            echo "        <article class=\"post\">
            <h2>
                <a href=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_post", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\">
                    ";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "
                </a>
            </h2>

            <p class=\"post-metadata\">
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> ";
            // line 15
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
            echo "</span>
                <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "author", array()), "email", array()), "html", null, true);
            echo "</span>
            </p>

            ";
            // line 19
            echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["post"], "summary", array()));
            echo "
        </article>
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 22
            echo "        <div class=\"well\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_posts_found"), "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "
    ";
        // line 25
        if ($this->getAttribute((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")), "haveToPaginate", array())) {
            // line 26
            echo "        <div class=\"navigation text-center\">
            ";
            // line 27
            echo $this->env->getExtension('WhiteOctober\PagerfantaBundle\Twig\PagerfantaExtension')->renderPagerfanta((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")), "twitter_bootstrap3_translated", array("routeName" => "blog_index_paginated"));
            echo "
        </div>
    ";
        }
        
        $__internal_08f01c946cdbd161cd23039200ca2f2640a81efa6532b6e080bbc2d7c290846c->leave($__internal_08f01c946cdbd161cd23039200ca2f2640a81efa6532b6e080bbc2d7c290846c_prof);

        
        $__internal_6887ec7d1c110a13b1054e36c25360ad53a29664bee0950b481fae9470a0844b->leave($__internal_6887ec7d1c110a13b1054e36c25360ad53a29664bee0950b481fae9470a0844b_prof);

    }

    // line 32
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_1b42c34731b49e87257daec6f0030e1b313fc0fc59ebb531a694751a72cf9270 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1b42c34731b49e87257daec6f0030e1b313fc0fc59ebb531a694751a72cf9270->enter($__internal_1b42c34731b49e87257daec6f0030e1b313fc0fc59ebb531a694751a72cf9270_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_bfd3de6856d3389176b76ad3b6e70262e525be84eb9a7158da012c05821dcf82 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bfd3de6856d3389176b76ad3b6e70262e525be84eb9a7158da012c05821dcf82->enter($__internal_bfd3de6856d3389176b76ad3b6e70262e525be84eb9a7158da012c05821dcf82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 33
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 35
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
    ";
        // line 36
        echo twig_include($this->env, $context, "blog/_rss.html.twig");
        echo "
";
        
        $__internal_bfd3de6856d3389176b76ad3b6e70262e525be84eb9a7158da012c05821dcf82->leave($__internal_bfd3de6856d3389176b76ad3b6e70262e525be84eb9a7158da012c05821dcf82_prof);

        
        $__internal_1b42c34731b49e87257daec6f0030e1b313fc0fc59ebb531a694751a72cf9270->leave($__internal_1b42c34731b49e87257daec6f0030e1b313fc0fc59ebb531a694751a72cf9270_prof);

    }

    public function getTemplateName()
    {
        return "blog/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 36,  155 => 35,  149 => 33,  140 => 32,  126 => 27,  123 => 26,  121 => 25,  118 => 24,  109 => 22,  101 => 19,  95 => 16,  91 => 15,  83 => 10,  79 => 9,  75 => 7,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'blog_index' %}

{% block main %}
    {% for post in posts %}
        <article class=\"post\">
            <h2>
                <a href=\"{{ path('blog_post', { slug: post.slug }) }}\">
                    {{ post.title }}
                </a>
            </h2>

            <p class=\"post-metadata\">
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}</span>
                <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.author.email }}</span>
            </p>

            {{ post.summary|md2html }}
        </article>
    {% else %}
        <div class=\"well\">{{ 'post.no_posts_found'|trans }}</div>
    {% endfor %}

    {% if posts.haveToPaginate %}
        <div class=\"navigation text-center\">
            {{ pagerfanta(posts, 'twitter_bootstrap3_translated', { routeName: 'blog_index_paginated' }) }}
        </div>
    {% endif %}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
    {{ include('blog/_rss.html.twig') }}
{% endblock %}
", "blog/index.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\blog\\index.html.twig");
    }
}
