<?php

/* :blog:index.html.twig */
class __TwigTemplate_5c12a640aae05cebe2fd91597cab118272f13b582f08192f3a631740744215e2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":blog:index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1bf6b907501776c5315c67a42eff6bd4345fd189aad61ce3ffcb7e0e7a7184d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d1bf6b907501776c5315c67a42eff6bd4345fd189aad61ce3ffcb7e0e7a7184d->enter($__internal_d1bf6b907501776c5315c67a42eff6bd4345fd189aad61ce3ffcb7e0e7a7184d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:index.html.twig"));

        $__internal_a1b99b9da473b827f7eb2bfde999e7fb71d1729a2b41cf2dd82ef392937b7b38 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a1b99b9da473b827f7eb2bfde999e7fb71d1729a2b41cf2dd82ef392937b7b38->enter($__internal_a1b99b9da473b827f7eb2bfde999e7fb71d1729a2b41cf2dd82ef392937b7b38_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d1bf6b907501776c5315c67a42eff6bd4345fd189aad61ce3ffcb7e0e7a7184d->leave($__internal_d1bf6b907501776c5315c67a42eff6bd4345fd189aad61ce3ffcb7e0e7a7184d_prof);

        
        $__internal_a1b99b9da473b827f7eb2bfde999e7fb71d1729a2b41cf2dd82ef392937b7b38->leave($__internal_a1b99b9da473b827f7eb2bfde999e7fb71d1729a2b41cf2dd82ef392937b7b38_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_eaf77093a18b596cb5fcebd2ccc3c859df8e4c50acacd88fd5f9baee2dffce41 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eaf77093a18b596cb5fcebd2ccc3c859df8e4c50acacd88fd5f9baee2dffce41->enter($__internal_eaf77093a18b596cb5fcebd2ccc3c859df8e4c50acacd88fd5f9baee2dffce41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_be71c3f55bc86401dc56e8bb409864b39a28a9ade0aa6da0e6329cd1783a524a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_be71c3f55bc86401dc56e8bb409864b39a28a9ade0aa6da0e6329cd1783a524a->enter($__internal_be71c3f55bc86401dc56e8bb409864b39a28a9ade0aa6da0e6329cd1783a524a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "blog_index";
        
        $__internal_be71c3f55bc86401dc56e8bb409864b39a28a9ade0aa6da0e6329cd1783a524a->leave($__internal_be71c3f55bc86401dc56e8bb409864b39a28a9ade0aa6da0e6329cd1783a524a_prof);

        
        $__internal_eaf77093a18b596cb5fcebd2ccc3c859df8e4c50acacd88fd5f9baee2dffce41->leave($__internal_eaf77093a18b596cb5fcebd2ccc3c859df8e4c50acacd88fd5f9baee2dffce41_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_a8da309d896ca1113e01d9023a658e95755463bb6f0a25d91e6028fbfc522bc0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a8da309d896ca1113e01d9023a658e95755463bb6f0a25d91e6028fbfc522bc0->enter($__internal_a8da309d896ca1113e01d9023a658e95755463bb6f0a25d91e6028fbfc522bc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_ee56e24288b49deec8c16bc733dc9404da915784e0e5112c7807266b8fe78f5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ee56e24288b49deec8c16bc733dc9404da915784e0e5112c7807266b8fe78f5c->enter($__internal_ee56e24288b49deec8c16bc733dc9404da915784e0e5112c7807266b8fe78f5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 7
            echo "        <article class=\"post\">
            <h2>
                <a href=\"";
            // line 9
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_post", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "\">
                    ";
            // line 10
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "
                </a>
            </h2>

            <p class=\"post-metadata\">
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> ";
            // line 15
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
            echo "</span>
                <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "author", array()), "email", array()), "html", null, true);
            echo "</span>
            </p>

            ";
            // line 19
            echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["post"], "summary", array()));
            echo "
        </article>
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 22
            echo "        <div class=\"well\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_posts_found"), "html", null, true);
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 24
        echo "
    ";
        // line 25
        if ($this->getAttribute((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")), "haveToPaginate", array())) {
            // line 26
            echo "        <div class=\"navigation text-center\">
            ";
            // line 27
            echo $this->env->getExtension('WhiteOctober\PagerfantaBundle\Twig\PagerfantaExtension')->renderPagerfanta((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")), "twitter_bootstrap3_translated", array("routeName" => "blog_index_paginated"));
            echo "
        </div>
    ";
        }
        
        $__internal_ee56e24288b49deec8c16bc733dc9404da915784e0e5112c7807266b8fe78f5c->leave($__internal_ee56e24288b49deec8c16bc733dc9404da915784e0e5112c7807266b8fe78f5c_prof);

        
        $__internal_a8da309d896ca1113e01d9023a658e95755463bb6f0a25d91e6028fbfc522bc0->leave($__internal_a8da309d896ca1113e01d9023a658e95755463bb6f0a25d91e6028fbfc522bc0_prof);

    }

    // line 32
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_07e16748955cd4f472493fc96489963e6bc61026c0e4ce7c60393bb2f7e1f02e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_07e16748955cd4f472493fc96489963e6bc61026c0e4ce7c60393bb2f7e1f02e->enter($__internal_07e16748955cd4f472493fc96489963e6bc61026c0e4ce7c60393bb2f7e1f02e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_e365df7f25aecf0e5d02a09a32fb0ba1140e7afd1d1bd2404f45323cff4a7e33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e365df7f25aecf0e5d02a09a32fb0ba1140e7afd1d1bd2404f45323cff4a7e33->enter($__internal_e365df7f25aecf0e5d02a09a32fb0ba1140e7afd1d1bd2404f45323cff4a7e33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 33
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 35
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
    ";
        // line 36
        echo twig_include($this->env, $context, "blog/_rss.html.twig");
        echo "
";
        
        $__internal_e365df7f25aecf0e5d02a09a32fb0ba1140e7afd1d1bd2404f45323cff4a7e33->leave($__internal_e365df7f25aecf0e5d02a09a32fb0ba1140e7afd1d1bd2404f45323cff4a7e33_prof);

        
        $__internal_07e16748955cd4f472493fc96489963e6bc61026c0e4ce7c60393bb2f7e1f02e->leave($__internal_07e16748955cd4f472493fc96489963e6bc61026c0e4ce7c60393bb2f7e1f02e_prof);

    }

    public function getTemplateName()
    {
        return ":blog:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 36,  155 => 35,  149 => 33,  140 => 32,  126 => 27,  123 => 26,  121 => 25,  118 => 24,  109 => 22,  101 => 19,  95 => 16,  91 => 15,  83 => 10,  79 => 9,  75 => 7,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'blog_index' %}

{% block main %}
    {% for post in posts %}
        <article class=\"post\">
            <h2>
                <a href=\"{{ path('blog_post', { slug: post.slug }) }}\">
                    {{ post.title }}
                </a>
            </h2>

            <p class=\"post-metadata\">
                <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}</span>
                <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.author.email }}</span>
            </p>

            {{ post.summary|md2html }}
        </article>
    {% else %}
        <div class=\"well\">{{ 'post.no_posts_found'|trans }}</div>
    {% endfor %}

    {% if posts.haveToPaginate %}
        <div class=\"navigation text-center\">
            {{ pagerfanta(posts, 'twitter_bootstrap3_translated', { routeName: 'blog_index_paginated' }) }}
        </div>
    {% endif %}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
    {{ include('blog/_rss.html.twig') }}
{% endblock %}
", ":blog:index.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/blog/index.html.twig");
    }
}
