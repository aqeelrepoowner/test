<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_4efc1951613568edd8edfe3e3bd115dcdbc592969b2e9eadb83eee3594e3f9bf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_720cdaba5af3913e74127e0341b3ab81bbbb3f05108171dbc9489dbf025b158c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_720cdaba5af3913e74127e0341b3ab81bbbb3f05108171dbc9489dbf025b158c->enter($__internal_720cdaba5af3913e74127e0341b3ab81bbbb3f05108171dbc9489dbf025b158c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        $__internal_1178ee6dabe7a1123f1bb122866fda0cc064ddfc86d97007fbba034687275b49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1178ee6dabe7a1123f1bb122866fda0cc064ddfc86d97007fbba034687275b49->enter($__internal_1178ee6dabe7a1123f1bb122866fda0cc064ddfc86d97007fbba034687275b49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_720cdaba5af3913e74127e0341b3ab81bbbb3f05108171dbc9489dbf025b158c->leave($__internal_720cdaba5af3913e74127e0341b3ab81bbbb3f05108171dbc9489dbf025b158c_prof);

        
        $__internal_1178ee6dabe7a1123f1bb122866fda0cc064ddfc86d97007fbba034687275b49->leave($__internal_1178ee6dabe7a1123f1bb122866fda0cc064ddfc86d97007fbba034687275b49_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'button_widget', array('type' => isset(\$type) ? \$type : 'reset')) ?>
", "@Framework/Form/reset_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\reset_widget.html.php");
    }
}
