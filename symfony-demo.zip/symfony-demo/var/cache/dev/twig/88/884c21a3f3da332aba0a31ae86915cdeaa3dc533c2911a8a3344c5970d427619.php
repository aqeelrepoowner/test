<?php

/* blog/_rss.html.twig */
class __TwigTemplate_08bfda300bb591c2406b7b5080c00061bcd54eab3faebeedf37dfe9e977fdcff extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_50da91b1b6ee7ad8e0e28e81aa4cd97a72aebb5782b3a4faed452d87c9fbacec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_50da91b1b6ee7ad8e0e28e81aa4cd97a72aebb5782b3a4faed452d87c9fbacec->enter($__internal_50da91b1b6ee7ad8e0e28e81aa4cd97a72aebb5782b3a4faed452d87c9fbacec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/_rss.html.twig"));

        $__internal_1cf96d52cd8a0b9d83c68c31da3a2d83bf91de92dc076cff74c67d89a9f983d2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1cf96d52cd8a0b9d83c68c31da3a2d83bf91de92dc076cff74c67d89a9f983d2->enter($__internal_1cf96d52cd8a0b9d83c68c31da3a2d83bf91de92dc076cff74c67d89a9f983d2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/_rss.html.twig"));

        // line 1
        echo "<div class=\"section rss\">
    <a href=\"";
        // line 2
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> ";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.rss"), "html", null, true);
        echo "
    </a>
</div>
";
        
        $__internal_50da91b1b6ee7ad8e0e28e81aa4cd97a72aebb5782b3a4faed452d87c9fbacec->leave($__internal_50da91b1b6ee7ad8e0e28e81aa4cd97a72aebb5782b3a4faed452d87c9fbacec_prof);

        
        $__internal_1cf96d52cd8a0b9d83c68c31da3a2d83bf91de92dc076cff74c67d89a9f983d2->leave($__internal_1cf96d52cd8a0b9d83c68c31da3a2d83bf91de92dc076cff74c67d89a9f983d2_prof);

    }

    public function getTemplateName()
    {
        return "blog/_rss.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"section rss\">
    <a href=\"{{ path('blog_rss') }}\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> {{ 'menu.rss'|trans }}
    </a>
</div>
", "blog/_rss.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\blog\\_rss.html.twig");
    }
}
