<?php

/* security/login.html.twig */
class __TwigTemplate_8b2bdae3976e8602120a8a6f7515294e5f4f8227a978c3be2f587173b1aa5ac7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "security/login.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_352277105776789c42f8e534a1c0444c52e7393a0548d1fa29c8ae8f6438bcf2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_352277105776789c42f8e534a1c0444c52e7393a0548d1fa29c8ae8f6438bcf2->enter($__internal_352277105776789c42f8e534a1c0444c52e7393a0548d1fa29c8ae8f6438bcf2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $__internal_d9fc461173ac40c8ee74b0fa6d90c62b37c3d160843f3179fd282cf938953f7a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9fc461173ac40c8ee74b0fa6d90c62b37c3d160843f3179fd282cf938953f7a->enter($__internal_d9fc461173ac40c8ee74b0fa6d90c62b37c3d160843f3179fd282cf938953f7a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "security/login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_352277105776789c42f8e534a1c0444c52e7393a0548d1fa29c8ae8f6438bcf2->leave($__internal_352277105776789c42f8e534a1c0444c52e7393a0548d1fa29c8ae8f6438bcf2_prof);

        
        $__internal_d9fc461173ac40c8ee74b0fa6d90c62b37c3d160843f3179fd282cf938953f7a->leave($__internal_d9fc461173ac40c8ee74b0fa6d90c62b37c3d160843f3179fd282cf938953f7a_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_d6196955d9023903a0b5d3fe760e07d0ce2947245030f36e29486fb6467c3b55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d6196955d9023903a0b5d3fe760e07d0ce2947245030f36e29486fb6467c3b55->enter($__internal_d6196955d9023903a0b5d3fe760e07d0ce2947245030f36e29486fb6467c3b55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_028a182e40c07a43b83716b13e05adb5e546009435fea8f0294214396ec9838e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_028a182e40c07a43b83716b13e05adb5e546009435fea8f0294214396ec9838e->enter($__internal_028a182e40c07a43b83716b13e05adb5e546009435fea8f0294214396ec9838e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "login";
        
        $__internal_028a182e40c07a43b83716b13e05adb5e546009435fea8f0294214396ec9838e->leave($__internal_028a182e40c07a43b83716b13e05adb5e546009435fea8f0294214396ec9838e_prof);

        
        $__internal_d6196955d9023903a0b5d3fe760e07d0ce2947245030f36e29486fb6467c3b55->leave($__internal_d6196955d9023903a0b5d3fe760e07d0ce2947245030f36e29486fb6467c3b55_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_11572130a8d790c082fe07bb44502c6e35187933be41ead4a4e10372db3e54f0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_11572130a8d790c082fe07bb44502c6e35187933be41ead4a4e10372db3e54f0->enter($__internal_11572130a8d790c082fe07bb44502c6e35187933be41ead4a4e10372db3e54f0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_277f9320e9d40ab5da84e95cdb66d6dd580f4ae3b52dcab533728ad34957e556 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_277f9320e9d40ab5da84e95cdb66d6dd580f4ae3b52dcab533728ad34957e556->enter($__internal_277f9320e9d40ab5da84e95cdb66d6dd580f4ae3b52dcab533728ad34957e556_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    ";
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 7
            echo "        <div class=\"alert alert-danger\">
            ";
            // line 8
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 11
        echo "
    <div class=\"row\">
        <div class=\"col-sm-5\">
            <div class=\"well\">
                <form action=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
        echo "\" method=\"post\">
                    <fieldset>
                        <legend><i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.login"), "html", null, true);
        echo "</legend>
                        <div class=\"form-group\">
                            <label for=\"username\">";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.username"), "html", null, true);
        echo "</label>
                            <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" class=\"form-control\"/>
                        </div>
                        <div class=\"form-group\">
                            <label for=\"password\">";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.password"), "html", null, true);
        echo "</label>
                            <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"/>
                        <button type=\"submit\" class=\"btn btn-primary\">
                            <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> ";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.sign_in"), "html", null, true);
        echo "
                        </button>
                    </fieldset>
                </form>
            </div>
        </div>

        <div id=\"login-help\" class=\"col-sm-7\">
            <h3>
                <i class=\"fa fa-long-arrow-left\" aria-hidden=\"true\"></i>
                ";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.login_users"), "html", null, true);
        echo "
            </h3>

            <table class=\"table table-striped table-bordered table-hover\">
                <thead>
                    <tr>
                        <th scope=\"col\">";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.username"), "html", null, true);
        echo "</th>
                        <th scope=\"col\">";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.password"), "html", null, true);
        echo "</th>
                        <th scope=\"col\">";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.role"), "html", null, true);
        echo "</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>john_user</td>
                        <td>kitten</td>
                        <td><code>ROLE_USER</code> (";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.role_user"), "html", null, true);
        echo ")</td>
                    </tr>
                    <tr>
                        <td>anna_admin</td>
                        <td>kitten</td>
                        <td><code>ROLE_ADMIN</code> (";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.role_admin"), "html", null, true);
        echo ")</td>
                    </tr>
                </tbody>
            </table>

            <div id=\"login-users-help\" class=\"panel panel-default\">
                <div class=\"panel-body\">
                    <p>
                        <span class=\"label label-success\">";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("note"), "html", null, true);
        echo "</span>
                        ";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.reload_fixtures"), "html", null, true);
        echo "<br/>

                        <code class=\"console\">\$ php bin/console doctrine:fixtures:load</code>
                    </p>

                    <p>
                        <span class=\"label label-success\">";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("tip"), "html", null, true);
        echo "</span>
                        ";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.add_user"), "html", null, true);
        echo "<br/>

                        <code class=\"console\">\$ php bin/console app:add-user</code>
                    </p>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_277f9320e9d40ab5da84e95cdb66d6dd580f4ae3b52dcab533728ad34957e556->leave($__internal_277f9320e9d40ab5da84e95cdb66d6dd580f4ae3b52dcab533728ad34957e556_prof);

        
        $__internal_11572130a8d790c082fe07bb44502c6e35187933be41ead4a4e10372db3e54f0->leave($__internal_11572130a8d790c082fe07bb44502c6e35187933be41ead4a4e10372db3e54f0_prof);

    }

    // line 84
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_6cb51ae1a4de504c535da0c04b7374bb75643c72f85c57fb1b52d1ac97fe1d1c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cb51ae1a4de504c535da0c04b7374bb75643c72f85c57fb1b52d1ac97fe1d1c->enter($__internal_6cb51ae1a4de504c535da0c04b7374bb75643c72f85c57fb1b52d1ac97fe1d1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_ea660b4b434a30625d8ee4347866e91f30f234cb06656f9c560e8746ca776d54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ea660b4b434a30625d8ee4347866e91f30f234cb06656f9c560e8746ca776d54->enter($__internal_ea660b4b434a30625d8ee4347866e91f30f234cb06656f9c560e8746ca776d54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 85
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 87
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_ea660b4b434a30625d8ee4347866e91f30f234cb06656f9c560e8746ca776d54->leave($__internal_ea660b4b434a30625d8ee4347866e91f30f234cb06656f9c560e8746ca776d54_prof);

        
        $__internal_6cb51ae1a4de504c535da0c04b7374bb75643c72f85c57fb1b52d1ac97fe1d1c->leave($__internal_6cb51ae1a4de504c535da0c04b7374bb75643c72f85c57fb1b52d1ac97fe1d1c_prof);

    }

    // line 90
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b723f4321458b468f1b94e4bba3b33cfce37fdb6cd788e6ff4808e45db3b295c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b723f4321458b468f1b94e4bba3b33cfce37fdb6cd788e6ff4808e45db3b295c->enter($__internal_b723f4321458b468f1b94e4bba3b33cfce37fdb6cd788e6ff4808e45db3b295c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_60598a26f632716484156af64b40749a4bccabb227304d24f3ad390ba520d03a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_60598a26f632716484156af64b40749a4bccabb227304d24f3ad390ba520d03a->enter($__internal_60598a26f632716484156af64b40749a4bccabb227304d24f3ad390ba520d03a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 91
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

    <script>
        \$(document).ready(function() {
            var usernameEl = \$('#username');
            var passwordEl = \$('#password');
            // in a real application, hardcoding the user/password would be idiotic
            // but for the demo application it's very convenient to do so
            if (!usernameEl.val() && !passwordEl.val()) {
                usernameEl.val('anna_admin');
                passwordEl.val('kitten');
            }
        });
    </script>
";
        
        $__internal_60598a26f632716484156af64b40749a4bccabb227304d24f3ad390ba520d03a->leave($__internal_60598a26f632716484156af64b40749a4bccabb227304d24f3ad390ba520d03a_prof);

        
        $__internal_b723f4321458b468f1b94e4bba3b33cfce37fdb6cd788e6ff4808e45db3b295c->leave($__internal_b723f4321458b468f1b94e4bba3b33cfce37fdb6cd788e6ff4808e45db3b295c_prof);

    }

    public function getTemplateName()
    {
        return "security/login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  250 => 91,  241 => 90,  229 => 87,  223 => 85,  214 => 84,  195 => 74,  191 => 73,  182 => 67,  178 => 66,  167 => 58,  159 => 53,  149 => 46,  145 => 45,  141 => 44,  132 => 38,  119 => 28,  114 => 26,  108 => 23,  102 => 20,  98 => 19,  93 => 17,  88 => 15,  82 => 11,  76 => 8,  73 => 7,  70 => 6,  61 => 5,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'login' %}

{% block main %}
    {% if error %}
        <div class=\"alert alert-danger\">
            {{ error.messageKey|trans(error.messageData, 'security') }}
        </div>
    {% endif %}

    <div class=\"row\">
        <div class=\"col-sm-5\">
            <div class=\"well\">
                <form action=\"{{ path('security_login') }}\" method=\"post\">
                    <fieldset>
                        <legend><i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'title.login'|trans }}</legend>
                        <div class=\"form-group\">
                            <label for=\"username\">{{ 'label.username'|trans }}</label>
                            <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" class=\"form-control\"/>
                        </div>
                        <div class=\"form-group\">
                            <label for=\"password\">{{ 'label.password'|trans }}</label>
                            <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\"/>
                        <button type=\"submit\" class=\"btn btn-primary\">
                            <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> {{ 'action.sign_in'|trans }}
                        </button>
                    </fieldset>
                </form>
            </div>
        </div>

        <div id=\"login-help\" class=\"col-sm-7\">
            <h3>
                <i class=\"fa fa-long-arrow-left\" aria-hidden=\"true\"></i>
                {{ 'help.login_users'|trans }}
            </h3>

            <table class=\"table table-striped table-bordered table-hover\">
                <thead>
                    <tr>
                        <th scope=\"col\">{{ 'label.username'|trans }}</th>
                        <th scope=\"col\">{{ 'label.password'|trans }}</th>
                        <th scope=\"col\">{{ 'label.role'|trans }}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>john_user</td>
                        <td>kitten</td>
                        <td><code>ROLE_USER</code> ({{ 'help.role_user'|trans }})</td>
                    </tr>
                    <tr>
                        <td>anna_admin</td>
                        <td>kitten</td>
                        <td><code>ROLE_ADMIN</code> ({{ 'help.role_admin'|trans }})</td>
                    </tr>
                </tbody>
            </table>

            <div id=\"login-users-help\" class=\"panel panel-default\">
                <div class=\"panel-body\">
                    <p>
                        <span class=\"label label-success\">{{ 'note'|trans }}</span>
                        {{ 'help.reload_fixtures'|trans }}<br/>

                        <code class=\"console\">\$ php bin/console doctrine:fixtures:load</code>
                    </p>

                    <p>
                        <span class=\"label label-success\">{{ 'tip'|trans }}</span>
                        {{ 'help.add_user'|trans }}<br/>

                        <code class=\"console\">\$ php bin/console app:add-user</code>
                    </p>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}

{% block javascripts %}
    {{ parent() }}

    <script>
        \$(document).ready(function() {
            var usernameEl = \$('#username');
            var passwordEl = \$('#password');
            // in a real application, hardcoding the user/password would be idiotic
            // but for the demo application it's very convenient to do so
            if (!usernameEl.val() && !passwordEl.val()) {
                usernameEl.val('anna_admin');
                passwordEl.val('kitten');
            }
        });
    </script>
{% endblock %}
", "security/login.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\security\\login.html.twig");
    }
}
