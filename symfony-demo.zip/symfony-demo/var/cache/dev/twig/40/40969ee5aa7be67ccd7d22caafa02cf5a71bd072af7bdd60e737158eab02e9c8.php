<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_a5852af887673387f648226004773b757bf0fef5736150eb6f9e4e91eaafa99f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e46492d3f47bce1437037b34bc4581163f9354dda35d297627acbe61f9602877 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e46492d3f47bce1437037b34bc4581163f9354dda35d297627acbe61f9602877->enter($__internal_e46492d3f47bce1437037b34bc4581163f9354dda35d297627acbe61f9602877_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        $__internal_3fafcf807db5e81c8f9e84661e3b26fe57698e9af714b680d5c2ecd38c701fd4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3fafcf807db5e81c8f9e84661e3b26fe57698e9af714b680d5c2ecd38c701fd4->enter($__internal_3fafcf807db5e81c8f9e84661e3b26fe57698e9af714b680d5c2ecd38c701fd4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_e46492d3f47bce1437037b34bc4581163f9354dda35d297627acbe61f9602877->leave($__internal_e46492d3f47bce1437037b34bc4581163f9354dda35d297627acbe61f9602877_prof);

        
        $__internal_3fafcf807db5e81c8f9e84661e3b26fe57698e9af714b680d5c2ecd38c701fd4->leave($__internal_3fafcf807db5e81c8f9e84661e3b26fe57698e9af714b680d5c2ecd38c701fd4_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
", "@Framework/Form/collection_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\collection_widget.html.php");
    }
}
