<?php

/* @Framework/Form/url_widget.html.php */
class __TwigTemplate_b1bd5deb0b4f50c2268ce56d9659836a39d488a4c7724d5d2323606560d75fda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4b7329e5d693005ea0458f60889257eec07f3a1a4ec0fe9db2fd86b32657dda0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b7329e5d693005ea0458f60889257eec07f3a1a4ec0fe9db2fd86b32657dda0->enter($__internal_4b7329e5d693005ea0458f60889257eec07f3a1a4ec0fe9db2fd86b32657dda0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        $__internal_455c4cddb2b2eb3a6ad4e5069a412539112f65d3834795f08433910db88807cd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_455c4cddb2b2eb3a6ad4e5069a412539112f65d3834795f08433910db88807cd->enter($__internal_455c4cddb2b2eb3a6ad4e5069a412539112f65d3834795f08433910db88807cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/url_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
";
        
        $__internal_4b7329e5d693005ea0458f60889257eec07f3a1a4ec0fe9db2fd86b32657dda0->leave($__internal_4b7329e5d693005ea0458f60889257eec07f3a1a4ec0fe9db2fd86b32657dda0_prof);

        
        $__internal_455c4cddb2b2eb3a6ad4e5069a412539112f65d3834795f08433910db88807cd->leave($__internal_455c4cddb2b2eb3a6ad4e5069a412539112f65d3834795f08433910db88807cd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/url_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'url')) ?>
", "@Framework/Form/url_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\url_widget.html.php");
    }
}
