<?php

/* @Twig/Exception/error.css.twig */
class __TwigTemplate_905dfe137ce16b5e8b709b4929b130981d4dafe4f6927098fb506f89019b6ea8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4054be4dfd878d4a5c5679ccc0e2b404404875d1f569baf5a6e4754a6a25b7bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4054be4dfd878d4a5c5679ccc0e2b404404875d1f569baf5a6e4754a6a25b7bd->enter($__internal_4054be4dfd878d4a5c5679ccc0e2b404404875d1f569baf5a6e4754a6a25b7bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        $__internal_ca982a8b4a90597982cd592044494f772dc0ccc2c46b112333cfc7977f8f77c3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca982a8b4a90597982cd592044494f772dc0ccc2c46b112333cfc7977f8f77c3->enter($__internal_ca982a8b4a90597982cd592044494f772dc0ccc2c46b112333cfc7977f8f77c3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "css", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "css", null, true);
        echo "

*/
";
        
        $__internal_4054be4dfd878d4a5c5679ccc0e2b404404875d1f569baf5a6e4754a6a25b7bd->leave($__internal_4054be4dfd878d4a5c5679ccc0e2b404404875d1f569baf5a6e4754a6a25b7bd_prof);

        
        $__internal_ca982a8b4a90597982cd592044494f772dc0ccc2c46b112333cfc7977f8f77c3->leave($__internal_ca982a8b4a90597982cd592044494f772dc0ccc2c46b112333cfc7977f8f77c3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "@Twig/Exception/error.css.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.css.twig");
    }
}
