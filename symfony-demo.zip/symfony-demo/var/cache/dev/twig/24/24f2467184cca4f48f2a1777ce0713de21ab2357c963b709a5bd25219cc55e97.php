<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_15f113be29af0ede34f3db72441e58eaf17f85d251c070b4744114a0350d1c17 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51b4a634eb87d935032f778c3d1b979edc35fdf2a22c7c2c8b0aef91fde6bfff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51b4a634eb87d935032f778c3d1b979edc35fdf2a22c7c2c8b0aef91fde6bfff->enter($__internal_51b4a634eb87d935032f778c3d1b979edc35fdf2a22c7c2c8b0aef91fde6bfff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        $__internal_845f3f71dde0f431052e30826cefa8b8f70eb61c6849c6a857e3f623b4c4f33c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_845f3f71dde0f431052e30826cefa8b8f70eb61c6849c6a857e3f623b4c4f33c->enter($__internal_845f3f71dde0f431052e30826cefa8b8f70eb61c6849c6a857e3f623b4c4f33c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_51b4a634eb87d935032f778c3d1b979edc35fdf2a22c7c2c8b0aef91fde6bfff->leave($__internal_51b4a634eb87d935032f778c3d1b979edc35fdf2a22c7c2c8b0aef91fde6bfff_prof);

        
        $__internal_845f3f71dde0f431052e30826cefa8b8f70eb61c6849c6a857e3f623b4c4f33c->leave($__internal_845f3f71dde0f431052e30826cefa8b8f70eb61c6849c6a857e3f623b4c4f33c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->widget(\$form) ?>
", "@Framework/Form/hidden_row.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_row.html.php");
    }
}
