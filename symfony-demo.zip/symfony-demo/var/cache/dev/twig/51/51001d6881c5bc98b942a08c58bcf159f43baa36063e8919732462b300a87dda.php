<?php

/* @WebProfiler/Profiler/toolbar_redirect.html.twig */
class __TwigTemplate_5a569557d020a5d8033262384ca0cba193aa54e7f3ec9ad938dc483fa5d26194 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@WebProfiler/Profiler/toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_df6b53494cb601c6b643af09c6b87d6705a44608372c1ed32661a70cbcae34b3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_df6b53494cb601c6b643af09c6b87d6705a44608372c1ed32661a70cbcae34b3->enter($__internal_df6b53494cb601c6b643af09c6b87d6705a44608372c1ed32661a70cbcae34b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $__internal_5ffcae510cbb88927d638fe6a9bde8f9bcd36d9b2224af8d94aadf7df616dab9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5ffcae510cbb88927d638fe6a9bde8f9bcd36d9b2224af8d94aadf7df616dab9->enter($__internal_5ffcae510cbb88927d638fe6a9bde8f9bcd36d9b2224af8d94aadf7df616dab9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_df6b53494cb601c6b643af09c6b87d6705a44608372c1ed32661a70cbcae34b3->leave($__internal_df6b53494cb601c6b643af09c6b87d6705a44608372c1ed32661a70cbcae34b3_prof);

        
        $__internal_5ffcae510cbb88927d638fe6a9bde8f9bcd36d9b2224af8d94aadf7df616dab9->leave($__internal_5ffcae510cbb88927d638fe6a9bde8f9bcd36d9b2224af8d94aadf7df616dab9_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_7ece0e539b76bd02590d9fadeeeb815a78861cb379fa56eccefc097bd53720f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ece0e539b76bd02590d9fadeeeb815a78861cb379fa56eccefc097bd53720f8->enter($__internal_7ece0e539b76bd02590d9fadeeeb815a78861cb379fa56eccefc097bd53720f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e559061836bec2a894ad2ceab7aa453031c30a55c589a6819c90cf96200bb989 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e559061836bec2a894ad2ceab7aa453031c30a55c589a6819c90cf96200bb989->enter($__internal_e559061836bec2a894ad2ceab7aa453031c30a55c589a6819c90cf96200bb989_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_e559061836bec2a894ad2ceab7aa453031c30a55c589a6819c90cf96200bb989->leave($__internal_e559061836bec2a894ad2ceab7aa453031c30a55c589a6819c90cf96200bb989_prof);

        
        $__internal_7ece0e539b76bd02590d9fadeeeb815a78861cb379fa56eccefc097bd53720f8->leave($__internal_7ece0e539b76bd02590d9fadeeeb815a78861cb379fa56eccefc097bd53720f8_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_c202a3eafd48d105ea03891a5167a1b3d1143d01e7941d61a97815cc51e449a1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c202a3eafd48d105ea03891a5167a1b3d1143d01e7941d61a97815cc51e449a1->enter($__internal_c202a3eafd48d105ea03891a5167a1b3d1143d01e7941d61a97815cc51e449a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_83390fcb5d48f7f812fa4fe58d9052c08c0c13912bf72e0b0ff9b4b5a861a684 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_83390fcb5d48f7f812fa4fe58d9052c08c0c13912bf72e0b0ff9b4b5a861a684->enter($__internal_83390fcb5d48f7f812fa4fe58d9052c08c0c13912bf72e0b0ff9b4b5a861a684_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_83390fcb5d48f7f812fa4fe58d9052c08c0c13912bf72e0b0ff9b4b5a861a684->leave($__internal_83390fcb5d48f7f812fa4fe58d9052c08c0c13912bf72e0b0ff9b4b5a861a684_prof);

        
        $__internal_c202a3eafd48d105ea03891a5167a1b3d1143d01e7941d61a97815cc51e449a1->leave($__internal_c202a3eafd48d105ea03891a5167a1b3d1143d01e7941d61a97815cc51e449a1_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "@WebProfiler/Profiler/toolbar_redirect.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\toolbar_redirect.html.twig");
    }
}
