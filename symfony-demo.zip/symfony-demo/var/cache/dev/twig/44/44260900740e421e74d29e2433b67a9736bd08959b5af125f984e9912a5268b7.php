<?php

/* :security:login.html.twig */
class __TwigTemplate_7a61c3e3e18851a7d5f3c32f161ce4fe370bbd4ab407f2ca8e8dcf2dee3f947e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":security:login.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c3c913360f45a95631747a6e765be3c6fd237253591540f2b65e17ac803f9c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9c3c913360f45a95631747a6e765be3c6fd237253591540f2b65e17ac803f9c7->enter($__internal_9c3c913360f45a95631747a6e765be3c6fd237253591540f2b65e17ac803f9c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":security:login.html.twig"));

        $__internal_8f7e20e73fe358ef098c30b18db426ff78847b87c1c7b094fa85354d128741e0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f7e20e73fe358ef098c30b18db426ff78847b87c1c7b094fa85354d128741e0->enter($__internal_8f7e20e73fe358ef098c30b18db426ff78847b87c1c7b094fa85354d128741e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":security:login.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c3c913360f45a95631747a6e765be3c6fd237253591540f2b65e17ac803f9c7->leave($__internal_9c3c913360f45a95631747a6e765be3c6fd237253591540f2b65e17ac803f9c7_prof);

        
        $__internal_8f7e20e73fe358ef098c30b18db426ff78847b87c1c7b094fa85354d128741e0->leave($__internal_8f7e20e73fe358ef098c30b18db426ff78847b87c1c7b094fa85354d128741e0_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_98d1170123ced935f76d6256817f18145a48919e6c569381aa0b94507a758f0d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98d1170123ced935f76d6256817f18145a48919e6c569381aa0b94507a758f0d->enter($__internal_98d1170123ced935f76d6256817f18145a48919e6c569381aa0b94507a758f0d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_7ecb092f0d748082a70f1cf22b6188c9128012bfd6cc1c89dd1b22e31f772403 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7ecb092f0d748082a70f1cf22b6188c9128012bfd6cc1c89dd1b22e31f772403->enter($__internal_7ecb092f0d748082a70f1cf22b6188c9128012bfd6cc1c89dd1b22e31f772403_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "login";
        
        $__internal_7ecb092f0d748082a70f1cf22b6188c9128012bfd6cc1c89dd1b22e31f772403->leave($__internal_7ecb092f0d748082a70f1cf22b6188c9128012bfd6cc1c89dd1b22e31f772403_prof);

        
        $__internal_98d1170123ced935f76d6256817f18145a48919e6c569381aa0b94507a758f0d->leave($__internal_98d1170123ced935f76d6256817f18145a48919e6c569381aa0b94507a758f0d_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_46e875ebe5a8b88a707402e2b7fccbe0fe955ec8eb891173a61c8df0cdd0f137 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46e875ebe5a8b88a707402e2b7fccbe0fe955ec8eb891173a61c8df0cdd0f137->enter($__internal_46e875ebe5a8b88a707402e2b7fccbe0fe955ec8eb891173a61c8df0cdd0f137_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_b8f5e77d84ed931e2408276ef2645faaee1f78bb3210607b03290db97b95fae0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b8f5e77d84ed931e2408276ef2645faaee1f78bb3210607b03290db97b95fae0->enter($__internal_b8f5e77d84ed931e2408276ef2645faaee1f78bb3210607b03290db97b95fae0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    ";
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 7
            echo "        <div class=\"alert alert-danger\">
            ";
            // line 8
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageKey", array()), $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "messageData", array()), "security"), "html", null, true);
            echo "
        </div>
    ";
        }
        // line 11
        echo "
    <div class=\"row\">
        <div class=\"col-sm-5\">
            <div class=\"well\">
                <form action=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
        echo "\" method=\"post\">
                    <fieldset>
                        <legend><i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.login"), "html", null, true);
        echo "</legend>
                        <div class=\"form-group\">
                            <label for=\"username\">";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.username"), "html", null, true);
        echo "</label>
                            <input type=\"text\" id=\"username\" name=\"_username\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" class=\"form-control\"/>
                        </div>
                        <div class=\"form-group\">
                            <label for=\"password\">";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.password"), "html", null, true);
        echo "</label>
                            <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\"/>
                        <button type=\"submit\" class=\"btn btn-primary\">
                            <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> ";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.sign_in"), "html", null, true);
        echo "
                        </button>
                    </fieldset>
                </form>
            </div>
        </div>

        <div id=\"login-help\" class=\"col-sm-7\">
            <h3>
                <i class=\"fa fa-long-arrow-left\" aria-hidden=\"true\"></i>
                ";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.login_users"), "html", null, true);
        echo "
            </h3>

            <table class=\"table table-striped table-bordered table-hover\">
                <thead>
                    <tr>
                        <th scope=\"col\">";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.username"), "html", null, true);
        echo "</th>
                        <th scope=\"col\">";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.password"), "html", null, true);
        echo "</th>
                        <th scope=\"col\">";
        // line 46
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.role"), "html", null, true);
        echo "</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>john_user</td>
                        <td>kitten</td>
                        <td><code>ROLE_USER</code> (";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.role_user"), "html", null, true);
        echo ")</td>
                    </tr>
                    <tr>
                        <td>anna_admin</td>
                        <td>kitten</td>
                        <td><code>ROLE_ADMIN</code> (";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.role_admin"), "html", null, true);
        echo ")</td>
                    </tr>
                </tbody>
            </table>

            <div id=\"login-users-help\" class=\"panel panel-default\">
                <div class=\"panel-body\">
                    <p>
                        <span class=\"label label-success\">";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("note"), "html", null, true);
        echo "</span>
                        ";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.reload_fixtures"), "html", null, true);
        echo "<br/>

                        <code class=\"console\">\$ php bin/console doctrine:fixtures:load</code>
                    </p>

                    <p>
                        <span class=\"label label-success\">";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("tip"), "html", null, true);
        echo "</span>
                        ";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.add_user"), "html", null, true);
        echo "<br/>

                        <code class=\"console\">\$ php bin/console app:add-user</code>
                    </p>
                </div>
            </div>
        </div>
    </div>
";
        
        $__internal_b8f5e77d84ed931e2408276ef2645faaee1f78bb3210607b03290db97b95fae0->leave($__internal_b8f5e77d84ed931e2408276ef2645faaee1f78bb3210607b03290db97b95fae0_prof);

        
        $__internal_46e875ebe5a8b88a707402e2b7fccbe0fe955ec8eb891173a61c8df0cdd0f137->leave($__internal_46e875ebe5a8b88a707402e2b7fccbe0fe955ec8eb891173a61c8df0cdd0f137_prof);

    }

    // line 84
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_3a97553b23d4646a94e311a350fbdee045767309b85ed46932957e11376db7f7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3a97553b23d4646a94e311a350fbdee045767309b85ed46932957e11376db7f7->enter($__internal_3a97553b23d4646a94e311a350fbdee045767309b85ed46932957e11376db7f7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_263fcca2f87e2698ff74498bd4323af47fc38649711d84e5d851162f97379699 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_263fcca2f87e2698ff74498bd4323af47fc38649711d84e5d851162f97379699->enter($__internal_263fcca2f87e2698ff74498bd4323af47fc38649711d84e5d851162f97379699_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 85
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 87
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_263fcca2f87e2698ff74498bd4323af47fc38649711d84e5d851162f97379699->leave($__internal_263fcca2f87e2698ff74498bd4323af47fc38649711d84e5d851162f97379699_prof);

        
        $__internal_3a97553b23d4646a94e311a350fbdee045767309b85ed46932957e11376db7f7->leave($__internal_3a97553b23d4646a94e311a350fbdee045767309b85ed46932957e11376db7f7_prof);

    }

    // line 90
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_37b7047ed4c030356b7ef25f56d9018abe199ccdd21478232f17abe24baea3f4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37b7047ed4c030356b7ef25f56d9018abe199ccdd21478232f17abe24baea3f4->enter($__internal_37b7047ed4c030356b7ef25f56d9018abe199ccdd21478232f17abe24baea3f4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_11acdf78b21af8b5a009bfb9a5cdec79886199e680257779cfe306f3d2b13f64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_11acdf78b21af8b5a009bfb9a5cdec79886199e680257779cfe306f3d2b13f64->enter($__internal_11acdf78b21af8b5a009bfb9a5cdec79886199e680257779cfe306f3d2b13f64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 91
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "

    <script>
        \$(document).ready(function() {
            var usernameEl = \$('#username');
            var passwordEl = \$('#password');
            // in a real application, hardcoding the user/password would be idiotic
            // but for the demo application it's very convenient to do so
            if (!usernameEl.val() && !passwordEl.val()) {
                usernameEl.val('anna_admin');
                passwordEl.val('kitten');
            }
        });
    </script>
";
        
        $__internal_11acdf78b21af8b5a009bfb9a5cdec79886199e680257779cfe306f3d2b13f64->leave($__internal_11acdf78b21af8b5a009bfb9a5cdec79886199e680257779cfe306f3d2b13f64_prof);

        
        $__internal_37b7047ed4c030356b7ef25f56d9018abe199ccdd21478232f17abe24baea3f4->leave($__internal_37b7047ed4c030356b7ef25f56d9018abe199ccdd21478232f17abe24baea3f4_prof);

    }

    public function getTemplateName()
    {
        return ":security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  250 => 91,  241 => 90,  229 => 87,  223 => 85,  214 => 84,  195 => 74,  191 => 73,  182 => 67,  178 => 66,  167 => 58,  159 => 53,  149 => 46,  145 => 45,  141 => 44,  132 => 38,  119 => 28,  114 => 26,  108 => 23,  102 => 20,  98 => 19,  93 => 17,  88 => 15,  82 => 11,  76 => 8,  73 => 7,  70 => 6,  61 => 5,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'login' %}

{% block main %}
    {% if error %}
        <div class=\"alert alert-danger\">
            {{ error.messageKey|trans(error.messageData, 'security') }}
        </div>
    {% endif %}

    <div class=\"row\">
        <div class=\"col-sm-5\">
            <div class=\"well\">
                <form action=\"{{ path('security_login') }}\" method=\"post\">
                    <fieldset>
                        <legend><i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'title.login'|trans }}</legend>
                        <div class=\"form-group\">
                            <label for=\"username\">{{ 'label.username'|trans }}</label>
                            <input type=\"text\" id=\"username\" name=\"_username\" value=\"{{ last_username }}\" class=\"form-control\"/>
                        </div>
                        <div class=\"form-group\">
                            <label for=\"password\">{{ 'label.password'|trans }}</label>
                            <input type=\"password\" id=\"password\" name=\"_password\" class=\"form-control\" />
                        </div>
                        <input type=\"hidden\" name=\"_csrf_token\" value=\"{{ csrf_token('authenticate') }}\"/>
                        <button type=\"submit\" class=\"btn btn-primary\">
                            <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> {{ 'action.sign_in'|trans }}
                        </button>
                    </fieldset>
                </form>
            </div>
        </div>

        <div id=\"login-help\" class=\"col-sm-7\">
            <h3>
                <i class=\"fa fa-long-arrow-left\" aria-hidden=\"true\"></i>
                {{ 'help.login_users'|trans }}
            </h3>

            <table class=\"table table-striped table-bordered table-hover\">
                <thead>
                    <tr>
                        <th scope=\"col\">{{ 'label.username'|trans }}</th>
                        <th scope=\"col\">{{ 'label.password'|trans }}</th>
                        <th scope=\"col\">{{ 'label.role'|trans }}</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>john_user</td>
                        <td>kitten</td>
                        <td><code>ROLE_USER</code> ({{ 'help.role_user'|trans }})</td>
                    </tr>
                    <tr>
                        <td>anna_admin</td>
                        <td>kitten</td>
                        <td><code>ROLE_ADMIN</code> ({{ 'help.role_admin'|trans }})</td>
                    </tr>
                </tbody>
            </table>

            <div id=\"login-users-help\" class=\"panel panel-default\">
                <div class=\"panel-body\">
                    <p>
                        <span class=\"label label-success\">{{ 'note'|trans }}</span>
                        {{ 'help.reload_fixtures'|trans }}<br/>

                        <code class=\"console\">\$ php bin/console doctrine:fixtures:load</code>
                    </p>

                    <p>
                        <span class=\"label label-success\">{{ 'tip'|trans }}</span>
                        {{ 'help.add_user'|trans }}<br/>

                        <code class=\"console\">\$ php bin/console app:add-user</code>
                    </p>
                </div>
            </div>
        </div>
    </div>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}

{% block javascripts %}
    {{ parent() }}

    <script>
        \$(document).ready(function() {
            var usernameEl = \$('#username');
            var passwordEl = \$('#password');
            // in a real application, hardcoding the user/password would be idiotic
            // but for the demo application it's very convenient to do so
            if (!usernameEl.val() && !passwordEl.val()) {
                usernameEl.val('anna_admin');
                passwordEl.val('kitten');
            }
        });
    </script>
{% endblock %}
", ":security:login.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/security/login.html.twig");
    }
}
