<?php

/* TwigBundle:Exception:error404.html.twig */
class __TwigTemplate_98a4ff2fc282c2544268228e70ff3745dae6ae181741a0c68db31b3cb43ef57a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error404.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9a19b7985d1518515bc98d3609e39875ed37e3b4d05af0ed7b890fb10d40b00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f9a19b7985d1518515bc98d3609e39875ed37e3b4d05af0ed7b890fb10d40b00->enter($__internal_f9a19b7985d1518515bc98d3609e39875ed37e3b4d05af0ed7b890fb10d40b00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error404.html.twig"));

        $__internal_3983a3631ff556e520373351d02e7fbb379a3e46fe08f1deeb24dec9550c6487 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3983a3631ff556e520373351d02e7fbb379a3e46fe08f1deeb24dec9550c6487->enter($__internal_3983a3631ff556e520373351d02e7fbb379a3e46fe08f1deeb24dec9550c6487_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error404.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f9a19b7985d1518515bc98d3609e39875ed37e3b4d05af0ed7b890fb10d40b00->leave($__internal_f9a19b7985d1518515bc98d3609e39875ed37e3b4d05af0ed7b890fb10d40b00_prof);

        
        $__internal_3983a3631ff556e520373351d02e7fbb379a3e46fe08f1deeb24dec9550c6487->leave($__internal_3983a3631ff556e520373351d02e7fbb379a3e46fe08f1deeb24dec9550c6487_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_9f00862e0443cbc7cc490ae58315f7c42c337e53c4ead59cde7072ccf767a1e0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9f00862e0443cbc7cc490ae58315f7c42c337e53c4ead59cde7072ccf767a1e0->enter($__internal_9f00862e0443cbc7cc490ae58315f7c42c337e53c4ead59cde7072ccf767a1e0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_eaf2f5195bf8099e7e0c113bda710814b6b618e20aee109a4a135b369d1958a4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_eaf2f5195bf8099e7e0c113bda710814b6b618e20aee109a4a135b369d1958a4->enter($__internal_eaf2f5195bf8099e7e0c113bda710814b6b618e20aee109a4a135b369d1958a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_eaf2f5195bf8099e7e0c113bda710814b6b618e20aee109a4a135b369d1958a4->leave($__internal_eaf2f5195bf8099e7e0c113bda710814b6b618e20aee109a4a135b369d1958a4_prof);

        
        $__internal_9f00862e0443cbc7cc490ae58315f7c42c337e53c4ead59cde7072ccf767a1e0->leave($__internal_9f00862e0443cbc7cc490ae58315f7c42c337e53c4ead59cde7072ccf767a1e0_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_bc5b8c33e5c4f46e5404a75b51353d4d095d55562b8e53ef42001ac734c7fb55 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bc5b8c33e5c4f46e5404a75b51353d4d095d55562b8e53ef42001ac734c7fb55->enter($__internal_bc5b8c33e5c4f46e5404a75b51353d4d095d55562b8e53ef42001ac734c7fb55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_694670ebca4a798b464e061a6c39d04567924549f99a7f1b2fc68066f3b7b442 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_694670ebca4a798b464e061a6c39d04567924549f99a7f1b2fc68066f3b7b442->enter($__internal_694670ebca4a798b464e061a6c39d04567924549f99a7f1b2fc68066f3b7b442_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => 404)), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_404.description"), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_404.suggestion", array("%url%" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index")));
        echo "
    </p>
";
        
        $__internal_694670ebca4a798b464e061a6c39d04567924549f99a7f1b2fc68066f3b7b442->leave($__internal_694670ebca4a798b464e061a6c39d04567924549f99a7f1b2fc68066f3b7b442_prof);

        
        $__internal_bc5b8c33e5c4f46e5404a75b51353d4d095d55562b8e53ef42001ac734c7fb55->leave($__internal_bc5b8c33e5c4f46e5404a75b51353d4d095d55562b8e53ef42001ac734c7fb55_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_98f752224f82e54834255cd5807263390eb5ca662e8aee5a9dc4fa041f60c5a1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98f752224f82e54834255cd5807263390eb5ca662e8aee5a9dc4fa041f60c5a1->enter($__internal_98f752224f82e54834255cd5807263390eb5ca662e8aee5a9dc4fa041f60c5a1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_ad4919a1bda5d89f9bc9ad6f8e6db4100214de6e63ac2b62af60fe23575fbdc7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ad4919a1bda5d89f9bc9ad6f8e6db4100214de6e63ac2b62af60fe23575fbdc7->enter($__internal_ad4919a1bda5d89f9bc9ad6f8e6db4100214de6e63ac2b62af60fe23575fbdc7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_ad4919a1bda5d89f9bc9ad6f8e6db4100214de6e63ac2b62af60fe23575fbdc7->leave($__internal_ad4919a1bda5d89f9bc9ad6f8e6db4100214de6e63ac2b62af60fe23575fbdc7_prof);

        
        $__internal_98f752224f82e54834255cd5807263390eb5ca662e8aee5a9dc4fa041f60c5a1->leave($__internal_98f752224f82e54834255cd5807263390eb5ca662e8aee5a9dc4fa041f60c5a1_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render errors of type HTTP 404 (Not Found)

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See http://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'http_error.name'|trans({ '%status_code%': 404 }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error_404.description'|trans }}
    </p>
    <p>
        {{ 'http_error_404.suggestion'|trans({ '%url%': path('blog_index') })|raw }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error404.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources/TwigBundle/views/Exception/error404.html.twig");
    }
}
