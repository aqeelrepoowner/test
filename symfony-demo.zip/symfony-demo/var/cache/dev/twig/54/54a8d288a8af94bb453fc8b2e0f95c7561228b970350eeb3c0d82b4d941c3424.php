<?php

/* TwigBundle:Exception:error403.html.twig */
class __TwigTemplate_7a0b2633ab9da399d131f27a823aa61e276eef3a42138662ea9d466091b4fec2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 11
        $this->parent = $this->loadTemplate("base.html.twig", "TwigBundle:Exception:error403.html.twig", 11);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eb6f3ad2686dde31011c00f4e3d6e422698bd480a8cde3a2de6c09112021bcde = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb6f3ad2686dde31011c00f4e3d6e422698bd480a8cde3a2de6c09112021bcde->enter($__internal_eb6f3ad2686dde31011c00f4e3d6e422698bd480a8cde3a2de6c09112021bcde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error403.html.twig"));

        $__internal_8bc570c58f6f53b38d474177675fee41fc7705f720165eec5027621bbc0362cb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8bc570c58f6f53b38d474177675fee41fc7705f720165eec5027621bbc0362cb->enter($__internal_8bc570c58f6f53b38d474177675fee41fc7705f720165eec5027621bbc0362cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_eb6f3ad2686dde31011c00f4e3d6e422698bd480a8cde3a2de6c09112021bcde->leave($__internal_eb6f3ad2686dde31011c00f4e3d6e422698bd480a8cde3a2de6c09112021bcde_prof);

        
        $__internal_8bc570c58f6f53b38d474177675fee41fc7705f720165eec5027621bbc0362cb->leave($__internal_8bc570c58f6f53b38d474177675fee41fc7705f720165eec5027621bbc0362cb_prof);

    }

    // line 13
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_59346024b5c52d6d9b10c26b1165d5cb3260c18e2526596180e715868dd5a253 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_59346024b5c52d6d9b10c26b1165d5cb3260c18e2526596180e715868dd5a253->enter($__internal_59346024b5c52d6d9b10c26b1165d5cb3260c18e2526596180e715868dd5a253_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_f36dfc8d47d8217e33ef872cb3892f828f7b7ce47167f3fbe1e5c8df8d2c04e4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f36dfc8d47d8217e33ef872cb3892f828f7b7ce47167f3fbe1e5c8df8d2c04e4->enter($__internal_f36dfc8d47d8217e33ef872cb3892f828f7b7ce47167f3fbe1e5c8df8d2c04e4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "error";
        
        $__internal_f36dfc8d47d8217e33ef872cb3892f828f7b7ce47167f3fbe1e5c8df8d2c04e4->leave($__internal_f36dfc8d47d8217e33ef872cb3892f828f7b7ce47167f3fbe1e5c8df8d2c04e4_prof);

        
        $__internal_59346024b5c52d6d9b10c26b1165d5cb3260c18e2526596180e715868dd5a253->leave($__internal_59346024b5c52d6d9b10c26b1165d5cb3260c18e2526596180e715868dd5a253_prof);

    }

    // line 15
    public function block_main($context, array $blocks = array())
    {
        $__internal_e228ca13e1b15ddd9aa5a441f67a9a3508f3ea435d147ad531ed9f7707338060 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e228ca13e1b15ddd9aa5a441f67a9a3508f3ea435d147ad531ed9f7707338060->enter($__internal_e228ca13e1b15ddd9aa5a441f67a9a3508f3ea435d147ad531ed9f7707338060_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_48b56a9b27779f2ab9aed01d7075bb7cd744af6288bf726b55f00f47f4e1d953 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48b56a9b27779f2ab9aed01d7075bb7cd744af6288bf726b55f00f47f4e1d953->enter($__internal_48b56a9b27779f2ab9aed01d7075bb7cd744af6288bf726b55f00f47f4e1d953_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 16
        echo "    <h1 class=\"text-danger\"><i class=\"fa fa-unlock-alt\" aria-hidden=\"true\"></i> ";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error.name", array("%status_code%" => 403)), "html", null, true);
        echo "</h1>

    <p class=\"lead\">
        ";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_403.description"), "html", null, true);
        echo "
    </p>
    <p>
        ";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("http_error_403.suggestion"), "html", null, true);
        echo "
    </p>
";
        
        $__internal_48b56a9b27779f2ab9aed01d7075bb7cd744af6288bf726b55f00f47f4e1d953->leave($__internal_48b56a9b27779f2ab9aed01d7075bb7cd744af6288bf726b55f00f47f4e1d953_prof);

        
        $__internal_e228ca13e1b15ddd9aa5a441f67a9a3508f3ea435d147ad531ed9f7707338060->leave($__internal_e228ca13e1b15ddd9aa5a441f67a9a3508f3ea435d147ad531ed9f7707338060_prof);

    }

    // line 26
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_b6f24cd344bb9f9ff061d1d8ea3e49747c1cf7992a17d51ec270acff7757cb60 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b6f24cd344bb9f9ff061d1d8ea3e49747c1cf7992a17d51ec270acff7757cb60->enter($__internal_b6f24cd344bb9f9ff061d1d8ea3e49747c1cf7992a17d51ec270acff7757cb60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_ef0b23bf87a9528f849667476cd462ef6c1629107648527fd7bb5f0fdce0e51a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef0b23bf87a9528f849667476cd462ef6c1629107648527fd7bb5f0fdce0e51a->enter($__internal_ef0b23bf87a9528f849667476cd462ef6c1629107648527fd7bb5f0fdce0e51a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 27
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 29
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_ef0b23bf87a9528f849667476cd462ef6c1629107648527fd7bb5f0fdce0e51a->leave($__internal_ef0b23bf87a9528f849667476cd462ef6c1629107648527fd7bb5f0fdce0e51a_prof);

        
        $__internal_b6f24cd344bb9f9ff061d1d8ea3e49747c1cf7992a17d51ec270acff7757cb60->leave($__internal_b6f24cd344bb9f9ff061d1d8ea3e49747c1cf7992a17d51ec270acff7757cb60_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 29,  104 => 27,  95 => 26,  82 => 22,  76 => 19,  69 => 16,  60 => 15,  42 => 13,  11 => 11,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
    This template is used to render errors of type HTTP 403 (Forbidden)

    This is the simplest way to customize error pages in Symfony applications.
    In case you need it, you can also hook into the internal exception handling
    made by Symfony. This allows you to perform advanced tasks and even recover
    your application from some errors.
    See http://symfony.com/doc/current/cookbook/controller/error_pages.html
#}

{% extends 'base.html.twig' %}

{% block body_id 'error' %}

{% block main %}
    <h1 class=\"text-danger\"><i class=\"fa fa-unlock-alt\" aria-hidden=\"true\"></i> {{ 'http_error.name'|trans({ '%status_code%': 403 }) }}</h1>

    <p class=\"lead\">
        {{ 'http_error_403.description'|trans }}
    </p>
    <p>
        {{ 'http_error_403.suggestion'|trans }}
    </p>
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "TwigBundle:Exception:error403.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources/TwigBundle/views/Exception/error403.html.twig");
    }
}
