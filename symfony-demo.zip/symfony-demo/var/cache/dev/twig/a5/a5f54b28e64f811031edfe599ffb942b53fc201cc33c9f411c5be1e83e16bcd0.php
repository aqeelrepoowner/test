<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_4fa86c723db2bfa5e537ab2ab58e32e2c1561626c63650754ef0041d2644351d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f696d8121378fc4998d499e621800a4b532871521a7cb5ddd4cb291eec1af79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f696d8121378fc4998d499e621800a4b532871521a7cb5ddd4cb291eec1af79->enter($__internal_7f696d8121378fc4998d499e621800a4b532871521a7cb5ddd4cb291eec1af79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        $__internal_999a85ddb8adfd8b1d4c4fbb18272773f3a669607f29410e8463e9cfd5758275 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_999a85ddb8adfd8b1d4c4fbb18272773f3a669607f29410e8463e9cfd5758275->enter($__internal_999a85ddb8adfd8b1d4c4fbb18272773f3a669607f29410e8463e9cfd5758275_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_7f696d8121378fc4998d499e621800a4b532871521a7cb5ddd4cb291eec1af79->leave($__internal_7f696d8121378fc4998d499e621800a4b532871521a7cb5ddd4cb291eec1af79_prof);

        
        $__internal_999a85ddb8adfd8b1d4c4fbb18272773f3a669607f29410e8463e9cfd5758275->leave($__internal_999a85ddb8adfd8b1d4c4fbb18272773f3a669607f29410e8463e9cfd5758275_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
", "@Framework/Form/textarea_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\textarea_widget.html.php");
    }
}
