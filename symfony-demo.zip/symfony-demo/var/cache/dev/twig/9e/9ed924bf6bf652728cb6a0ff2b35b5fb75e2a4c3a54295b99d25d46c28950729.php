<?php

/* @Framework/Form/radio_widget.html.php */
class __TwigTemplate_a6cbdd6a6cf7f799059a739bc4a20b4534d77359b6bedf6f8d7555f4069771d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ee5a27edbe9900678864e4ed82cd9888ca1a5527d87e1330ab1b3c0feb8840d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee5a27edbe9900678864e4ed82cd9888ca1a5527d87e1330ab1b3c0feb8840d3->enter($__internal_ee5a27edbe9900678864e4ed82cd9888ca1a5527d87e1330ab1b3c0feb8840d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        $__internal_a346b69d30193672ad6503c0e4ee71e780e3e694836e4c3d6fc217dc41c16cc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a346b69d30193672ad6503c0e4ee71e780e3e694836e4c3d6fc217dc41c16cc1->enter($__internal_a346b69d30193672ad6503c0e4ee71e780e3e694836e4c3d6fc217dc41c16cc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/radio_widget.html.php"));

        // line 1
        echo "<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_ee5a27edbe9900678864e4ed82cd9888ca1a5527d87e1330ab1b3c0feb8840d3->leave($__internal_ee5a27edbe9900678864e4ed82cd9888ca1a5527d87e1330ab1b3c0feb8840d3_prof);

        
        $__internal_a346b69d30193672ad6503c0e4ee71e780e3e694836e4c3d6fc217dc41c16cc1->leave($__internal_a346b69d30193672ad6503c0e4ee71e780e3e694836e4c3d6fc217dc41c16cc1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/radio_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"radio\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    value=\"<?php echo \$view->escape(\$value) ?>\"
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/radio_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\radio_widget.html.php");
    }
}
