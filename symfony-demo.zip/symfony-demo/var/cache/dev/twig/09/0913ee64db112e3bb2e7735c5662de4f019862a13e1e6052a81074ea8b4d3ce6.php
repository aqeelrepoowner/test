<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_1f288a16bc5f0e617d401f11650cb45a33e3147338f15aaee7d1dade8c95ab90 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4d68c3d16708c7161e814ab10851c13120cd01380444e8e46b669e2ade6457a2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4d68c3d16708c7161e814ab10851c13120cd01380444e8e46b669e2ade6457a2->enter($__internal_4d68c3d16708c7161e814ab10851c13120cd01380444e8e46b669e2ade6457a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        $__internal_4a4f7f15cf78d000c407883db37fa97952045a14befcca79bb79a383b4d03846 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4a4f7f15cf78d000c407883db37fa97952045a14befcca79bb79a383b4d03846->enter($__internal_4a4f7f15cf78d000c407883db37fa97952045a14befcca79bb79a383b4d03846_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_4d68c3d16708c7161e814ab10851c13120cd01380444e8e46b669e2ade6457a2->leave($__internal_4d68c3d16708c7161e814ab10851c13120cd01380444e8e46b669e2ade6457a2_prof);

        
        $__internal_4a4f7f15cf78d000c407883db37fa97952045a14befcca79bb79a383b4d03846->leave($__internal_4a4f7f15cf78d000c407883db37fa97952045a14befcca79bb79a383b4d03846_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
", "@Framework/Form/hidden_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\hidden_widget.html.php");
    }
}
