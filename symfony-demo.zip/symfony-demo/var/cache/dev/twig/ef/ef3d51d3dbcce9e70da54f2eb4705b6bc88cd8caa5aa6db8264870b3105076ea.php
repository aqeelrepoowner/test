<?php

/* @WebProfiler/Profiler/ajax_layout.html.twig */
class __TwigTemplate_dd7148fd7a2cef8f4b573e4862a3a72ccf9c93d73a5766aa6c4e9451bca97700 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_25745b9e753107a12c9b1df13375b5d7edec965910dafd370b825ed142047e0f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_25745b9e753107a12c9b1df13375b5d7edec965910dafd370b825ed142047e0f->enter($__internal_25745b9e753107a12c9b1df13375b5d7edec965910dafd370b825ed142047e0f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        $__internal_4b10da7d47273d50c7e5b5bfbbfa1c35ca42464185d519750abfa46ec0da1351 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4b10da7d47273d50c7e5b5bfbbfa1c35ca42464185d519750abfa46ec0da1351->enter($__internal_4b10da7d47273d50c7e5b5bfbbfa1c35ca42464185d519750abfa46ec0da1351_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Profiler/ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_25745b9e753107a12c9b1df13375b5d7edec965910dafd370b825ed142047e0f->leave($__internal_25745b9e753107a12c9b1df13375b5d7edec965910dafd370b825ed142047e0f_prof);

        
        $__internal_4b10da7d47273d50c7e5b5bfbbfa1c35ca42464185d519750abfa46ec0da1351->leave($__internal_4b10da7d47273d50c7e5b5bfbbfa1c35ca42464185d519750abfa46ec0da1351_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_8738c6304f155669c0ceb6e63a2611945725ce92caf16b7ea2fffcc4100b7cc0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8738c6304f155669c0ceb6e63a2611945725ce92caf16b7ea2fffcc4100b7cc0->enter($__internal_8738c6304f155669c0ceb6e63a2611945725ce92caf16b7ea2fffcc4100b7cc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_1bbc05b0fcbe3734cc01046e045d6133dc40f850c5debf5124f338f718b3f9b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1bbc05b0fcbe3734cc01046e045d6133dc40f850c5debf5124f338f718b3f9b6->enter($__internal_1bbc05b0fcbe3734cc01046e045d6133dc40f850c5debf5124f338f718b3f9b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_1bbc05b0fcbe3734cc01046e045d6133dc40f850c5debf5124f338f718b3f9b6->leave($__internal_1bbc05b0fcbe3734cc01046e045d6133dc40f850c5debf5124f338f718b3f9b6_prof);

        
        $__internal_8738c6304f155669c0ceb6e63a2611945725ce92caf16b7ea2fffcc4100b7cc0->leave($__internal_8738c6304f155669c0ceb6e63a2611945725ce92caf16b7ea2fffcc4100b7cc0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Profiler/ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% block panel '' %}
", "@WebProfiler/Profiler/ajax_layout.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Profiler\\ajax_layout.html.twig");
    }
}
