<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_75be04fa1cd6a6054aebf39d1efee4cd9c95858154904070fba96194b9e3ed6d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_87267eb5982ed1baeb89a24755bd17c813c38808134f3b664e9259a50aa0f193 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_87267eb5982ed1baeb89a24755bd17c813c38808134f3b664e9259a50aa0f193->enter($__internal_87267eb5982ed1baeb89a24755bd17c813c38808134f3b664e9259a50aa0f193_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        $__internal_e234d5476ae0dac64e3f37fb664891cf8697d5a5f96f2dd0b053099bd25939f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e234d5476ae0dac64e3f37fb664891cf8697d5a5f96f2dd0b053099bd25939f1->enter($__internal_e234d5476ae0dac64e3f37fb664891cf8697d5a5f96f2dd0b053099bd25939f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_87267eb5982ed1baeb89a24755bd17c813c38808134f3b664e9259a50aa0f193->leave($__internal_87267eb5982ed1baeb89a24755bd17c813c38808134f3b664e9259a50aa0f193_prof);

        
        $__internal_e234d5476ae0dac64e3f37fb664891cf8697d5a5f96f2dd0b053099bd25939f1->leave($__internal_e234d5476ae0dac64e3f37fb664891cf8697d5a5f96f2dd0b053099bd25939f1_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/button_row.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\button_row.html.php");
    }
}
