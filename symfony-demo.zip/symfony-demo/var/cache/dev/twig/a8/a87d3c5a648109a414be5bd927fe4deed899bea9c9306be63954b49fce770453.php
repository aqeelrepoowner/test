<?php

/* admin/students/index.html.twig */
class __TwigTemplate_c93ec39fc45948dd620937ab017832df67d71f030397bfc840f06faab23f8622 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/students/index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed8df646906464727e4fe44bb56e5ee50053b8b9e735659bd386c71d60a4a67c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ed8df646906464727e4fe44bb56e5ee50053b8b9e735659bd386c71d60a4a67c->enter($__internal_ed8df646906464727e4fe44bb56e5ee50053b8b9e735659bd386c71d60a4a67c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/students/index.html.twig"));

        $__internal_541930124a33735b51a583ebaca9d47b2ae817df7cc40ecd11c0e02849b58c81 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_541930124a33735b51a583ebaca9d47b2ae817df7cc40ecd11c0e02849b58c81->enter($__internal_541930124a33735b51a583ebaca9d47b2ae817df7cc40ecd11c0e02849b58c81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/students/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_ed8df646906464727e4fe44bb56e5ee50053b8b9e735659bd386c71d60a4a67c->leave($__internal_ed8df646906464727e4fe44bb56e5ee50053b8b9e735659bd386c71d60a4a67c_prof);

        
        $__internal_541930124a33735b51a583ebaca9d47b2ae817df7cc40ecd11c0e02849b58c81->leave($__internal_541930124a33735b51a583ebaca9d47b2ae817df7cc40ecd11c0e02849b58c81_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_311174e6689afc3652595ff14cffc849c58f165ddf2bc85b4c142c4c4a94334c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_311174e6689afc3652595ff14cffc849c58f165ddf2bc85b4c142c4c4a94334c->enter($__internal_311174e6689afc3652595ff14cffc849c58f165ddf2bc85b4c142c4c4a94334c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_25de013d42be0993ace8f2d58e6703481b7b76db610dc86d810e369467528478 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25de013d42be0993ace8f2d58e6703481b7b76db610dc86d810e369467528478->enter($__internal_25de013d42be0993ace8f2d58e6703481b7b76db610dc86d810e369467528478_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_student_index";
        
        $__internal_25de013d42be0993ace8f2d58e6703481b7b76db610dc86d810e369467528478->leave($__internal_25de013d42be0993ace8f2d58e6703481b7b76db610dc86d810e369467528478_prof);

        
        $__internal_311174e6689afc3652595ff14cffc849c58f165ddf2bc85b4c142c4c4a94334c->leave($__internal_311174e6689afc3652595ff14cffc849c58f165ddf2bc85b4c142c4c4a94334c_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_8e29ffe8f91a92e60013f588017be28054e733a6ac2acf231e441862cc4c738e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8e29ffe8f91a92e60013f588017be28054e733a6ac2acf231e441862cc4c738e->enter($__internal_8e29ffe8f91a92e60013f588017be28054e733a6ac2acf231e441862cc4c738e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_b44fc23f9e1bc4162e2dc9a8a3b1c68efa2926a78f74c92817f8e23cf3b1f024 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b44fc23f9e1bc4162e2dc9a8a3b1c68efa2926a78f74c92817f8e23cf3b1f024->enter($__internal_b44fc23f9e1bc4162e2dc9a8a3b1c68efa2926a78f74c92817f8e23cf3b1f024_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.student_list"), "html", null, true);
        echo "</h1>

    <table class=\"table table-striped table-middle-aligned\">
        <thead>
            <tr>
                <th scope=\"col\">";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_first_name"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_fatherName"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_last_name"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_email"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_gender"), "html", null, true);
        echo "</th>
                <th scope=\"col\">";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.student_dob"), "html", null, true);
        echo "</th>
                <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> ";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.actions"), "html", null, true);
        echo "</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["students"]) ? $context["students"] : $this->getContext($context, "students")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["student"]) {
            // line 22
            echo "            <tr>
                <td>";
            // line 23
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "first_name", array()), "html", null, true);
            echo "</td>
                ";
            // line 27
            echo "                <td>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "father_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 28
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "last_name", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 29
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "email", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "gender", array()), "html", null, true);
            echo "</td>
                <td>";
            // line 31
            echo twig_escape_filter($this->env, $this->getAttribute($context["student"], "dob", array()), "html", null, true);
            echo "</td>
                <td class=\"text-right\">
                    <div class=\"item-actions\">
                        <a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_show", array("id" => $this->getAttribute($context["student"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-default\">
                            ";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.show"), "html", null, true);
            echo "
                        </a>

                        <a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_edit", array("id" => $this->getAttribute($context["student"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit"), "html", null, true);
            echo "
                        </a>
                    </div>
                </td>
            </tr>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 45
            echo "            <tr>
                <td colspan=\"4\" align=\"center\">";
            // line 46
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("student.no_students_found"), "html", null, true);
            echo "</td>
           </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['student'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "        </tbody>
    </table>
";
        
        $__internal_b44fc23f9e1bc4162e2dc9a8a3b1c68efa2926a78f74c92817f8e23cf3b1f024->leave($__internal_b44fc23f9e1bc4162e2dc9a8a3b1c68efa2926a78f74c92817f8e23cf3b1f024_prof);

        
        $__internal_8e29ffe8f91a92e60013f588017be28054e733a6ac2acf231e441862cc4c738e->leave($__internal_8e29ffe8f91a92e60013f588017be28054e733a6ac2acf231e441862cc4c738e_prof);

    }

    // line 53
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_338eeb55dd32da120ee59988d5680c3244d2372f6c68954481e9331fe60c61f2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_338eeb55dd32da120ee59988d5680c3244d2372f6c68954481e9331fe60c61f2->enter($__internal_338eeb55dd32da120ee59988d5680c3244d2372f6c68954481e9331fe60c61f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_b061029157dbbe2dd493417d8db473ee51a402281279275a340280523d9a9792 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b061029157dbbe2dd493417d8db473ee51a402281279275a340280523d9a9792->enter($__internal_b061029157dbbe2dd493417d8db473ee51a402281279275a340280523d9a9792_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 54
        echo "    <div class=\"section actions\">
        <a href=\"";
        // line 55
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_new");
        echo "\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> ";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.create_student"), "html", null, true);
        echo "
        </a>
    </div>

    ";
        // line 60
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 62
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_b061029157dbbe2dd493417d8db473ee51a402281279275a340280523d9a9792->leave($__internal_b061029157dbbe2dd493417d8db473ee51a402281279275a340280523d9a9792_prof);

        
        $__internal_338eeb55dd32da120ee59988d5680c3244d2372f6c68954481e9331fe60c61f2->leave($__internal_338eeb55dd32da120ee59988d5680c3244d2372f6c68954481e9331fe60c61f2_prof);

    }

    public function getTemplateName()
    {
        return "admin/students/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  221 => 62,  216 => 60,  209 => 56,  205 => 55,  202 => 54,  193 => 53,  181 => 49,  172 => 46,  169 => 45,  158 => 39,  154 => 38,  148 => 35,  144 => 34,  138 => 31,  134 => 30,  130 => 29,  126 => 28,  121 => 27,  117 => 23,  114 => 22,  109 => 21,  102 => 17,  98 => 16,  94 => 15,  90 => 14,  86 => 13,  82 => 12,  78 => 11,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_student_index' %}

{% block main %}
    <h1>{{ 'title.student_list'|trans }}</h1>

    <table class=\"table table-striped table-middle-aligned\">
        <thead>
            <tr>
                <th scope=\"col\">{{ 'label.student_first_name'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_fatherName'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_last_name'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_email'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_gender'|trans }}</th>
                <th scope=\"col\">{{ 'label.student_dob'|trans }}</th>
                <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> {{ 'label.actions'|trans }}</th>
            </tr>
        </thead>
        <tbody>
        {% for student in students %}
            <tr>
                <td>{{ student.first_name }}</td>
                {# it's not mandatory to set the timezone in localizeddate(). This is done to
                   avoid errors when the 'intl' PHP extension is not available and the application
                   is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
                <td>{{ student.father_name }}</td>
                <td>{{ student.last_name }}</td>
                <td>{{ student.email }}</td>
                <td>{{ student.gender }}</td>
                <td>{{ student.dob }}</td>
                <td class=\"text-right\">
                    <div class=\"item-actions\">
                        <a href=\"{{ path('admin_student_show', { id: student.id }) }}\" class=\"btn btn-sm btn-default\">
                            {{ 'action.show'|trans }}
                        </a>

                        <a href=\"{{ path('admin_student_edit', { id: student.id }) }}\" class=\"btn btn-sm btn-primary\">
                            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit'|trans }}
                        </a>
                    </div>
                </td>
            </tr>
        {% else %}
            <tr>
                <td colspan=\"4\" align=\"center\">{{ 'student.no_students_found'|trans }}</td>
           </tr>
        {% endfor %}
        </tbody>
    </table>
{% endblock %}

{% block sidebar %}
    <div class=\"section actions\">
        <a href=\"{{ path('admin_student_new') }}\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> {{ 'action.create_student'|trans }}
        </a>
    </div>

    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "admin/students/index.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\admin\\students\\index.html.twig");
    }
}
