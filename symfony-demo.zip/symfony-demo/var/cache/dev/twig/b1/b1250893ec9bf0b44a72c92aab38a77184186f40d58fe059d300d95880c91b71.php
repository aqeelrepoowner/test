<?php

/* @Framework/Form/form_enctype.html.php */
class __TwigTemplate_642acfa793a44c07af3d56e270d68390e431db9ad43b9426acfbbc7c05768240 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ffb4b4ccd6d6a00de3fd0fc97a83c94c30b1496f1afbfd6204a7b41c11e72499 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ffb4b4ccd6d6a00de3fd0fc97a83c94c30b1496f1afbfd6204a7b41c11e72499->enter($__internal_ffb4b4ccd6d6a00de3fd0fc97a83c94c30b1496f1afbfd6204a7b41c11e72499_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        $__internal_20eed91440c8cebcd015f4abe5a5cc1bf47315bb150204c659bfb7ca8e4b4373 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_20eed91440c8cebcd015f4abe5a5cc1bf47315bb150204c659bfb7ca8e4b4373->enter($__internal_20eed91440c8cebcd015f4abe5a5cc1bf47315bb150204c659bfb7ca8e4b4373_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_enctype.html.php"));

        // line 1
        echo "<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
";
        
        $__internal_ffb4b4ccd6d6a00de3fd0fc97a83c94c30b1496f1afbfd6204a7b41c11e72499->leave($__internal_ffb4b4ccd6d6a00de3fd0fc97a83c94c30b1496f1afbfd6204a7b41c11e72499_prof);

        
        $__internal_20eed91440c8cebcd015f4abe5a5cc1bf47315bb150204c659bfb7ca8e4b4373->leave($__internal_20eed91440c8cebcd015f4abe5a5cc1bf47315bb150204c659bfb7ca8e4b4373_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_enctype.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$form->vars['multipart']): ?>enctype=\"multipart/form-data\"<?php endif ?>
", "@Framework/Form/form_enctype.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_enctype.html.php");
    }
}
