<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_f9054665294263a3db06df2dda796b67e823b8f51058777c541e296deb07f9ae extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7f11f37cdb56bbf0aa95efd39e36d93bd8e0ef8960f25d4caf43755af267e813 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f11f37cdb56bbf0aa95efd39e36d93bd8e0ef8960f25d4caf43755af267e813->enter($__internal_7f11f37cdb56bbf0aa95efd39e36d93bd8e0ef8960f25d4caf43755af267e813_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        $__internal_125f5616ffaf603694e5998de8e1a3cec99e8c3e210ab865ad399c7e51c94036 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_125f5616ffaf603694e5998de8e1a3cec99e8c3e210ab865ad399c7e51c94036->enter($__internal_125f5616ffaf603694e5998de8e1a3cec99e8c3e210ab865ad399c7e51c94036_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_7f11f37cdb56bbf0aa95efd39e36d93bd8e0ef8960f25d4caf43755af267e813->leave($__internal_7f11f37cdb56bbf0aa95efd39e36d93bd8e0ef8960f25d4caf43755af267e813_prof);

        
        $__internal_125f5616ffaf603694e5998de8e1a3cec99e8c3e210ab865ad399c7e51c94036->leave($__internal_125f5616ffaf603694e5998de8e1a3cec99e8c3e210ab865ad399c7e51c94036_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.atom.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.atom.twig");
    }
}
