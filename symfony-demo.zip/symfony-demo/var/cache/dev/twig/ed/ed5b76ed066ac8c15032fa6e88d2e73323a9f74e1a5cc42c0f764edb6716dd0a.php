<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_9e7dc4a95aab464843b6452ab66e3e90aa327b728b53e75a829a32a4172decd1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d3fe8e26a2455bac948f6937987a193d9e8bc1b9208320bd731dc07f6b04c0cf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d3fe8e26a2455bac948f6937987a193d9e8bc1b9208320bd731dc07f6b04c0cf->enter($__internal_d3fe8e26a2455bac948f6937987a193d9e8bc1b9208320bd731dc07f6b04c0cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        $__internal_8292b23050d3141e00f11102f9e9122a0ba591564b4a2dd454231701aad6da86 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8292b23050d3141e00f11102f9e9122a0ba591564b4a2dd454231701aad6da86->enter($__internal_8292b23050d3141e00f11102f9e9122a0ba591564b4a2dd454231701aad6da86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_d3fe8e26a2455bac948f6937987a193d9e8bc1b9208320bd731dc07f6b04c0cf->leave($__internal_d3fe8e26a2455bac948f6937987a193d9e8bc1b9208320bd731dc07f6b04c0cf_prof);

        
        $__internal_8292b23050d3141e00f11102f9e9122a0ba591564b4a2dd454231701aad6da86->leave($__internal_8292b23050d3141e00f11102f9e9122a0ba591564b4a2dd454231701aad6da86_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'password')) ?>
", "@Framework/Form/password_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\password_widget.html.php");
    }
}
