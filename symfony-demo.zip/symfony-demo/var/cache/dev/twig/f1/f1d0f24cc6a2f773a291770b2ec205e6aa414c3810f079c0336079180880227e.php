<?php

/* :blog:comment_form_error.html.twig */
class __TwigTemplate_1aa0f43da7c4fc77ea69f3bdfa65e54c8409129fe31f670c32ac32501ff78771 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":blog:comment_form_error.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63b375a48224f269c6661c2fd583f40e85b26a3bdaae413edf46216aab05bed2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63b375a48224f269c6661c2fd583f40e85b26a3bdaae413edf46216aab05bed2->enter($__internal_63b375a48224f269c6661c2fd583f40e85b26a3bdaae413edf46216aab05bed2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:comment_form_error.html.twig"));

        $__internal_4c810570015cb3400c7090aca5b4a83b3307333fb83fec5c7860066befb77757 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4c810570015cb3400c7090aca5b4a83b3307333fb83fec5c7860066befb77757->enter($__internal_4c810570015cb3400c7090aca5b4a83b3307333fb83fec5c7860066befb77757_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:comment_form_error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_63b375a48224f269c6661c2fd583f40e85b26a3bdaae413edf46216aab05bed2->leave($__internal_63b375a48224f269c6661c2fd583f40e85b26a3bdaae413edf46216aab05bed2_prof);

        
        $__internal_4c810570015cb3400c7090aca5b4a83b3307333fb83fec5c7860066befb77757->leave($__internal_4c810570015cb3400c7090aca5b4a83b3307333fb83fec5c7860066befb77757_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_3aa6ebc2246cbe23991ed6183bf1344928a4e0dcc4fbfc4802eab6ea388b9798 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3aa6ebc2246cbe23991ed6183bf1344928a4e0dcc4fbfc4802eab6ea388b9798->enter($__internal_3aa6ebc2246cbe23991ed6183bf1344928a4e0dcc4fbfc4802eab6ea388b9798_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_16d468c872a4ad98d61d08682e279116c4f82471167681043ce7ab1e913c4cd3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16d468c872a4ad98d61d08682e279116c4f82471167681043ce7ab1e913c4cd3->enter($__internal_16d468c872a4ad98d61d08682e279116c4f82471167681043ce7ab1e913c4cd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "comment_form_error";
        
        $__internal_16d468c872a4ad98d61d08682e279116c4f82471167681043ce7ab1e913c4cd3->leave($__internal_16d468c872a4ad98d61d08682e279116c4f82471167681043ce7ab1e913c4cd3_prof);

        
        $__internal_3aa6ebc2246cbe23991ed6183bf1344928a4e0dcc4fbfc4802eab6ea388b9798->leave($__internal_3aa6ebc2246cbe23991ed6183bf1344928a4e0dcc4fbfc4802eab6ea388b9798_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_fa6f4ef77df58472f24f666cc32f4580a7ccbfbd960330cdd25437d5125d3406 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa6f4ef77df58472f24f666cc32f4580a7ccbfbd960330cdd25437d5125d3406->enter($__internal_fa6f4ef77df58472f24f666cc32f4580a7ccbfbd960330cdd25437d5125d3406_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_2e1f5d4f7fdd05827b2b8306895b712523e2056fbe1c97c1a76f7e2cb1eca71b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2e1f5d4f7fdd05827b2b8306895b712523e2056fbe1c97c1a76f7e2cb1eca71b->enter($__internal_2e1f5d4f7fdd05827b2b8306895b712523e2056fbe1c97c1a76f7e2cb1eca71b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.comment_error"), "html", null, true);
        echo "</h1>

    <div class=\"well\">
        ";
        // line 9
        echo twig_include($this->env, $context, "blog/_comment_form.html.twig");
        echo "
    </div>
";
        
        $__internal_2e1f5d4f7fdd05827b2b8306895b712523e2056fbe1c97c1a76f7e2cb1eca71b->leave($__internal_2e1f5d4f7fdd05827b2b8306895b712523e2056fbe1c97c1a76f7e2cb1eca71b_prof);

        
        $__internal_fa6f4ef77df58472f24f666cc32f4580a7ccbfbd960330cdd25437d5125d3406->leave($__internal_fa6f4ef77df58472f24f666cc32f4580a7ccbfbd960330cdd25437d5125d3406_prof);

    }

    public function getTemplateName()
    {
        return ":blog:comment_form_error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 9,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'comment_form_error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'title.comment_error'|trans }}</h1>

    <div class=\"well\">
        {{ include('blog/_comment_form.html.twig') }}
    </div>
{% endblock %}
", ":blog:comment_form_error.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/blog/comment_form_error.html.twig");
    }
}
