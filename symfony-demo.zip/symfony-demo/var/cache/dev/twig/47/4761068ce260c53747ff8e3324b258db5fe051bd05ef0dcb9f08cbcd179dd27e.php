<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_56f3cd2195f563e29e7460459819da8437d3f0b099165782d08850e065550ac3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14664e74f49b6e98fc580ce9fb5c81ba5cc8d5fd9a5c386d2faf90d34b773562 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14664e74f49b6e98fc580ce9fb5c81ba5cc8d5fd9a5c386d2faf90d34b773562->enter($__internal_14664e74f49b6e98fc580ce9fb5c81ba5cc8d5fd9a5c386d2faf90d34b773562_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_2511fff6fa4876bb1ee2c158129838ab5cc85c4431fb1bcd88aab900e27d9bb6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2511fff6fa4876bb1ee2c158129838ab5cc85c4431fb1bcd88aab900e27d9bb6->enter($__internal_2511fff6fa4876bb1ee2c158129838ab5cc85c4431fb1bcd88aab900e27d9bb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_14664e74f49b6e98fc580ce9fb5c81ba5cc8d5fd9a5c386d2faf90d34b773562->leave($__internal_14664e74f49b6e98fc580ce9fb5c81ba5cc8d5fd9a5c386d2faf90d34b773562_prof);

        
        $__internal_2511fff6fa4876bb1ee2c158129838ab5cc85c4431fb1bcd88aab900e27d9bb6->leave($__internal_2511fff6fa4876bb1ee2c158129838ab5cc85c4431fb1bcd88aab900e27d9bb6_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_14ef4bdc66535687296b4a3bea3ab1de2935c95cadef292073899bb719da47a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_14ef4bdc66535687296b4a3bea3ab1de2935c95cadef292073899bb719da47a5->enter($__internal_14ef4bdc66535687296b4a3bea3ab1de2935c95cadef292073899bb719da47a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_29e932499117f2198f1895b749b17babfae83d8bd5992a4270ecfd687b23bc24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_29e932499117f2198f1895b749b17babfae83d8bd5992a4270ecfd687b23bc24->enter($__internal_29e932499117f2198f1895b749b17babfae83d8bd5992a4270ecfd687b23bc24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_29e932499117f2198f1895b749b17babfae83d8bd5992a4270ecfd687b23bc24->leave($__internal_29e932499117f2198f1895b749b17babfae83d8bd5992a4270ecfd687b23bc24_prof);

        
        $__internal_14ef4bdc66535687296b4a3bea3ab1de2935c95cadef292073899bb719da47a5->leave($__internal_14ef4bdc66535687296b4a3bea3ab1de2935c95cadef292073899bb719da47a5_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_d48975bb2daefc17ac4f515878bbc968ea7e84ff0a577be48db8d1c0f95848af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d48975bb2daefc17ac4f515878bbc968ea7e84ff0a577be48db8d1c0f95848af->enter($__internal_d48975bb2daefc17ac4f515878bbc968ea7e84ff0a577be48db8d1c0f95848af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_418b4186ea70063be4f637a0a558841a2388c0e7206deb6a6c192657077c4069 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_418b4186ea70063be4f637a0a558841a2388c0e7206deb6a6c192657077c4069->enter($__internal_418b4186ea70063be4f637a0a558841a2388c0e7206deb6a6c192657077c4069_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_418b4186ea70063be4f637a0a558841a2388c0e7206deb6a6c192657077c4069->leave($__internal_418b4186ea70063be4f637a0a558841a2388c0e7206deb6a6c192657077c4069_prof);

        
        $__internal_d48975bb2daefc17ac4f515878bbc968ea7e84ff0a577be48db8d1c0f95848af->leave($__internal_d48975bb2daefc17ac4f515878bbc968ea7e84ff0a577be48db8d1c0f95848af_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ba2c6710f17beba1b0e6b83a9723de21a29b8e41f09c1287a9df14603601a5ec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ba2c6710f17beba1b0e6b83a9723de21a29b8e41f09c1287a9df14603601a5ec->enter($__internal_ba2c6710f17beba1b0e6b83a9723de21a29b8e41f09c1287a9df14603601a5ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_17b315ca0c7142ef6d4774c64a00e6c1fefa74333faae2815a4fc00a687fe6ae = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_17b315ca0c7142ef6d4774c64a00e6c1fefa74333faae2815a4fc00a687fe6ae->enter($__internal_17b315ca0c7142ef6d4774c64a00e6c1fefa74333faae2815a4fc00a687fe6ae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_17b315ca0c7142ef6d4774c64a00e6c1fefa74333faae2815a4fc00a687fe6ae->leave($__internal_17b315ca0c7142ef6d4774c64a00e6c1fefa74333faae2815a4fc00a687fe6ae_prof);

        
        $__internal_ba2c6710f17beba1b0e6b83a9723de21a29b8e41f09c1287a9df14603601a5ec->leave($__internal_ba2c6710f17beba1b0e6b83a9723de21a29b8e41f09c1287a9df14603601a5ec_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
