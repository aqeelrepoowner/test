<?php

/* base.html.twig */
class __TwigTemplate_81db5df7843571d32c90f2daefc6e6f34fcf056f5aa02a4aecbdfcf8620ea646 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_51fd5e40b5822d9d8882b760dc11724e5cf74de08cf039367d957a0161e3907b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_51fd5e40b5822d9d8882b760dc11724e5cf74de08cf039367d957a0161e3907b->enter($__internal_51fd5e40b5822d9d8882b760dc11724e5cf74de08cf039367d957a0161e3907b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_aa7d7c863cc005375ba0633941942209c227993d28301821bf8db5369ff28b4e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa7d7c863cc005375ba0633941942209c227993d28301821bf8db5369ff28b4e->enter($__internal_aa7d7c863cc005375ba0633941942209c227993d28301821bf8db5369ff28b4e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()), "html", null, true);
        echo "\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("rss.title"), "html", null, true);
        echo "\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 21
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>

    <body id=\"";
        // line 24
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

        ";
        // line 26
        $this->displayBlock('header', $context, $blocks);
        // line 89
        echo "
        <div class=\"container body-container\">
            ";
        // line 91
        $this->displayBlock('body', $context, $blocks);
        // line 110
        echo "        </div>

        ";
        // line 112
        $this->displayBlock('footer', $context, $blocks);
        // line 137
        echo "
        ";
        // line 138
        $this->displayBlock('javascripts', $context, $blocks);
        // line 146
        echo "
        ";
        // line 150
        echo "        <!-- Page rendered on ";
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, "now", "long", "long", null, "UTC"), "html", null, true);
        echo " -->
    </body>
</html>
";
        
        $__internal_51fd5e40b5822d9d8882b760dc11724e5cf74de08cf039367d957a0161e3907b->leave($__internal_51fd5e40b5822d9d8882b760dc11724e5cf74de08cf039367d957a0161e3907b_prof);

        
        $__internal_aa7d7c863cc005375ba0633941942209c227993d28301821bf8db5369ff28b4e->leave($__internal_aa7d7c863cc005375ba0633941942209c227993d28301821bf8db5369ff28b4e_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_0f58c821c572bdb122751b63ec6bed1b9294862f6f4c0173a83339df3c5dfe10 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0f58c821c572bdb122751b63ec6bed1b9294862f6f4c0173a83339df3c5dfe10->enter($__internal_0f58c821c572bdb122751b63ec6bed1b9294862f6f4c0173a83339df3c5dfe10_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_feaaa02418e8bee4f898c241057467a8e0b0847d76b3c36d5f5c00f6ac79a6de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_feaaa02418e8bee4f898c241057467a8e0b0847d76b3c36d5f5c00f6ac79a6de->enter($__internal_feaaa02418e8bee4f898c241057467a8e0b0847d76b3c36d5f5c00f6ac79a6de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symfony Demo application";
        
        $__internal_feaaa02418e8bee4f898c241057467a8e0b0847d76b3c36d5f5c00f6ac79a6de->leave($__internal_feaaa02418e8bee4f898c241057467a8e0b0847d76b3c36d5f5c00f6ac79a6de_prof);

        
        $__internal_0f58c821c572bdb122751b63ec6bed1b9294862f6f4c0173a83339df3c5dfe10->leave($__internal_0f58c821c572bdb122751b63ec6bed1b9294862f6f4c0173a83339df3c5dfe10_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1289720bfc1e2db0c295aefa1c93e3a341d855e835d54ec98eab4ffc0e1841b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1289720bfc1e2db0c295aefa1c93e3a341d855e835d54ec98eab4ffc0e1841b4->enter($__internal_1289720bfc1e2db0c295aefa1c93e3a341d855e835d54ec98eab4ffc0e1841b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_40aa044a9d06fbefdaccd94f339e9a7f9748e3b364ab6861d50fbff1a11986a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40aa044a9d06fbefdaccd94f339e9a7f9748e3b364ab6861d50fbff1a11986a6->enter($__internal_40aa044a9d06fbefdaccd94f339e9a7f9748e3b364ab6861d50fbff1a11986a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 14
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-flatly-3.3.7.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-awesome-4.6.3.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-lato.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/highlight-solarized-light.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_40aa044a9d06fbefdaccd94f339e9a7f9748e3b364ab6861d50fbff1a11986a6->leave($__internal_40aa044a9d06fbefdaccd94f339e9a7f9748e3b364ab6861d50fbff1a11986a6_prof);

        
        $__internal_1289720bfc1e2db0c295aefa1c93e3a341d855e835d54ec98eab4ffc0e1841b4->leave($__internal_1289720bfc1e2db0c295aefa1c93e3a341d855e835d54ec98eab4ffc0e1841b4_prof);

    }

    // line 24
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_7f22dad0779a2e0f5525d1934d857096a06654eba2db1db03d8bb77760ca2385 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f22dad0779a2e0f5525d1934d857096a06654eba2db1db03d8bb77760ca2385->enter($__internal_7f22dad0779a2e0f5525d1934d857096a06654eba2db1db03d8bb77760ca2385_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_a8e6932c18bd3d39d621e6aa992cfabcca29a9edfde4481d2545c0c952757045 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a8e6932c18bd3d39d621e6aa992cfabcca29a9edfde4481d2545c0c952757045->enter($__internal_a8e6932c18bd3d39d621e6aa992cfabcca29a9edfde4481d2545c0c952757045_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_a8e6932c18bd3d39d621e6aa992cfabcca29a9edfde4481d2545c0c952757045->leave($__internal_a8e6932c18bd3d39d621e6aa992cfabcca29a9edfde4481d2545c0c952757045_prof);

        
        $__internal_7f22dad0779a2e0f5525d1934d857096a06654eba2db1db03d8bb77760ca2385->leave($__internal_7f22dad0779a2e0f5525d1934d857096a06654eba2db1db03d8bb77760ca2385_prof);

    }

    // line 26
    public function block_header($context, array $blocks = array())
    {
        $__internal_e2419141973fe5549f452005c8e6be784a3633a0ea523d14d98b6535eaa18534 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e2419141973fe5549f452005c8e6be784a3633a0ea523d14d98b6535eaa18534->enter($__internal_e2419141973fe5549f452005c8e6be784a3633a0ea523d14d98b6535eaa18534_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_a00974d1d0ab58b5f527d44a3200e37a0692077e51fd061df4ec56e1ad27738a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a00974d1d0ab58b5f527d44a3200e37a0692077e51fd061df4ec56e1ad27738a->enter($__internal_a00974d1d0ab58b5f527d44a3200e37a0692077e51fd061df4ec56e1ad27738a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 27
        echo "            <header>
                <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
                    <div class=\"container\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">
                                Symfony Demo
                            </a>

                            <button type=\"button\" class=\"navbar-toggle\"
                                    data-toggle=\"collapse\"
                                    data-target=\".navbar-collapse\">
                                <span class=\"sr-only\">";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.toggle_nav"), "html", null, true);
        echo "</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav navbar-right\">

                                ";
        // line 47
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 62
        echo "
                                ";
        // line 63
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 64
            echo "                                    <li>
                                        <a href=\"";
            // line 65
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">
                                            <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> ";
            // line 66
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.logout"), "html", null, true);
            echo "
                                        </a>
                                    </li>
                                ";
        }
        // line 70
        echo "
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" id=\"locales\">
                                        <i class=\"fa fa-globe\" aria-hidden=\"true\"></i>
                                        <span class=\"caret\"></span>
                                        <span class=\"sr-only\">";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.choose_language"), "html", null, true);
        echo "</span>
                                    </a>
                                    <ul class=\"dropdown-menu locales\" role=\"menu\" aria-labelledby=\"locales\">
                                        ";
        // line 78
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('AppBundle\Twig\AppExtension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 79
            echo "                                            <li ";
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "aria-checked=\"true\" class=\"active\"";
            } else {
                echo "aria-checked=\"false\"";
            }
            echo " role=\"menuitem\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a></li>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 81
        echo "                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        ";
        
        $__internal_a00974d1d0ab58b5f527d44a3200e37a0692077e51fd061df4ec56e1ad27738a->leave($__internal_a00974d1d0ab58b5f527d44a3200e37a0692077e51fd061df4ec56e1ad27738a_prof);

        
        $__internal_e2419141973fe5549f452005c8e6be784a3633a0ea523d14d98b6535eaa18534->leave($__internal_e2419141973fe5549f452005c8e6be784a3633a0ea523d14d98b6535eaa18534_prof);

    }

    // line 47
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_9636f876440d18c0907d7cd5fe10a9c90ba609e78abb6c437f2c07f735606716 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9636f876440d18c0907d7cd5fe10a9c90ba609e78abb6c437f2c07f735606716->enter($__internal_9636f876440d18c0907d7cd5fe10a9c90ba609e78abb6c437f2c07f735606716_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_47ec36c5c01ea41fe126f8677742ed17b6bee9f81f9311a9ad7213b280659e41 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_47ec36c5c01ea41fe126f8677742ed17b6bee9f81f9311a9ad7213b280659e41->enter($__internal_47ec36c5c01ea41fe126f8677742ed17b6bee9f81f9311a9ad7213b280659e41_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 48
        echo "                                    <li>
                                        <a href=\"";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
                                            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> ";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.homepage"), "html", null, true);
        echo "
                                        </a>
                                    </li>

                                    ";
        // line 54
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 55
            echo "                                        <li>
                                            <a href=\"";
            // line 56
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
            echo "\">
                                                <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
            // line 57
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.admin"), "html", null, true);
            echo "
                                            </a>
                                        </li>
                                    ";
        }
        // line 61
        echo "                                ";
        
        $__internal_47ec36c5c01ea41fe126f8677742ed17b6bee9f81f9311a9ad7213b280659e41->leave($__internal_47ec36c5c01ea41fe126f8677742ed17b6bee9f81f9311a9ad7213b280659e41_prof);

        
        $__internal_9636f876440d18c0907d7cd5fe10a9c90ba609e78abb6c437f2c07f735606716->leave($__internal_9636f876440d18c0907d7cd5fe10a9c90ba609e78abb6c437f2c07f735606716_prof);

    }

    // line 91
    public function block_body($context, array $blocks = array())
    {
        $__internal_741dcc3cdb1a306b975287b81b3c5defe3f5713210e27ceb1ccf1f6831deae34 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_741dcc3cdb1a306b975287b81b3c5defe3f5713210e27ceb1ccf1f6831deae34->enter($__internal_741dcc3cdb1a306b975287b81b3c5defe3f5713210e27ceb1ccf1f6831deae34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_375f3cb47a2fe8798de1385dd9554676f73e98bfb72da92d21083f7bdf41f63e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_375f3cb47a2fe8798de1385dd9554676f73e98bfb72da92d21083f7bdf41f63e->enter($__internal_375f3cb47a2fe8798de1385dd9554676f73e98bfb72da92d21083f7bdf41f63e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 92
        echo "                <div class=\"row\">
                    <div id=\"main\" class=\"col-sm-9\">
                        ";
        // line 94
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "

                        ";
        // line 96
        $this->displayBlock('main', $context, $blocks);
        // line 97
        echo "                    </div>

                    <div id=\"sidebar\" class=\"col-sm-3\">
                        ";
        // line 100
        $this->displayBlock('sidebar', $context, $blocks);
        // line 107
        echo "                    </div>
                </div>
            ";
        
        $__internal_375f3cb47a2fe8798de1385dd9554676f73e98bfb72da92d21083f7bdf41f63e->leave($__internal_375f3cb47a2fe8798de1385dd9554676f73e98bfb72da92d21083f7bdf41f63e_prof);

        
        $__internal_741dcc3cdb1a306b975287b81b3c5defe3f5713210e27ceb1ccf1f6831deae34->leave($__internal_741dcc3cdb1a306b975287b81b3c5defe3f5713210e27ceb1ccf1f6831deae34_prof);

    }

    // line 96
    public function block_main($context, array $blocks = array())
    {
        $__internal_311477df22b7705a6c28186176ded5965d3dbab920ac60198b622d28f097b220 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_311477df22b7705a6c28186176ded5965d3dbab920ac60198b622d28f097b220->enter($__internal_311477df22b7705a6c28186176ded5965d3dbab920ac60198b622d28f097b220_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_9b3a8a16a927a6765c94e7f16b36afa5ee28bd606e038820805aa775f5cd160a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9b3a8a16a927a6765c94e7f16b36afa5ee28bd606e038820805aa775f5cd160a->enter($__internal_9b3a8a16a927a6765c94e7f16b36afa5ee28bd606e038820805aa775f5cd160a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_9b3a8a16a927a6765c94e7f16b36afa5ee28bd606e038820805aa775f5cd160a->leave($__internal_9b3a8a16a927a6765c94e7f16b36afa5ee28bd606e038820805aa775f5cd160a_prof);

        
        $__internal_311477df22b7705a6c28186176ded5965d3dbab920ac60198b622d28f097b220->leave($__internal_311477df22b7705a6c28186176ded5965d3dbab920ac60198b622d28f097b220_prof);

    }

    // line 100
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_ae712b7cec2bd680dfa5ca85199b50e1582d7eb4ea8ddbf0c3975004a55bdfc3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae712b7cec2bd680dfa5ca85199b50e1582d7eb4ea8ddbf0c3975004a55bdfc3->enter($__internal_ae712b7cec2bd680dfa5ca85199b50e1582d7eb4ea8ddbf0c3975004a55bdfc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_5997fd661becf47cbff7aea9c4afeee23ccf3b45f0cde888c79fc3b06306e8d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5997fd661becf47cbff7aea9c4afeee23ccf3b45f0cde888c79fc3b06306e8d1->enter($__internal_5997fd661becf47cbff7aea9c4afeee23ccf3b45f0cde888c79fc3b06306e8d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 101
        echo "                            ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragmentStrategy("esi", Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("FrameworkBundle:Template:template", array("template" => "blog/about.html.twig", "sharedAge" => 600, "_locale" => $this->getAttribute($this->getAttribute(        // line 104
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()))));
        // line 105
        echo "
                        ";
        
        $__internal_5997fd661becf47cbff7aea9c4afeee23ccf3b45f0cde888c79fc3b06306e8d1->leave($__internal_5997fd661becf47cbff7aea9c4afeee23ccf3b45f0cde888c79fc3b06306e8d1_prof);

        
        $__internal_ae712b7cec2bd680dfa5ca85199b50e1582d7eb4ea8ddbf0c3975004a55bdfc3->leave($__internal_ae712b7cec2bd680dfa5ca85199b50e1582d7eb4ea8ddbf0c3975004a55bdfc3_prof);

    }

    // line 112
    public function block_footer($context, array $blocks = array())
    {
        $__internal_160777d5e627d8cd96a9b9c0f613b82bb301f07e37d45f79d039baec38b5e8d6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_160777d5e627d8cd96a9b9c0f613b82bb301f07e37d45f79d039baec38b5e8d6->enter($__internal_160777d5e627d8cd96a9b9c0f613b82bb301f07e37d45f79d039baec38b5e8d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_07dd9a123ffeae3047af41e0becb4207cc2349b104de4751b56bdeb3d031227b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_07dd9a123ffeae3047af41e0becb4207cc2349b104de4751b56bdeb3d031227b->enter($__internal_07dd9a123ffeae3047af41e0becb4207cc2349b104de4751b56bdeb3d031227b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 113
        echo "            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\">
                            <p>&copy; ";
        // line 117
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " - The Symfony Project</p>
                            <p>";
        // line 118
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("mit_license"), "html", null, true);
        echo "</p>
                        </div>
                        <div id=\"footer-resources\" class=\"col-md-6\">
                            <p>
                                <a href=\"https://twitter.com/symfony\" title=\"Symfony Twitter\">
                                    <i class=\"fa fa-twitter\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://www.facebook.com/SensioLabs\" title=\"SensioLabs Facebook\">
                                    <i class=\"fa fa-facebook\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://symfony.com/blog/\" title=\"Symfony Blog\">
                                    <i class=\"fa fa-rss\" aria-hidden=\"true\"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        ";
        
        $__internal_07dd9a123ffeae3047af41e0becb4207cc2349b104de4751b56bdeb3d031227b->leave($__internal_07dd9a123ffeae3047af41e0becb4207cc2349b104de4751b56bdeb3d031227b_prof);

        
        $__internal_160777d5e627d8cd96a9b9c0f613b82bb301f07e37d45f79d039baec38b5e8d6->leave($__internal_160777d5e627d8cd96a9b9c0f613b82bb301f07e37d45f79d039baec38b5e8d6_prof);

    }

    // line 138
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_64974a370519d08a038e5c870bb1fd35fe9a17e718a69bc79e2ab5d1fa90720f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_64974a370519d08a038e5c870bb1fd35fe9a17e718a69bc79e2ab5d1fa90720f->enter($__internal_64974a370519d08a038e5c870bb1fd35fe9a17e718a69bc79e2ab5d1fa90720f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_08f9962c182260a1a8343ef44d541765a220f7b120914812408cd62b4f7fe1f2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_08f9962c182260a1a8343ef44d541765a220f7b120914812408cd62b4f7fe1f2->enter($__internal_08f9962c182260a1a8343ef44d541765a220f7b120914812408cd62b4f7fe1f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 139
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 140
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 141
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-3.3.7.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 142
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/highlight.pack.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_08f9962c182260a1a8343ef44d541765a220f7b120914812408cd62b4f7fe1f2->leave($__internal_08f9962c182260a1a8343ef44d541765a220f7b120914812408cd62b4f7fe1f2_prof);

        
        $__internal_64974a370519d08a038e5c870bb1fd35fe9a17e718a69bc79e2ab5d1fa90720f->leave($__internal_64974a370519d08a038e5c870bb1fd35fe9a17e718a69bc79e2ab5d1fa90720f_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  499 => 144,  495 => 143,  491 => 142,  487 => 141,  483 => 140,  478 => 139,  469 => 138,  440 => 118,  436 => 117,  430 => 113,  421 => 112,  410 => 105,  408 => 104,  406 => 101,  397 => 100,  380 => 96,  368 => 107,  366 => 100,  361 => 97,  359 => 96,  354 => 94,  350 => 92,  341 => 91,  331 => 61,  324 => 57,  320 => 56,  317 => 55,  315 => 54,  308 => 50,  304 => 49,  301 => 48,  292 => 47,  275 => 81,  258 => 79,  254 => 78,  248 => 75,  241 => 70,  234 => 66,  230 => 65,  227 => 64,  225 => 63,  222 => 62,  220 => 47,  208 => 38,  198 => 31,  192 => 27,  183 => 26,  166 => 24,  154 => 19,  150 => 18,  146 => 17,  142 => 16,  138 => 15,  133 => 14,  124 => 13,  106 => 11,  91 => 150,  88 => 146,  86 => 138,  83 => 137,  81 => 112,  77 => 110,  75 => 91,  71 => 89,  69 => 26,  64 => 24,  57 => 21,  55 => 13,  49 => 12,  45 => 11,  38 => 7,  35 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"{{ app.request.locale }}\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>{% block title %}Symfony Demo application{% endblock %}</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"{{ 'rss.title'|trans }}\" href=\"{{ path('blog_rss') }}\">
        {% block stylesheets %}
            <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-flatly-3.3.7.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/font-awesome-4.6.3.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/font-lato.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/highlight-solarized-light.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/main.css') }}\">
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>

    <body id=\"{% block body_id %}{% endblock %}\">

        {% block header %}
            <header>
                <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
                    <div class=\"container\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">
                                Symfony Demo
                            </a>

                            <button type=\"button\" class=\"navbar-toggle\"
                                    data-toggle=\"collapse\"
                                    data-target=\".navbar-collapse\">
                                <span class=\"sr-only\">{{ 'menu.toggle_nav'|trans }}</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav navbar-right\">

                                {% block header_navigation_links %}
                                    <li>
                                        <a href=\"{{ path('blog_index') }}\">
                                            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> {{ 'menu.homepage'|trans }}
                                        </a>
                                    </li>

                                    {% if is_granted('ROLE_ADMIN') %}
                                        <li>
                                            <a href=\"{{ path('admin_post_index') }}\">
                                                <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'menu.admin'|trans }}
                                            </a>
                                        </li>
                                    {% endif %}
                                {% endblock %}

                                {% if app.user %}
                                    <li>
                                        <a href=\"{{ path('security_logout') }}\">
                                            <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> {{ 'menu.logout'|trans }}
                                        </a>
                                    </li>
                                {% endif %}

                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" id=\"locales\">
                                        <i class=\"fa fa-globe\" aria-hidden=\"true\"></i>
                                        <span class=\"caret\"></span>
                                        <span class=\"sr-only\">{{ 'menu.choose_language'|trans }}</span>
                                    </a>
                                    <ul class=\"dropdown-menu locales\" role=\"menu\" aria-labelledby=\"locales\">
                                        {% for locale in locales() %}
                                            <li {% if app.request.locale == locale.code %}aria-checked=\"true\" class=\"active\"{%else%}aria-checked=\"false\"{% endif %} role=\"menuitem\"><a href=\"{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({ _locale: locale.code })) }}\">{{ locale.name|capitalize }}</a></li>
                                        {% endfor %}
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        {% endblock %}

        <div class=\"container body-container\">
            {% block body %}
                <div class=\"row\">
                    <div id=\"main\" class=\"col-sm-9\">
                        {{ include('default/_flash_messages.html.twig') }}

                        {% block main %}{% endblock %}
                    </div>

                    <div id=\"sidebar\" class=\"col-sm-3\">
                        {% block sidebar %}
                            {{ render_esi(controller('FrameworkBundle:Template:template', {
                                'template': 'blog/about.html.twig',
                                'sharedAge': 600,
                                '_locale': app.request.locale
                            })) }}
                        {% endblock %}
                    </div>
                </div>
            {% endblock %}
        </div>

        {% block footer %}
            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\">
                            <p>&copy; {{ 'now'|date('Y') }} - The Symfony Project</p>
                            <p>{{ 'mit_license'|trans }}</p>
                        </div>
                        <div id=\"footer-resources\" class=\"col-md-6\">
                            <p>
                                <a href=\"https://twitter.com/symfony\" title=\"Symfony Twitter\">
                                    <i class=\"fa fa-twitter\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://www.facebook.com/SensioLabs\" title=\"SensioLabs Facebook\">
                                    <i class=\"fa fa-facebook\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://symfony.com/blog/\" title=\"Symfony Blog\">
                                    <i class=\"fa fa-rss\" aria-hidden=\"true\"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        {% endblock %}

        {% block javascripts %}
            <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
            <script src=\"{{ asset('js/moment.min.js') }}\"></script>
            <script src=\"{{ asset('js/bootstrap-3.3.7.min.js') }}\"></script>
            <script src=\"{{ asset('js/highlight.pack.js') }}\"></script>
            <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
            <script src=\"{{ asset('js/main.js') }}\"></script>
        {% endblock %}

        {# it's not mandatory to set the timezone in localizeddate(). This is done to
           avoid errors when the 'intl' PHP extension is not available and the application
           is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
        <!-- Page rendered on {{ 'now'|localizeddate('long', 'long', null, 'UTC') }} -->
    </body>
</html>
", "base.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\base.html.twig");
    }
}
