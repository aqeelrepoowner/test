<?php

/* :default:homepage.html.twig */
class __TwigTemplate_93a84ff37fdda3f163f1d0e1f9ce952d6472555b18ae312a99e05cec5a6a3f56 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":default:homepage.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'footer' => array($this, 'block_footer'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a4294abfc2f7e32d924ce84adcdfed2e90ac86240d2586a0a694ace2b7a6361c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a4294abfc2f7e32d924ce84adcdfed2e90ac86240d2586a0a694ace2b7a6361c->enter($__internal_a4294abfc2f7e32d924ce84adcdfed2e90ac86240d2586a0a694ace2b7a6361c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:homepage.html.twig"));

        $__internal_41ec3ad823d40f4a47c2f42cce130a47587baf7cdc1f00cbe1973ff5277d2e89 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_41ec3ad823d40f4a47c2f42cce130a47587baf7cdc1f00cbe1973ff5277d2e89->enter($__internal_41ec3ad823d40f4a47c2f42cce130a47587baf7cdc1f00cbe1973ff5277d2e89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":default:homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a4294abfc2f7e32d924ce84adcdfed2e90ac86240d2586a0a694ace2b7a6361c->leave($__internal_a4294abfc2f7e32d924ce84adcdfed2e90ac86240d2586a0a694ace2b7a6361c_prof);

        
        $__internal_41ec3ad823d40f4a47c2f42cce130a47587baf7cdc1f00cbe1973ff5277d2e89->leave($__internal_41ec3ad823d40f4a47c2f42cce130a47587baf7cdc1f00cbe1973ff5277d2e89_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_cf0123783a747b4988931f81fb71927a279df74f2b28c72ee0aa98e8eded3335 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf0123783a747b4988931f81fb71927a279df74f2b28c72ee0aa98e8eded3335->enter($__internal_cf0123783a747b4988931f81fb71927a279df74f2b28c72ee0aa98e8eded3335_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_093345061884816cb8ec993ff3fc81405d8ea8ac2360cee49f4e6070c76c73ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_093345061884816cb8ec993ff3fc81405d8ea8ac2360cee49f4e6070c76c73ef->enter($__internal_093345061884816cb8ec993ff3fc81405d8ea8ac2360cee49f4e6070c76c73ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "homepage";
        
        $__internal_093345061884816cb8ec993ff3fc81405d8ea8ac2360cee49f4e6070c76c73ef->leave($__internal_093345061884816cb8ec993ff3fc81405d8ea8ac2360cee49f4e6070c76c73ef_prof);

        
        $__internal_cf0123783a747b4988931f81fb71927a279df74f2b28c72ee0aa98e8eded3335->leave($__internal_cf0123783a747b4988931f81fb71927a279df74f2b28c72ee0aa98e8eded3335_prof);

    }

    // line 9
    public function block_header($context, array $blocks = array())
    {
        $__internal_f23c199b5897446666a03fdd826c82e27de4bd1a141e3fe527413fe552716612 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f23c199b5897446666a03fdd826c82e27de4bd1a141e3fe527413fe552716612->enter($__internal_f23c199b5897446666a03fdd826c82e27de4bd1a141e3fe527413fe552716612_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_aa7cec44369571a79303355b1fa0047e78db05f34150e4f4cbf28e2265dccf5b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aa7cec44369571a79303355b1fa0047e78db05f34150e4f4cbf28e2265dccf5b->enter($__internal_aa7cec44369571a79303355b1fa0047e78db05f34150e4f4cbf28e2265dccf5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        
        $__internal_aa7cec44369571a79303355b1fa0047e78db05f34150e4f4cbf28e2265dccf5b->leave($__internal_aa7cec44369571a79303355b1fa0047e78db05f34150e4f4cbf28e2265dccf5b_prof);

        
        $__internal_f23c199b5897446666a03fdd826c82e27de4bd1a141e3fe527413fe552716612->leave($__internal_f23c199b5897446666a03fdd826c82e27de4bd1a141e3fe527413fe552716612_prof);

    }

    // line 10
    public function block_footer($context, array $blocks = array())
    {
        $__internal_5863fb41b4e0674743e6c9812da217389eae1a980b595f603d2c9ee2ef75c2ff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5863fb41b4e0674743e6c9812da217389eae1a980b595f603d2c9ee2ef75c2ff->enter($__internal_5863fb41b4e0674743e6c9812da217389eae1a980b595f603d2c9ee2ef75c2ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_139cbdad4bce1c4e4f638e94add84146d00b3fcf798718903c6e7f606ca1872c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_139cbdad4bce1c4e4f638e94add84146d00b3fcf798718903c6e7f606ca1872c->enter($__internal_139cbdad4bce1c4e4f638e94add84146d00b3fcf798718903c6e7f606ca1872c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_139cbdad4bce1c4e4f638e94add84146d00b3fcf798718903c6e7f606ca1872c->leave($__internal_139cbdad4bce1c4e4f638e94add84146d00b3fcf798718903c6e7f606ca1872c_prof);

        
        $__internal_5863fb41b4e0674743e6c9812da217389eae1a980b595f603d2c9ee2ef75c2ff->leave($__internal_5863fb41b4e0674743e6c9812da217389eae1a980b595f603d2c9ee2ef75c2ff_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_a1887a03c691a44738d9dd7be5b11445ff3a6359584b9f309a2e248a3c90625b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1887a03c691a44738d9dd7be5b11445ff3a6359584b9f309a2e248a3c90625b->enter($__internal_a1887a03c691a44738d9dd7be5b11445ff3a6359584b9f309a2e248a3c90625b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1287b76f0145b8afe377d11b2f6913d6ca4b9730a9429a100cd552b701d4f7b1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1287b76f0145b8afe377d11b2f6913d6ca4b9730a9429a100cd552b701d4f7b1->enter($__internal_1287b76f0145b8afe377d11b2f6913d6ca4b9730a9429a100cd552b701d4f7b1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "    <div class=\"page-header\">
        <h1>";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.homepage");
        echo "</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.browse_app");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
                        <i class=\"fa fa-users\" aria-hidden=\"true\"></i> ";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.browse_app"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>

        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.browse_admin");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">
                        <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.browse_admin"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>
    </div>
";
        
        $__internal_1287b76f0145b8afe377d11b2f6913d6ca4b9730a9429a100cd552b701d4f7b1->leave($__internal_1287b76f0145b8afe377d11b2f6913d6ca4b9730a9429a100cd552b701d4f7b1_prof);

        
        $__internal_a1887a03c691a44738d9dd7be5b11445ff3a6359584b9f309a2e248a3c90625b->leave($__internal_a1887a03c691a44738d9dd7be5b11445ff3a6359584b9f309a2e248a3c90625b_prof);

    }

    public function getTemplateName()
    {
        return ":default:homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 38,  145 => 37,  139 => 34,  127 => 25,  123 => 24,  117 => 21,  107 => 14,  104 => 13,  95 => 12,  78 => 10,  61 => 9,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'homepage' %}

{#
    the homepage is a special page which displays neither a header nor a footer.
    this is done with the 'trick' of defining empty Twig blocks without any content
#}
{% block header %}{% endblock %}
{% block footer %}{% endblock %}

{% block body %}
    <div class=\"page-header\">
        <h1>{{ 'title.homepage'|trans|raw }}</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    {{ 'help.browse_app'|trans|raw }}
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"{{ path('blog_index') }}\">
                        <i class=\"fa fa-users\" aria-hidden=\"true\"></i> {{ 'action.browse_app'|trans }}
                    </a>
                </p>
            </div>
        </div>

        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    {{ 'help.browse_admin'|trans|raw }}
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"{{ path('admin_index') }}\">
                        <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'action.browse_admin'|trans }}
                    </a>
                </p>
            </div>
        </div>
    </div>
{% endblock %}
", ":default:homepage.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/default/homepage.html.twig");
    }
}
