<?php

/* WebProfilerBundle:Profiler:toolbar_redirect.html.twig */
class __TwigTemplate_3f8b56aeb3a64b35c22511e3067243f4074b6689ed0a10dbbc6a0b614549238d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_41017e7725edd01cc6c141b095008f15e426ec1ea2a238b76850ccceff733b9a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_41017e7725edd01cc6c141b095008f15e426ec1ea2a238b76850ccceff733b9a->enter($__internal_41017e7725edd01cc6c141b095008f15e426ec1ea2a238b76850ccceff733b9a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $__internal_6fba6bd7c22db36ce588b5ebb568717c574d8643130c42009becb7a358e9cb1b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6fba6bd7c22db36ce588b5ebb568717c574d8643130c42009becb7a358e9cb1b->enter($__internal_6fba6bd7c22db36ce588b5ebb568717c574d8643130c42009becb7a358e9cb1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_41017e7725edd01cc6c141b095008f15e426ec1ea2a238b76850ccceff733b9a->leave($__internal_41017e7725edd01cc6c141b095008f15e426ec1ea2a238b76850ccceff733b9a_prof);

        
        $__internal_6fba6bd7c22db36ce588b5ebb568717c574d8643130c42009becb7a358e9cb1b->leave($__internal_6fba6bd7c22db36ce588b5ebb568717c574d8643130c42009becb7a358e9cb1b_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_3d497b1a56e212f8d77c7281506a4c307ccd58cfb658cf3a1850cba01090a66e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3d497b1a56e212f8d77c7281506a4c307ccd58cfb658cf3a1850cba01090a66e->enter($__internal_3d497b1a56e212f8d77c7281506a4c307ccd58cfb658cf3a1850cba01090a66e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ab2965b7081d74537fd673ea655f6a5e216af6261c216b032524cc536639f8c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab2965b7081d74537fd673ea655f6a5e216af6261c216b032524cc536639f8c6->enter($__internal_ab2965b7081d74537fd673ea655f6a5e216af6261c216b032524cc536639f8c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Redirection Intercepted";
        
        $__internal_ab2965b7081d74537fd673ea655f6a5e216af6261c216b032524cc536639f8c6->leave($__internal_ab2965b7081d74537fd673ea655f6a5e216af6261c216b032524cc536639f8c6_prof);

        
        $__internal_3d497b1a56e212f8d77c7281506a4c307ccd58cfb658cf3a1850cba01090a66e->leave($__internal_3d497b1a56e212f8d77c7281506a4c307ccd58cfb658cf3a1850cba01090a66e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        $__internal_ae2188f159ff313f7a0ad5ecaf51a21eb7fddf7217cdabede65c97d9f2b49283 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ae2188f159ff313f7a0ad5ecaf51a21eb7fddf7217cdabede65c97d9f2b49283->enter($__internal_ae2188f159ff313f7a0ad5ecaf51a21eb7fddf7217cdabede65c97d9f2b49283_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_779265b528dfbbe315e9a4c8c758972df7188567b1ebc3ea4945563333079099 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_779265b528dfbbe315e9a4c8c758972df7188567b1ebc3ea4945563333079099->enter($__internal_779265b528dfbbe315e9a4c8c758972df7188567b1ebc3ea4945563333079099_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"";
        // line 8
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, (isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")), "html", null, true);
        echo "</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
";
        
        $__internal_779265b528dfbbe315e9a4c8c758972df7188567b1ebc3ea4945563333079099->leave($__internal_779265b528dfbbe315e9a4c8c758972df7188567b1ebc3ea4945563333079099_prof);

        
        $__internal_ae2188f159ff313f7a0ad5ecaf51a21eb7fddf7217cdabede65c97d9f2b49283->leave($__internal_ae2188f159ff313f7a0ad5ecaf51a21eb7fddf7217cdabede65c97d9f2b49283_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:toolbar_redirect.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 8,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@Twig/layout.html.twig' %}

{% block title 'Redirection Intercepted' %}

{% block body %}
    <div class=\"sf-reset\">
        <div class=\"block-exception\">
            <h1>This request redirects to <a href=\"{{ location }}\">{{ location }}</a>.</h1>

            <p>
                <small>
                    The redirect was intercepted by the web debug toolbar to help debugging.
                    For more information, see the \"intercept-redirects\" option of the Profiler.
                </small>
            </p>
        </div>
    </div>
{% endblock %}
", "WebProfilerBundle:Profiler:toolbar_redirect.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/toolbar_redirect.html.twig");
    }
}
