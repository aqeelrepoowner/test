<?php

/* :blog:index.xml.twig */
class __TwigTemplate_d893757857fbe09a46adec310f14bc9d87d9264d65013600db8410f4110c37a0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_27212982759069bdccfa185a5a8e8da89da101b755e6897460af02d6eda35c29 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_27212982759069bdccfa185a5a8e8da89da101b755e6897460af02d6eda35c29->enter($__internal_27212982759069bdccfa185a5a8e8da89da101b755e6897460af02d6eda35c29_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:index.xml.twig"));

        $__internal_9f9efb657ba8f6a723d9392156a3964ef61d2fca840bb06adbb8b514b9ccb347 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f9efb657ba8f6a723d9392156a3964ef61d2fca840bb06adbb8b514b9ccb347->enter($__internal_9f9efb657ba8f6a723d9392156a3964ef61d2fca840bb06adbb8b514b9ccb347_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:index.xml.twig"));

        // line 1
        echo "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<rss version=\"2.0\">
    <channel>
        <title>";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("rss.title"), "html", null, true);
        echo "</title>
        <description>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("rss.description"), "html", null, true);
        echo "</description>
        <pubDate>";
        // line 6
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "r", "GMT"), "html", null, true);
        echo "</pubDate>
        <lastBuildDate>";
        // line 7
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, (($this->getAttribute(twig_last($this->env, (isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts"))), "publishedAt", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute(twig_last($this->env, (isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts"))), "publishedAt", array()), "now")) : ("now")), "r", "GMT"), "html", null, true);
        echo "</lastBuildDate>
        <link>";
        // line 8
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("blog_index");
        echo "</link>
        <language>";
        // line 9
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()), "html", null, true);
        echo "</language>

        ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 12
            echo "            <item>
                <title>";
            // line 13
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "</title>
                <description>";
            // line 14
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "summary", array()), "html", null, true);
            echo "</description>
                <link>";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("blog_post", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "</link>
                <guid>";
            // line 16
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("blog_post", array("slug" => $this->getAttribute($context["post"], "slug", array()))), "html", null, true);
            echo "</guid>
                <pubDate>";
            // line 17
            echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "r", "GMT"), "html", null, true);
            echo "</pubDate>
                <author>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "author", array()), "email", array()), "html", null, true);
            echo "</author>
            </item>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 21
        echo "    </channel>
</rss>
";
        
        $__internal_27212982759069bdccfa185a5a8e8da89da101b755e6897460af02d6eda35c29->leave($__internal_27212982759069bdccfa185a5a8e8da89da101b755e6897460af02d6eda35c29_prof);

        
        $__internal_9f9efb657ba8f6a723d9392156a3964ef61d2fca840bb06adbb8b514b9ccb347->leave($__internal_9f9efb657ba8f6a723d9392156a3964ef61d2fca840bb06adbb8b514b9ccb347_prof);

    }

    public function getTemplateName()
    {
        return ":blog:index.xml.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  91 => 21,  82 => 18,  78 => 17,  74 => 16,  70 => 15,  66 => 14,  62 => 13,  59 => 12,  55 => 11,  50 => 9,  46 => 8,  42 => 7,  38 => 6,  34 => 5,  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>
<rss version=\"2.0\">
    <channel>
        <title>{{ 'rss.title'|trans }}</title>
        <description>{{ 'rss.description'|trans }}</description>
        <pubDate>{{ 'now'|date('r', timezone='GMT') }}</pubDate>
        <lastBuildDate>{{ (posts|last).publishedAt|default('now')|date('r', timezone='GMT') }}</lastBuildDate>
        <link>{{ url('blog_index') }}</link>
        <language>{{ app.request.locale }}</language>

        {% for post in posts %}
            <item>
                <title>{{ post.title }}</title>
                <description>{{ post.summary }}</description>
                <link>{{ url('blog_post', {'slug': post.slug}) }}</link>
                <guid>{{ url('blog_post', {'slug': post.slug}) }}</guid>
                <pubDate>{{ post.publishedAt|date(format='r', timezone='GMT') }}</pubDate>
                <author>{{ post.author.email }}</author>
            </item>
        {% endfor %}
    </channel>
</rss>
", ":blog:index.xml.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/blog/index.xml.twig");
    }
}
