<?php

/* :admin:layout.html.twig */
class __TwigTemplate_983212ca046b72d47483e412ba269ec47c7a45d01190bf4f4831e0ea3e93fb1d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 8
        $this->parent = $this->loadTemplate("base.html.twig", ":admin:layout.html.twig", 8);
        $this->blocks = array(
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_104a28e8aa1a9250abddc91eb4b545d1d4c49286e3d9f5c3f6c6c84b5750e458 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_104a28e8aa1a9250abddc91eb4b545d1d4c49286e3d9f5c3f6c6c84b5750e458->enter($__internal_104a28e8aa1a9250abddc91eb4b545d1d4c49286e3d9f5c3f6c6c84b5750e458_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin:layout.html.twig"));

        $__internal_f9c2c148c5f0948b21476dfeb90d71a926186974054bc1bf829f97d8eac8e70f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9c2c148c5f0948b21476dfeb90d71a926186974054bc1bf829f97d8eac8e70f->enter($__internal_f9c2c148c5f0948b21476dfeb90d71a926186974054bc1bf829f97d8eac8e70f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin:layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_104a28e8aa1a9250abddc91eb4b545d1d4c49286e3d9f5c3f6c6c84b5750e458->leave($__internal_104a28e8aa1a9250abddc91eb4b545d1d4c49286e3d9f5c3f6c6c84b5750e458_prof);

        
        $__internal_f9c2c148c5f0948b21476dfeb90d71a926186974054bc1bf829f97d8eac8e70f->leave($__internal_f9c2c148c5f0948b21476dfeb90d71a926186974054bc1bf829f97d8eac8e70f_prof);

    }

    // line 10
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_b8113230f5553402212cb92a06e48ca902d46aec31f96f94d32a3edaa435fbb7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8113230f5553402212cb92a06e48ca902d46aec31f96f94d32a3edaa435fbb7->enter($__internal_b8113230f5553402212cb92a06e48ca902d46aec31f96f94d32a3edaa435fbb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_570e6c396dec1a158547c4274c6e5f0e6553546a0d309e05b6d1014e61f968e8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_570e6c396dec1a158547c4274c6e5f0e6553546a0d309e05b6d1014e61f968e8->enter($__internal_570e6c396dec1a158547c4274c6e5f0e6553546a0d309e05b6d1014e61f968e8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 11
        echo "    <li>
        <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">
            <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> ";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.post_list"), "html", null, true);
        echo "
        </a>
    </li>
    <li>
        <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.back_to_blog"), "html", null, true);
        echo "
        </a>
    </li>
";
        
        $__internal_570e6c396dec1a158547c4274c6e5f0e6553546a0d309e05b6d1014e61f968e8->leave($__internal_570e6c396dec1a158547c4274c6e5f0e6553546a0d309e05b6d1014e61f968e8_prof);

        
        $__internal_b8113230f5553402212cb92a06e48ca902d46aec31f96f94d32a3edaa435fbb7->leave($__internal_b8113230f5553402212cb92a06e48ca902d46aec31f96f94d32a3edaa435fbb7_prof);

    }

    public function getTemplateName()
    {
        return ":admin:layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 18,  63 => 17,  56 => 13,  52 => 12,  49 => 11,  40 => 10,  11 => 8,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template of the all backend pages. Since this layout is similar
   to the global layout, we inherit from it to just change the contents of some
   blocks. In practice, backend templates are using a three-level inheritance,
   showing how powerful, yet easy to use, is Twig's inheritance mechanism.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
{% extends 'base.html.twig' %}

{% block header_navigation_links %}
    <li>
        <a href=\"{{ path('admin_post_index') }}\">
            <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> {{ 'menu.post_list'|trans }}
        </a>
    </li>
    <li>
        <a href=\"{{ path('blog_index') }}\">
            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> {{ 'menu.back_to_blog'|trans }}
        </a>
    </li>
{% endblock %}
", ":admin:layout.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/admin/layout.html.twig");
    }
}
