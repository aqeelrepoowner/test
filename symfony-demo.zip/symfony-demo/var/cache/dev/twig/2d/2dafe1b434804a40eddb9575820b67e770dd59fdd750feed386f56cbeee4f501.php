<?php

/* :admin/blog:new.html.twig */
class __TwigTemplate_7888cffcd56953421d8bcaf9971b5b9a933a0e3f7c60b3b7e0cb63d563bfb0f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", ":admin/blog:new.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e57c579bdb1b486496dfedc39811dc29c36ee97454139d88b38fb5f3e8f43d1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e57c579bdb1b486496dfedc39811dc29c36ee97454139d88b38fb5f3e8f43d1->enter($__internal_1e57c579bdb1b486496dfedc39811dc29c36ee97454139d88b38fb5f3e8f43d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:new.html.twig"));

        $__internal_565aede90c48c7c773b9e6bda9e235073f1aad0f712b3d2bccee569c500b18ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_565aede90c48c7c773b9e6bda9e235073f1aad0f712b3d2bccee569c500b18ed->enter($__internal_565aede90c48c7c773b9e6bda9e235073f1aad0f712b3d2bccee569c500b18ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1e57c579bdb1b486496dfedc39811dc29c36ee97454139d88b38fb5f3e8f43d1->leave($__internal_1e57c579bdb1b486496dfedc39811dc29c36ee97454139d88b38fb5f3e8f43d1_prof);

        
        $__internal_565aede90c48c7c773b9e6bda9e235073f1aad0f712b3d2bccee569c500b18ed->leave($__internal_565aede90c48c7c773b9e6bda9e235073f1aad0f712b3d2bccee569c500b18ed_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_cabbb7acd9eae81c34ed08ad1d1799093c78fd9ed4c7aa2f32374968866167ba = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cabbb7acd9eae81c34ed08ad1d1799093c78fd9ed4c7aa2f32374968866167ba->enter($__internal_cabbb7acd9eae81c34ed08ad1d1799093c78fd9ed4c7aa2f32374968866167ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_50fce000ebf72351f383f9a1da39e0a4fe08231c716df353918b59b73a6aa96d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50fce000ebf72351f383f9a1da39e0a4fe08231c716df353918b59b73a6aa96d->enter($__internal_50fce000ebf72351f383f9a1da39e0a4fe08231c716df353918b59b73a6aa96d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_new";
        
        $__internal_50fce000ebf72351f383f9a1da39e0a4fe08231c716df353918b59b73a6aa96d->leave($__internal_50fce000ebf72351f383f9a1da39e0a4fe08231c716df353918b59b73a6aa96d_prof);

        
        $__internal_cabbb7acd9eae81c34ed08ad1d1799093c78fd9ed4c7aa2f32374968866167ba->leave($__internal_cabbb7acd9eae81c34ed08ad1d1799093c78fd9ed4c7aa2f32374968866167ba_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_f4145aae96e4620468a9a18cae2b96e2fdd19d4da1ce021cde993c7e2b9dd9d0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f4145aae96e4620468a9a18cae2b96e2fdd19d4da1ce021cde993c7e2b9dd9d0->enter($__internal_f4145aae96e4620468a9a18cae2b96e2fdd19d4da1ce021cde993c7e2b9dd9d0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_80a0a0cdc9194bf9c04501318b7c17245073ad1234dd09c06f89ce0188e4d8e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80a0a0cdc9194bf9c04501318b7c17245073ad1234dd09c06f89ce0188e4d8e3->enter($__internal_80a0a0cdc9194bf9c04501318b7c17245073ad1234dd09c06f89ce0188e4d8e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.post_new"), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "title", array()), 'row');
        echo "
        ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "summary", array()), 'row');
        echo "
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "content", array()), 'row');
        echo "
        ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "publishedAt", array()), 'row');
        echo "

        <input type=\"submit\" value=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.create_post"), "html", null, true);
        echo "\" class=\"btn btn-primary\" />
        ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveAndCreateNew", array()), 'widget', array("label" => "label.save_and_create_new", "attr" => array("class" => "btn btn-primary")));
        echo "
        <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\" class=\"btn btn-link\">
            ";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.back_to_list"), "html", null, true);
        echo "
        </a>
    ";
        // line 19
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_80a0a0cdc9194bf9c04501318b7c17245073ad1234dd09c06f89ce0188e4d8e3->leave($__internal_80a0a0cdc9194bf9c04501318b7c17245073ad1234dd09c06f89ce0188e4d8e3_prof);

        
        $__internal_f4145aae96e4620468a9a18cae2b96e2fdd19d4da1ce021cde993c7e2b9dd9d0->leave($__internal_f4145aae96e4620468a9a18cae2b96e2fdd19d4da1ce021cde993c7e2b9dd9d0_prof);

    }

    // line 22
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_242dfcb7a5ae760d2fe557bcf8f88197eca09b1a574a320feccab83f2f7e9a34 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_242dfcb7a5ae760d2fe557bcf8f88197eca09b1a574a320feccab83f2f7e9a34->enter($__internal_242dfcb7a5ae760d2fe557bcf8f88197eca09b1a574a320feccab83f2f7e9a34_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_fc3a3604c3808b5a19dd8eafdb10aca533866db44e95121f4b6f33412e442315 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fc3a3604c3808b5a19dd8eafdb10aca533866db44e95121f4b6f33412e442315->enter($__internal_fc3a3604c3808b5a19dd8eafdb10aca533866db44e95121f4b6f33412e442315_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 23
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 25
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_fc3a3604c3808b5a19dd8eafdb10aca533866db44e95121f4b6f33412e442315->leave($__internal_fc3a3604c3808b5a19dd8eafdb10aca533866db44e95121f4b6f33412e442315_prof);

        
        $__internal_242dfcb7a5ae760d2fe557bcf8f88197eca09b1a574a320feccab83f2f7e9a34->leave($__internal_242dfcb7a5ae760d2fe557bcf8f88197eca09b1a574a320feccab83f2f7e9a34_prof);

    }

    public function getTemplateName()
    {
        return ":admin/blog:new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 25,  134 => 23,  125 => 22,  113 => 19,  108 => 17,  104 => 16,  100 => 15,  96 => 14,  91 => 12,  87 => 11,  83 => 10,  79 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_new' %}

{% block main %}
    <h1>{{ 'title.post_new'|trans }}</h1>

    {{ form_start(form) }}
        {{ form_row(form.title) }}
        {{ form_row(form.summary) }}
        {{ form_row(form.content) }}
        {{ form_row(form.publishedAt) }}

        <input type=\"submit\" value=\"{{ 'label.create_post'|trans }}\" class=\"btn btn-primary\" />
        {{ form_widget(form.saveAndCreateNew, { label: 'label.save_and_create_new', attr: { class: 'btn btn-primary' } }) }}
        <a href=\"{{ path('admin_post_index') }}\" class=\"btn btn-link\">
            {{ 'action.back_to_list'|trans }}
        </a>
    {{ form_end(form) }}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", ":admin/blog:new.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/admin/blog/new.html.twig");
    }
}
