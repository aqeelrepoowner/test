<?php

/* :admin/blog:index.html.twig */
class __TwigTemplate_f0287ee7cd763b36f2436addb5328a06f5e5f16c9c075e11b3897def93fc6f44 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", ":admin/blog:index.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd1c8d32a3e80ebc151d85205b1fb1261957e02c7c384412119a7d97041fc831 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cd1c8d32a3e80ebc151d85205b1fb1261957e02c7c384412119a7d97041fc831->enter($__internal_cd1c8d32a3e80ebc151d85205b1fb1261957e02c7c384412119a7d97041fc831_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:index.html.twig"));

        $__internal_1804460a05c9a489dfb9289068d26bc88d3c5881a9ba45deb0863c31c9a03695 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1804460a05c9a489dfb9289068d26bc88d3c5881a9ba45deb0863c31c9a03695->enter($__internal_1804460a05c9a489dfb9289068d26bc88d3c5881a9ba45deb0863c31c9a03695_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cd1c8d32a3e80ebc151d85205b1fb1261957e02c7c384412119a7d97041fc831->leave($__internal_cd1c8d32a3e80ebc151d85205b1fb1261957e02c7c384412119a7d97041fc831_prof);

        
        $__internal_1804460a05c9a489dfb9289068d26bc88d3c5881a9ba45deb0863c31c9a03695->leave($__internal_1804460a05c9a489dfb9289068d26bc88d3c5881a9ba45deb0863c31c9a03695_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_e5123bd7338bbf33fe42c1666b7588848c081f07ee1cfd1746b72c1dfa45112a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e5123bd7338bbf33fe42c1666b7588848c081f07ee1cfd1746b72c1dfa45112a->enter($__internal_e5123bd7338bbf33fe42c1666b7588848c081f07ee1cfd1746b72c1dfa45112a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_f9b1e96ead156206d1598227afe993aace1aaa57c3ac5d6a68f86ac46a02d706 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f9b1e96ead156206d1598227afe993aace1aaa57c3ac5d6a68f86ac46a02d706->enter($__internal_f9b1e96ead156206d1598227afe993aace1aaa57c3ac5d6a68f86ac46a02d706_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_index";
        
        $__internal_f9b1e96ead156206d1598227afe993aace1aaa57c3ac5d6a68f86ac46a02d706->leave($__internal_f9b1e96ead156206d1598227afe993aace1aaa57c3ac5d6a68f86ac46a02d706_prof);

        
        $__internal_e5123bd7338bbf33fe42c1666b7588848c081f07ee1cfd1746b72c1dfa45112a->leave($__internal_e5123bd7338bbf33fe42c1666b7588848c081f07ee1cfd1746b72c1dfa45112a_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_74ca0ce4fded5f11a2e520a7ff265a94dfeddfafaf3ed35de6e10eeeb92c58ea = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_74ca0ce4fded5f11a2e520a7ff265a94dfeddfafaf3ed35de6e10eeeb92c58ea->enter($__internal_74ca0ce4fded5f11a2e520a7ff265a94dfeddfafaf3ed35de6e10eeeb92c58ea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_c16d04c0b7966b5a25fe9124571efc37d2ff9144024d2055267ccaca6c95ce0a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c16d04c0b7966b5a25fe9124571efc37d2ff9144024d2055267ccaca6c95ce0a->enter($__internal_c16d04c0b7966b5a25fe9124571efc37d2ff9144024d2055267ccaca6c95ce0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.post_list"), "html", null, true);
        echo "</h1>

    <table class=\"table table-striped table-middle-aligned\">
        <thead>
            <tr>
                <th scope=\"col\">";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.title"), "html", null, true);
        echo "</th>
                <th scope=\"col\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> ";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.published_at"), "html", null, true);
        echo "</th>
                <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> ";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.actions"), "html", null, true);
        echo "</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 17
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 18
            echo "            <tr>
                <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
            echo "</td>
                ";
            // line 23
            echo "                <td>";
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["post"], "publishedAt", array()), "medium", "short", null, "UTC"), "html", null, true);
            echo "</td>
                <td class=\"text-right\">
                    <div class=\"item-actions\">
                        <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_show", array("id" => $this->getAttribute($context["post"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-default\">
                            ";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.show"), "html", null, true);
            echo "
                        </a>

                        <a href=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_edit", array("id" => $this->getAttribute($context["post"], "id", array()))), "html", null, true);
            echo "\" class=\"btn btn-sm btn-primary\">
                            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
            // line 31
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit"), "html", null, true);
            echo "
                        </a>
                    </div>
                </td>
            </tr>
        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 37
            echo "            <tr>
                <td colspan=\"4\" align=\"center\">";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_posts_found"), "html", null, true);
            echo "</td>
           </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "        </tbody>
    </table>
";
        
        $__internal_c16d04c0b7966b5a25fe9124571efc37d2ff9144024d2055267ccaca6c95ce0a->leave($__internal_c16d04c0b7966b5a25fe9124571efc37d2ff9144024d2055267ccaca6c95ce0a_prof);

        
        $__internal_74ca0ce4fded5f11a2e520a7ff265a94dfeddfafaf3ed35de6e10eeeb92c58ea->leave($__internal_74ca0ce4fded5f11a2e520a7ff265a94dfeddfafaf3ed35de6e10eeeb92c58ea_prof);

    }

    // line 45
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_eb3709ef182b2bc2aa7b55766c2ef8140963fa2cfabc56a20ac98dc1f1d8aa94 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb3709ef182b2bc2aa7b55766c2ef8140963fa2cfabc56a20ac98dc1f1d8aa94->enter($__internal_eb3709ef182b2bc2aa7b55766c2ef8140963fa2cfabc56a20ac98dc1f1d8aa94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_78925984163d6b36f7053ea9bb4ea30749e40b39c7fb6a237fb8fa3a241b2481 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_78925984163d6b36f7053ea9bb4ea30749e40b39c7fb6a237fb8fa3a241b2481->enter($__internal_78925984163d6b36f7053ea9bb4ea30749e40b39c7fb6a237fb8fa3a241b2481_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 46
        echo "    <div class=\"section actions\">
        <a href=\"";
        // line 47
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_new");
        echo "\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> ";
        // line 48
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.create_post"), "html", null, true);
        echo "
        </a>
    </div>

    ";
        // line 52
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 54
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_78925984163d6b36f7053ea9bb4ea30749e40b39c7fb6a237fb8fa3a241b2481->leave($__internal_78925984163d6b36f7053ea9bb4ea30749e40b39c7fb6a237fb8fa3a241b2481_prof);

        
        $__internal_eb3709ef182b2bc2aa7b55766c2ef8140963fa2cfabc56a20ac98dc1f1d8aa94->leave($__internal_eb3709ef182b2bc2aa7b55766c2ef8140963fa2cfabc56a20ac98dc1f1d8aa94_prof);

    }

    public function getTemplateName()
    {
        return ":admin/blog:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  189 => 54,  184 => 52,  177 => 48,  173 => 47,  170 => 46,  161 => 45,  149 => 41,  140 => 38,  137 => 37,  126 => 31,  122 => 30,  116 => 27,  112 => 26,  105 => 23,  101 => 19,  98 => 18,  93 => 17,  86 => 13,  82 => 12,  78 => 11,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_index' %}

{% block main %}
    <h1>{{ 'title.post_list'|trans }}</h1>

    <table class=\"table table-striped table-middle-aligned\">
        <thead>
            <tr>
                <th scope=\"col\">{{ 'label.title'|trans }}</th>
                <th scope=\"col\"><i class=\"fa fa-calendar\" aria-hidden=\"true\"></i> {{ 'label.published_at'|trans }}</th>
                <th scope=\"col\" class=\"text-center\"><i class=\"fa fa-cogs\" aria-hidden=\"true\"></i> {{ 'label.actions'|trans }}</th>
            </tr>
        </thead>
        <tbody>
        {% for post in posts %}
            <tr>
                <td>{{ post.title }}</td>
                {# it's not mandatory to set the timezone in localizeddate(). This is done to
                   avoid errors when the 'intl' PHP extension is not available and the application
                   is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
                <td>{{ post.publishedAt|localizeddate('medium', 'short', null, 'UTC') }}</td>
                <td class=\"text-right\">
                    <div class=\"item-actions\">
                        <a href=\"{{ path('admin_post_show', { id: post.id }) }}\" class=\"btn btn-sm btn-default\">
                            {{ 'action.show'|trans }}
                        </a>

                        <a href=\"{{ path('admin_post_edit', { id: post.id }) }}\" class=\"btn btn-sm btn-primary\">
                            <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit'|trans }}
                        </a>
                    </div>
                </td>
            </tr>
        {% else %}
            <tr>
                <td colspan=\"4\" align=\"center\">{{ 'post.no_posts_found'|trans }}</td>
           </tr>
        {% endfor %}
        </tbody>
    </table>
{% endblock %}

{% block sidebar %}
    <div class=\"section actions\">
        <a href=\"{{ path('admin_post_new') }}\" class=\"btn btn-lg btn-block btn-success\">
            <i class=\"fa fa-plus\" aria-hidden=\"true\"></i> {{ 'action.create_post'|trans }}
        </a>
    </div>

    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", ":admin/blog:index.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/admin/blog/index.html.twig");
    }
}
