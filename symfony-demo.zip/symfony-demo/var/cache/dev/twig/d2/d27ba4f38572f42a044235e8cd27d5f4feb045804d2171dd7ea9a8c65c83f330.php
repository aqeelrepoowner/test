<?php

/* @Twig/Exception/error.txt.twig */
class __TwigTemplate_60fa486c3a85c76d67ad9b2f093457819a27f2754af04a2a23b6d63cf6ca0358 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7cd8bb6f9c68e57e7a370ba8d04175dffe4dd23b6177ef2851c5afdcd544214e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7cd8bb6f9c68e57e7a370ba8d04175dffe4dd23b6177ef2851c5afdcd544214e->enter($__internal_7cd8bb6f9c68e57e7a370ba8d04175dffe4dd23b6177ef2851c5afdcd544214e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        $__internal_0e076adb759f15124a818b6c77942e56408214eba1ad82f45fd227166c6fe5b9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0e076adb759f15124a818b6c77942e56408214eba1ad82f45fd227166c6fe5b9->enter($__internal_0e076adb759f15124a818b6c77942e56408214eba1ad82f45fd227166c6fe5b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_7cd8bb6f9c68e57e7a370ba8d04175dffe4dd23b6177ef2851c5afdcd544214e->leave($__internal_7cd8bb6f9c68e57e7a370ba8d04175dffe4dd23b6177ef2851c5afdcd544214e_prof);

        
        $__internal_0e076adb759f15124a818b6c77942e56408214eba1ad82f45fd227166c6fe5b9->leave($__internal_0e076adb759f15124a818b6c77942e56408214eba1ad82f45fd227166c6fe5b9_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 4,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("Oops! An Error Occurred
=======================

The server returned a \"{{ status_code }} {{ status_text }}\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
", "@Twig/Exception/error.txt.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.txt.twig");
    }
}
