<?php

/* form/layout.html.twig */
class __TwigTemplate_eba796cb3e6972d26caae6f23d292096ad8ca5a1ad146dd8b8b821f59bcdb0ad extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("bootstrap_3_layout.html.twig", "form/layout.html.twig", 1);
        $this->blocks = array(
            'form_errors' => array($this, 'block_form_errors'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "bootstrap_3_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a9057a918dc22549eb64593c31d06db980c7d5d2fd8aaf1f841d000502a5c505 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a9057a918dc22549eb64593c31d06db980c7d5d2fd8aaf1f841d000502a5c505->enter($__internal_a9057a918dc22549eb64593c31d06db980c7d5d2fd8aaf1f841d000502a5c505_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/layout.html.twig"));

        $__internal_aeec2d8fcb396eefc9413dc6c241b17dd0ceddd0669afb0ae27868b4434a7fe6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_aeec2d8fcb396eefc9413dc6c241b17dd0ceddd0669afb0ae27868b4434a7fe6->enter($__internal_aeec2d8fcb396eefc9413dc6c241b17dd0ceddd0669afb0ae27868b4434a7fe6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a9057a918dc22549eb64593c31d06db980c7d5d2fd8aaf1f841d000502a5c505->leave($__internal_a9057a918dc22549eb64593c31d06db980c7d5d2fd8aaf1f841d000502a5c505_prof);

        
        $__internal_aeec2d8fcb396eefc9413dc6c241b17dd0ceddd0669afb0ae27868b4434a7fe6->leave($__internal_aeec2d8fcb396eefc9413dc6c241b17dd0ceddd0669afb0ae27868b4434a7fe6_prof);

    }

    // line 5
    public function block_form_errors($context, array $blocks = array())
    {
        $__internal_048bbe556223b81d044b2c6ed645b58528b88fa866cc17e62358bd0977f2c317 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_048bbe556223b81d044b2c6ed645b58528b88fa866cc17e62358bd0977f2c317->enter($__internal_048bbe556223b81d044b2c6ed645b58528b88fa866cc17e62358bd0977f2c317_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        $__internal_6baebd53523061d577cfdb845a43d7ac3176bb6fb6a2d86136e4b9e1a7d18e2b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6baebd53523061d577cfdb845a43d7ac3176bb6fb6a2d86136e4b9e1a7d18e2b->enter($__internal_6baebd53523061d577cfdb845a43d7ac3176bb6fb6a2d86136e4b9e1a7d18e2b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_errors"));

        // line 6
        if ((twig_length_filter($this->env, (isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors"))) > 0)) {
            // line 7
            if ($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parent", array())) {
                echo "<span class=\"help-block\">";
            } else {
                echo "<div class=\"alert alert-danger\">";
            }
            // line 8
            echo "        <ul class=\"list-unstyled\">";
            // line 9
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["errors"]) ? $context["errors"] : $this->getContext($context, "errors")));
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 11
                echo "            <li><span class=\"fa fa-exclamation-triangle\"></span> ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["error"], "message", array()), "html", null, true);
                echo "</li>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "</ul>
        ";
            // line 14
            if ($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parent", array())) {
                echo "</span>";
            } else {
                echo "</div>";
            }
        }
        
        $__internal_6baebd53523061d577cfdb845a43d7ac3176bb6fb6a2d86136e4b9e1a7d18e2b->leave($__internal_6baebd53523061d577cfdb845a43d7ac3176bb6fb6a2d86136e4b9e1a7d18e2b_prof);

        
        $__internal_048bbe556223b81d044b2c6ed645b58528b88fa866cc17e62358bd0977f2c317->leave($__internal_048bbe556223b81d044b2c6ed645b58528b88fa866cc17e62358bd0977f2c317_prof);

    }

    public function getTemplateName()
    {
        return "form/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 14,  71 => 13,  63 => 11,  59 => 9,  57 => 8,  51 => 7,  49 => 6,  40 => 5,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'bootstrap_3_layout.html.twig' %}

{# Errors #}

{% block form_errors -%}
    {% if errors|length > 0 -%}
        {% if form.parent %}<span class=\"help-block\">{% else %}<div class=\"alert alert-danger\">{% endif %}
        <ul class=\"list-unstyled\">
        {%- for error in errors -%}
            {# use font-awesome icon library #}
            <li><span class=\"fa fa-exclamation-triangle\"></span> {{ error.message }}</li>
        {%- endfor -%}
        </ul>
        {% if form.parent %}</span>{% else %}</div>{% endif %}
    {%- endif %}
{%- endblock form_errors %}
", "form/layout.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\form\\layout.html.twig");
    }
}
