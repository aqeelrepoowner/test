<?php

/* TwigBundle:Exception:exception.json.twig */
class __TwigTemplate_51d026dc034647cad445727e1e41401b1fb85d07a8e2fd0269481f52a371c906 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7a8db88656d1ff29b483da465445df57bc8e1bbd83eeea9fbd0335b4ac93d495 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7a8db88656d1ff29b483da465445df57bc8e1bbd83eeea9fbd0335b4ac93d495->enter($__internal_7a8db88656d1ff29b483da465445df57bc8e1bbd83eeea9fbd0335b4ac93d495_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        $__internal_56b53d446dc3f310fceea37f946431cb8731c6faa1558d082ab5e2576b852b43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56b53d446dc3f310fceea37f946431cb8731c6faa1558d082ab5e2576b852b43->enter($__internal_56b53d446dc3f310fceea37f946431cb8731c6faa1558d082ab5e2576b852b43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_7a8db88656d1ff29b483da465445df57bc8e1bbd83eeea9fbd0335b4ac93d495->leave($__internal_7a8db88656d1ff29b483da465445df57bc8e1bbd83eeea9fbd0335b4ac93d495_prof);

        
        $__internal_56b53d446dc3f310fceea37f946431cb8731c6faa1558d082ab5e2576b852b43->leave($__internal_56b53d446dc3f310fceea37f946431cb8731c6faa1558d082ab5e2576b852b43_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "TwigBundle:Exception:exception.json.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.json.twig");
    }
}
