<?php

/* WebProfilerBundle:Profiler:open.html.twig */
class __TwigTemplate_e92bb6854f9df7af10a2ec1d9597852d4b8c78f6337d712764c7bd6c10bea9a1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/base.html.twig", "WebProfilerBundle:Profiler:open.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78e476c0dcf247fa346ba24e6c386f9c83bbbf315731392fb4fff31e35f0a7f8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_78e476c0dcf247fa346ba24e6c386f9c83bbbf315731392fb4fff31e35f0a7f8->enter($__internal_78e476c0dcf247fa346ba24e6c386f9c83bbbf315731392fb4fff31e35f0a7f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $__internal_96288ede630535b12392b9900581f25d3745f13dfc52c1d6e8d0a4155b0aeddd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_96288ede630535b12392b9900581f25d3745f13dfc52c1d6e8d0a4155b0aeddd->enter($__internal_96288ede630535b12392b9900581f25d3745f13dfc52c1d6e8d0a4155b0aeddd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:open.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_78e476c0dcf247fa346ba24e6c386f9c83bbbf315731392fb4fff31e35f0a7f8->leave($__internal_78e476c0dcf247fa346ba24e6c386f9c83bbbf315731392fb4fff31e35f0a7f8_prof);

        
        $__internal_96288ede630535b12392b9900581f25d3745f13dfc52c1d6e8d0a4155b0aeddd->leave($__internal_96288ede630535b12392b9900581f25d3745f13dfc52c1d6e8d0a4155b0aeddd_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_18577a231c83808c4d3bbf53fe7a091694883122fd28d13003b7b3f61ab52d5b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_18577a231c83808c4d3bbf53fe7a091694883122fd28d13003b7b3f61ab52d5b->enter($__internal_18577a231c83808c4d3bbf53fe7a091694883122fd28d13003b7b3f61ab52d5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_39a4aaaa421e80c5b6f50f2c67534e86134dcb4cdbbfd067ebf6cedc91ca376d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_39a4aaaa421e80c5b6f50f2c67534e86134dcb4cdbbfd067ebf6cedc91ca376d->enter($__internal_39a4aaaa421e80c5b6f50f2c67534e86134dcb4cdbbfd067ebf6cedc91ca376d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <style>
        ";
        // line 5
        echo twig_include($this->env, $context, "@WebProfiler/Profiler/open.css.twig");
        echo "
    </style>
";
        
        $__internal_39a4aaaa421e80c5b6f50f2c67534e86134dcb4cdbbfd067ebf6cedc91ca376d->leave($__internal_39a4aaaa421e80c5b6f50f2c67534e86134dcb4cdbbfd067ebf6cedc91ca376d_prof);

        
        $__internal_18577a231c83808c4d3bbf53fe7a091694883122fd28d13003b7b3f61ab52d5b->leave($__internal_18577a231c83808c4d3bbf53fe7a091694883122fd28d13003b7b3f61ab52d5b_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_cf09499df078a7275d87714f3d2e540636bf80307c39f00712df7e644ae0a746 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf09499df078a7275d87714f3d2e540636bf80307c39f00712df7e644ae0a746->enter($__internal_cf09499df078a7275d87714f3d2e540636bf80307c39f00712df7e644ae0a746_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_87a8e5b387f8e62b73f279782b48108e7646bcbdefe0a4894ee3ecf626f44f7b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_87a8e5b387f8e62b73f279782b48108e7646bcbdefe0a4894ee3ecf626f44f7b->enter($__internal_87a8e5b387f8e62b73f279782b48108e7646bcbdefe0a4894ee3ecf626f44f7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "<div class=\"header\">
    <h1>";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["file"]) ? $context["file"] : $this->getContext($context, "file")), "html", null, true);
        echo " <small>line ";
        echo twig_escape_filter($this->env, (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")), "html", null, true);
        echo "</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/";
        // line 12
        echo twig_escape_filter($this->env, twig_constant("Symfony\\Component\\HttpKernel\\Kernel::VERSION"), "html", null, true);
        echo "/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    ";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\CodeExtension')->fileExcerpt((isset($context["filename"]) ? $context["filename"] : $this->getContext($context, "filename")), (isset($context["line"]) ? $context["line"] : $this->getContext($context, "line")),  -1);
        echo "
</div>
";
        
        $__internal_87a8e5b387f8e62b73f279782b48108e7646bcbdefe0a4894ee3ecf626f44f7b->leave($__internal_87a8e5b387f8e62b73f279782b48108e7646bcbdefe0a4894ee3ecf626f44f7b_prof);

        
        $__internal_cf09499df078a7275d87714f3d2e540636bf80307c39f00712df7e644ae0a746->leave($__internal_cf09499df078a7275d87714f3d2e540636bf80307c39f00712df7e644ae0a746_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:open.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 15,  84 => 12,  78 => 11,  75 => 10,  66 => 9,  53 => 5,  50 => 4,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/base.html.twig' %}

{% block head %}
    <style>
        {{ include('@WebProfiler/Profiler/open.css.twig') }}
    </style>
{% endblock %}

{% block body %}
<div class=\"header\">
    <h1>{{ file }} <small>line {{ line }}</small></h1>
    <a class=\"doc\" href=\"https://symfony.com/doc/{{ constant('Symfony\\\\Component\\\\HttpKernel\\\\Kernel::VERSION') }}/reference/configuration/framework.html#ide\" rel=\"help\">Open in your IDE?</a>
</div>
<div class=\"source\">
    {{ filename|file_excerpt(line, -1) }}
</div>
{% endblock %}
", "WebProfilerBundle:Profiler:open.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Profiler/open.html.twig");
    }
}
