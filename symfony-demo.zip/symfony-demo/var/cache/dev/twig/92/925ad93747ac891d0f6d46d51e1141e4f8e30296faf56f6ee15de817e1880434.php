<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_89d208251872d8b697d9f73717f45fa0f1178fff2a9b75806b035a0d04135210 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3808ec6ae10268887cb060163d3c57ac10bb39dcf544b8ab1781cc89029d3e15 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3808ec6ae10268887cb060163d3c57ac10bb39dcf544b8ab1781cc89029d3e15->enter($__internal_3808ec6ae10268887cb060163d3c57ac10bb39dcf544b8ab1781cc89029d3e15_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        $__internal_23a48a1ef7e058cfa8fdc8a4cc6bad6883923622a8146b39c088de6de1b9dc40 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_23a48a1ef7e058cfa8fdc8a4cc6bad6883923622a8146b39c088de6de1b9dc40->enter($__internal_23a48a1ef7e058cfa8fdc8a4cc6bad6883923622a8146b39c088de6de1b9dc40_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_3808ec6ae10268887cb060163d3c57ac10bb39dcf544b8ab1781cc89029d3e15->leave($__internal_3808ec6ae10268887cb060163d3c57ac10bb39dcf544b8ab1781cc89029d3e15_prof);

        
        $__internal_23a48a1ef7e058cfa8fdc8a4cc6bad6883923622a8146b39c088de6de1b9dc40->leave($__internal_23a48a1ef7e058cfa8fdc8a4cc6bad6883923622a8146b39c088de6de1b9dc40_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
", "@Framework/Form/choice_options.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_options.html.php");
    }
}
