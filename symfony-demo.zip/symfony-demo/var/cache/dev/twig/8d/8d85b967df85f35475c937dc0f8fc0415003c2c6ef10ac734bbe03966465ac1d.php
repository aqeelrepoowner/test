<?php

/* admin/layout.html.twig */
class __TwigTemplate_bb4e6b297cbbd5280c66cdbf2325de52f5e20b4aa2d49b7b79f9ad765f5ae9c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 8
        $this->parent = $this->loadTemplate("base.html.twig", "admin/layout.html.twig", 8);
        $this->blocks = array(
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_36708aced578810a48018e12579c87d99379f0db28591370245e8e3100c57a50 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_36708aced578810a48018e12579c87d99379f0db28591370245e8e3100c57a50->enter($__internal_36708aced578810a48018e12579c87d99379f0db28591370245e8e3100c57a50_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/layout.html.twig"));

        $__internal_a02898eb48195c2b479ee83a59ce5415b0564497052e478ba9d35b15f673b504 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a02898eb48195c2b479ee83a59ce5415b0564497052e478ba9d35b15f673b504->enter($__internal_a02898eb48195c2b479ee83a59ce5415b0564497052e478ba9d35b15f673b504_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_36708aced578810a48018e12579c87d99379f0db28591370245e8e3100c57a50->leave($__internal_36708aced578810a48018e12579c87d99379f0db28591370245e8e3100c57a50_prof);

        
        $__internal_a02898eb48195c2b479ee83a59ce5415b0564497052e478ba9d35b15f673b504->leave($__internal_a02898eb48195c2b479ee83a59ce5415b0564497052e478ba9d35b15f673b504_prof);

    }

    // line 10
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_22cca85da47d04abe2da92192d0809f1124da528fcc7eca55f15869f311eb9ef = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_22cca85da47d04abe2da92192d0809f1124da528fcc7eca55f15869f311eb9ef->enter($__internal_22cca85da47d04abe2da92192d0809f1124da528fcc7eca55f15869f311eb9ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_ac48f019a034091b3209374b17988e661ff230841e2c889eae648eb526245804 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ac48f019a034091b3209374b17988e661ff230841e2c889eae648eb526245804->enter($__internal_ac48f019a034091b3209374b17988e661ff230841e2c889eae648eb526245804_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 11
        echo "    <li>
        <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
        echo "\">
            <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> ";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.post_list"), "html", null, true);
        echo "
        </a>
    </li>
    <li>
        <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> ";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.back_to_blog"), "html", null, true);
        echo "
        </a>
    </li>
";
        
        $__internal_ac48f019a034091b3209374b17988e661ff230841e2c889eae648eb526245804->leave($__internal_ac48f019a034091b3209374b17988e661ff230841e2c889eae648eb526245804_prof);

        
        $__internal_22cca85da47d04abe2da92192d0809f1124da528fcc7eca55f15869f311eb9ef->leave($__internal_22cca85da47d04abe2da92192d0809f1124da528fcc7eca55f15869f311eb9ef_prof);

    }

    public function getTemplateName()
    {
        return "admin/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  67 => 18,  63 => 17,  56 => 13,  52 => 12,  49 => 11,  40 => 10,  11 => 8,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template of the all backend pages. Since this layout is similar
   to the global layout, we inherit from it to just change the contents of some
   blocks. In practice, backend templates are using a three-level inheritance,
   showing how powerful, yet easy to use, is Twig's inheritance mechanism.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
{% extends 'base.html.twig' %}

{% block header_navigation_links %}
    <li>
        <a href=\"{{ path('admin_post_index') }}\">
            <i class=\"fa fa-list-alt\" aria-hidden=\"true\"></i> {{ 'menu.post_list'|trans }}
        </a>
    </li>
    <li>
        <a href=\"{{ path('blog_index') }}\">
            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> {{ 'menu.back_to_blog'|trans }}
        </a>
    </li>
{% endblock %}
", "admin/layout.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\admin\\layout.html.twig");
    }
}
