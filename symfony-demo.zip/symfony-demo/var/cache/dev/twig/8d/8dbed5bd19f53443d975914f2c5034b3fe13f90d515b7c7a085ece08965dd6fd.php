<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_9d07331a1d0797c52f098fd3c74fc68c8a6b66d2b58b125bf770395d164625b1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57427ae8af9fd14950928b57d54e2b45a663026687da7e08d97801a5862a3f82 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_57427ae8af9fd14950928b57d54e2b45a663026687da7e08d97801a5862a3f82->enter($__internal_57427ae8af9fd14950928b57d54e2b45a663026687da7e08d97801a5862a3f82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        $__internal_d8ada625465d2431a283377cfa62f17f06ff4eaa62e92d65b21f63605121b78b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d8ada625465d2431a283377cfa62f17f06ff4eaa62e92d65b21f63605121b78b->enter($__internal_d8ada625465d2431a283377cfa62f17f06ff4eaa62e92d65b21f63605121b78b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_57427ae8af9fd14950928b57d54e2b45a663026687da7e08d97801a5862a3f82->leave($__internal_57427ae8af9fd14950928b57d54e2b45a663026687da7e08d97801a5862a3f82_prof);

        
        $__internal_d8ada625465d2431a283377cfa62f17f06ff4eaa62e92d65b21f63605121b78b->leave($__internal_d8ada625465d2431a283377cfa62f17f06ff4eaa62e92d65b21f63605121b78b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
", "@Framework/Form/integer_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\integer_widget.html.php");
    }
}
