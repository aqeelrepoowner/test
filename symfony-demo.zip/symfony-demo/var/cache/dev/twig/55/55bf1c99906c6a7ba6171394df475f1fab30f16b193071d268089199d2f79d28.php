<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_caca90fc21138a32793429023fb2fe79ab85ada60f338340f4019fe79cf65269 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d3cbe25c88fe84774c3e88395e32b15b36afbabbd05f8f0ff9b22e51954c131 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d3cbe25c88fe84774c3e88395e32b15b36afbabbd05f8f0ff9b22e51954c131->enter($__internal_8d3cbe25c88fe84774c3e88395e32b15b36afbabbd05f8f0ff9b22e51954c131_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_91a68376719ee3a8240edf467628407593b02ad00c33358d1f44d6f85f236169 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91a68376719ee3a8240edf467628407593b02ad00c33358d1f44d6f85f236169->enter($__internal_91a68376719ee3a8240edf467628407593b02ad00c33358d1f44d6f85f236169_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.js.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_8d3cbe25c88fe84774c3e88395e32b15b36afbabbd05f8f0ff9b22e51954c131->leave($__internal_8d3cbe25c88fe84774c3e88395e32b15b36afbabbd05f8f0ff9b22e51954c131_prof);

        
        $__internal_91a68376719ee3a8240edf467628407593b02ad00c33358d1f44d6f85f236169->leave($__internal_91a68376719ee3a8240edf467628407593b02ad00c33358d1f44d6f85f236169_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "@Twig/Exception/exception.js.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.js.twig");
    }
}
