<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_a651abd3d7e65ec055a1c7700e787fb5cc43775535bbd44b384d927bfba0db72 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d20992f495489040556d233dafb1576a5558ea7b5fbd237aa940ee82006dfd64 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d20992f495489040556d233dafb1576a5558ea7b5fbd237aa940ee82006dfd64->enter($__internal_d20992f495489040556d233dafb1576a5558ea7b5fbd237aa940ee82006dfd64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        $__internal_5cc856335d8caeae64a21607668248e623903cd0b851a24c29a18c5b4e35a3ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5cc856335d8caeae64a21607668248e623903cd0b851a24c29a18c5b4e35a3ec->enter($__internal_5cc856335d8caeae64a21607668248e623903cd0b851a24c29a18c5b4e35a3ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_d20992f495489040556d233dafb1576a5558ea7b5fbd237aa940ee82006dfd64->leave($__internal_d20992f495489040556d233dafb1576a5558ea7b5fbd237aa940ee82006dfd64_prof);

        
        $__internal_5cc856335d8caeae64a21607668248e623903cd0b851a24c29a18c5b4e35a3ec->leave($__internal_5cc856335d8caeae64a21607668248e623903cd0b851a24c29a18c5b4e35a3ec_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
", "@Framework/Form/checkbox_widget.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\checkbox_widget.html.php");
    }
}
