<?php

/* TwigBundle:Exception:traces.txt.twig */
class __TwigTemplate_3e0c393154b92b2a0b27abae0087e86892af88a0bf42d008cdebea132a58de9f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4a9726ddfa512faf9741a81179f6eca8bf77058f5efcb5b61797e0c39dd469af = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4a9726ddfa512faf9741a81179f6eca8bf77058f5efcb5b61797e0c39dd469af->enter($__internal_4a9726ddfa512faf9741a81179f6eca8bf77058f5efcb5b61797e0c39dd469af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:traces.txt.twig"));

        $__internal_d6fb8c7b4cf15bc762a30d18e51eca8925057edd31b53f0fe809dc1ccc773963 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6fb8c7b4cf15bc762a30d18e51eca8925057edd31b53f0fe809dc1ccc773963->enter($__internal_d6fb8c7b4cf15bc762a30d18e51eca8925057edd31b53f0fe809dc1ccc773963_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:traces.txt.twig"));

        // line 1
        if (twig_length_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "trace", array()))) {
            // line 2
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "trace", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
                // line 3
                $this->loadTemplate("@Twig/Exception/trace.txt.twig", "TwigBundle:Exception:traces.txt.twig", 3)->display(array("trace" => $context["trace"]));
                // line 4
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        
        $__internal_4a9726ddfa512faf9741a81179f6eca8bf77058f5efcb5b61797e0c39dd469af->leave($__internal_4a9726ddfa512faf9741a81179f6eca8bf77058f5efcb5b61797e0c39dd469af_prof);

        
        $__internal_d6fb8c7b4cf15bc762a30d18e51eca8925057edd31b53f0fe809dc1ccc773963->leave($__internal_d6fb8c7b4cf15bc762a30d18e51eca8925057edd31b53f0fe809dc1ccc773963_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:traces.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 4,  31 => 3,  27 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if exception.trace|length %}
{% for trace in exception.trace %}
{% include '@Twig/Exception/trace.txt.twig' with { 'trace': trace } only %}

{% endfor %}
{% endif %}
", "TwigBundle:Exception:traces.txt.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/traces.txt.twig");
    }
}
