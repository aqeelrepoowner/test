<?php

/* TwigBundle:Exception:error.rdf.twig */
class __TwigTemplate_42943301f5d98ec4c25ecfee290c599252b0ebf808c484c1c6fd713f947265ac extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b53290b186280ae1b7a4e070395f15d10b614d7e058796a12d98a5a65042e182 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b53290b186280ae1b7a4e070395f15d10b614d7e058796a12d98a5a65042e182->enter($__internal_b53290b186280ae1b7a4e070395f15d10b614d7e058796a12d98a5a65042e182_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        $__internal_d1892b0462f44742ed26c4f25bca5d755bf9d693d3e176463110561e6cacedff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1892b0462f44742ed26c4f25bca5d755bf9d693d3e176463110561e6cacedff->enter($__internal_d1892b0462f44742ed26c4f25bca5d755bf9d693d3e176463110561e6cacedff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.rdf.twig", 1)->display($context);
        
        $__internal_b53290b186280ae1b7a4e070395f15d10b614d7e058796a12d98a5a65042e182->leave($__internal_b53290b186280ae1b7a4e070395f15d10b614d7e058796a12d98a5a65042e182_prof);

        
        $__internal_d1892b0462f44742ed26c4f25bca5d755bf9d693d3e176463110561e6cacedff->leave($__internal_d1892b0462f44742ed26c4f25bca5d755bf9d693d3e176463110561e6cacedff_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.rdf.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.rdf.twig");
    }
}
