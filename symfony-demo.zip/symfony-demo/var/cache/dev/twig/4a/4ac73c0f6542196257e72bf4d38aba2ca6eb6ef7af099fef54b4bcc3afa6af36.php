<?php

/* default/homepage.html.twig */
class __TwigTemplate_7ac7da08d5a3f00c686a695849a4a41ffb2267a3947df0c09e6bcdf1a081152c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/homepage.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'footer' => array($this, 'block_footer'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a62d644413dda4eb6bcc678a16cdf4c9af6c957e24ceab0a795734ce02d0f32 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a62d644413dda4eb6bcc678a16cdf4c9af6c957e24ceab0a795734ce02d0f32->enter($__internal_9a62d644413dda4eb6bcc678a16cdf4c9af6c957e24ceab0a795734ce02d0f32_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/homepage.html.twig"));

        $__internal_ed83a7c0004bed3c256e5ba766cc43b3ee6a2d2178933c502124c8e525530c61 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ed83a7c0004bed3c256e5ba766cc43b3ee6a2d2178933c502124c8e525530c61->enter($__internal_ed83a7c0004bed3c256e5ba766cc43b3ee6a2d2178933c502124c8e525530c61_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/homepage.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9a62d644413dda4eb6bcc678a16cdf4c9af6c957e24ceab0a795734ce02d0f32->leave($__internal_9a62d644413dda4eb6bcc678a16cdf4c9af6c957e24ceab0a795734ce02d0f32_prof);

        
        $__internal_ed83a7c0004bed3c256e5ba766cc43b3ee6a2d2178933c502124c8e525530c61->leave($__internal_ed83a7c0004bed3c256e5ba766cc43b3ee6a2d2178933c502124c8e525530c61_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_eb8925acb576591ef5ef28c1bef59079cff2d57edb5a9c49e9ed1dac2e8a094a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_eb8925acb576591ef5ef28c1bef59079cff2d57edb5a9c49e9ed1dac2e8a094a->enter($__internal_eb8925acb576591ef5ef28c1bef59079cff2d57edb5a9c49e9ed1dac2e8a094a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_82d8606106bbed8b8613b73ce5d12bfa96860a160da64d052f0b32ae16637297 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_82d8606106bbed8b8613b73ce5d12bfa96860a160da64d052f0b32ae16637297->enter($__internal_82d8606106bbed8b8613b73ce5d12bfa96860a160da64d052f0b32ae16637297_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "homepage";
        
        $__internal_82d8606106bbed8b8613b73ce5d12bfa96860a160da64d052f0b32ae16637297->leave($__internal_82d8606106bbed8b8613b73ce5d12bfa96860a160da64d052f0b32ae16637297_prof);

        
        $__internal_eb8925acb576591ef5ef28c1bef59079cff2d57edb5a9c49e9ed1dac2e8a094a->leave($__internal_eb8925acb576591ef5ef28c1bef59079cff2d57edb5a9c49e9ed1dac2e8a094a_prof);

    }

    // line 9
    public function block_header($context, array $blocks = array())
    {
        $__internal_7012d1327a535c68b5aaeddeeb3cce4b77b889c32b289fec10aaafa391766769 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7012d1327a535c68b5aaeddeeb3cce4b77b889c32b289fec10aaafa391766769->enter($__internal_7012d1327a535c68b5aaeddeeb3cce4b77b889c32b289fec10aaafa391766769_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_4bebab005357d910b97d1f5ef1d3d34e023d69781f3eaff2b2c1fe1f10f0ef00 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4bebab005357d910b97d1f5ef1d3d34e023d69781f3eaff2b2c1fe1f10f0ef00->enter($__internal_4bebab005357d910b97d1f5ef1d3d34e023d69781f3eaff2b2c1fe1f10f0ef00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        
        $__internal_4bebab005357d910b97d1f5ef1d3d34e023d69781f3eaff2b2c1fe1f10f0ef00->leave($__internal_4bebab005357d910b97d1f5ef1d3d34e023d69781f3eaff2b2c1fe1f10f0ef00_prof);

        
        $__internal_7012d1327a535c68b5aaeddeeb3cce4b77b889c32b289fec10aaafa391766769->leave($__internal_7012d1327a535c68b5aaeddeeb3cce4b77b889c32b289fec10aaafa391766769_prof);

    }

    // line 10
    public function block_footer($context, array $blocks = array())
    {
        $__internal_368c28825f37d6c129a3d7fcc06eb5626d9205d03248bb83682efe205a6b9805 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_368c28825f37d6c129a3d7fcc06eb5626d9205d03248bb83682efe205a6b9805->enter($__internal_368c28825f37d6c129a3d7fcc06eb5626d9205d03248bb83682efe205a6b9805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_25d6806e5ce66373ca793010e42337e4dbd6b0e0494e3040e635604414525195 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_25d6806e5ce66373ca793010e42337e4dbd6b0e0494e3040e635604414525195->enter($__internal_25d6806e5ce66373ca793010e42337e4dbd6b0e0494e3040e635604414525195_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        
        $__internal_25d6806e5ce66373ca793010e42337e4dbd6b0e0494e3040e635604414525195->leave($__internal_25d6806e5ce66373ca793010e42337e4dbd6b0e0494e3040e635604414525195_prof);

        
        $__internal_368c28825f37d6c129a3d7fcc06eb5626d9205d03248bb83682efe205a6b9805->leave($__internal_368c28825f37d6c129a3d7fcc06eb5626d9205d03248bb83682efe205a6b9805_prof);

    }

    // line 12
    public function block_body($context, array $blocks = array())
    {
        $__internal_8852e0d1c4f9bacc03dd35b96eabbdde02d00ff1ecdf61173f21a6cee6cbb36e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8852e0d1c4f9bacc03dd35b96eabbdde02d00ff1ecdf61173f21a6cee6cbb36e->enter($__internal_8852e0d1c4f9bacc03dd35b96eabbdde02d00ff1ecdf61173f21a6cee6cbb36e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_fcc514526641698c861bd1f58eab35cf97c26112ee9dc3b9ed48ad750a4d55db = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fcc514526641698c861bd1f58eab35cf97c26112ee9dc3b9ed48ad750a4d55db->enter($__internal_fcc514526641698c861bd1f58eab35cf97c26112ee9dc3b9ed48ad750a4d55db_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 13
        echo "    <div class=\"page-header\">
        <h1>";
        // line 14
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.homepage");
        echo "</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 21
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.browse_app");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 24
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
                        <i class=\"fa fa-users\" aria-hidden=\"true\"></i> ";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.browse_app"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>

        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    ";
        // line 34
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("help.browse_admin");
        echo "
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"";
        // line 37
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_index");
        echo "\">
                        <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.browse_admin"), "html", null, true);
        echo "
                    </a>
                </p>
            </div>
        </div>
    </div>
";
        
        $__internal_fcc514526641698c861bd1f58eab35cf97c26112ee9dc3b9ed48ad750a4d55db->leave($__internal_fcc514526641698c861bd1f58eab35cf97c26112ee9dc3b9ed48ad750a4d55db_prof);

        
        $__internal_8852e0d1c4f9bacc03dd35b96eabbdde02d00ff1ecdf61173f21a6cee6cbb36e->leave($__internal_8852e0d1c4f9bacc03dd35b96eabbdde02d00ff1ecdf61173f21a6cee6cbb36e_prof);

    }

    public function getTemplateName()
    {
        return "default/homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  149 => 38,  145 => 37,  139 => 34,  127 => 25,  123 => 24,  117 => 21,  107 => 14,  104 => 13,  95 => 12,  78 => 10,  61 => 9,  43 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'homepage' %}

{#
    the homepage is a special page which displays neither a header nor a footer.
    this is done with the 'trick' of defining empty Twig blocks without any content
#}
{% block header %}{% endblock %}
{% block footer %}{% endblock %}

{% block body %}
    <div class=\"page-header\">
        <h1>{{ 'title.homepage'|trans|raw }}</h1>
    </div>

    <div class=\"row\">
        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    {{ 'help.browse_app'|trans|raw }}
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"{{ path('blog_index') }}\">
                        <i class=\"fa fa-users\" aria-hidden=\"true\"></i> {{ 'action.browse_app'|trans }}
                    </a>
                </p>
            </div>
        </div>

        <div class=\"col-sm-6\">
            <div class=\"jumbotron\">
                <p>
                    {{ 'help.browse_admin'|trans|raw }}
                </p>
                <p>
                    <a class=\"btn btn-primary btn-lg\" href=\"{{ path('admin_index') }}\">
                        <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'action.browse_admin'|trans }}
                    </a>
                </p>
            </div>
        </div>
    </div>
{% endblock %}
", "default/homepage.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\default\\homepage.html.twig");
    }
}
