<?php

/* @Twig/Exception/exception.atom.twig */
class __TwigTemplate_73d2b6a9600f2f0164d89aaf724eda1ed6b2dbd6b788f9b172b9204ed9362961 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fdb8a3cef05b80a72167cbb6785c4464631ea564bc330418ecdbf743ae6556c6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fdb8a3cef05b80a72167cbb6785c4464631ea564bc330418ecdbf743ae6556c6->enter($__internal_fdb8a3cef05b80a72167cbb6785c4464631ea564bc330418ecdbf743ae6556c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        $__internal_0809cf2aa1b3a357f3b37f2246547dab452c63ca016cca64635f9080944b39f5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0809cf2aa1b3a357f3b37f2246547dab452c63ca016cca64635f9080944b39f5->enter($__internal_0809cf2aa1b3a357f3b37f2246547dab452c63ca016cca64635f9080944b39f5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "@Twig/Exception/exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_fdb8a3cef05b80a72167cbb6785c4464631ea564bc330418ecdbf743ae6556c6->leave($__internal_fdb8a3cef05b80a72167cbb6785c4464631ea564bc330418ecdbf743ae6556c6_prof);

        
        $__internal_0809cf2aa1b3a357f3b37f2246547dab452c63ca016cca64635f9080944b39f5->leave($__internal_0809cf2aa1b3a357f3b37f2246547dab452c63ca016cca64635f9080944b39f5_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "@Twig/Exception/exception.atom.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.atom.twig");
    }
}
