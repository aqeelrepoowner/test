<?php

/* :admin/blog:edit.html.twig */
class __TwigTemplate_848caf0b069b913074c04485fea4156705949c05d5cdc597e2c5069609f2df82 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", ":admin/blog:edit.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f41664e155771b19776e8bea38af46da0f17820b7bbf4bedb8db09f8abfc6932 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f41664e155771b19776e8bea38af46da0f17820b7bbf4bedb8db09f8abfc6932->enter($__internal_f41664e155771b19776e8bea38af46da0f17820b7bbf4bedb8db09f8abfc6932_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:edit.html.twig"));

        $__internal_dc1edfb1ac3b0e277f951b79487588abef47fa052e6619d1641f4599db9de941 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dc1edfb1ac3b0e277f951b79487588abef47fa052e6619d1641f4599db9de941->enter($__internal_dc1edfb1ac3b0e277f951b79487588abef47fa052e6619d1641f4599db9de941_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":admin/blog:edit.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f41664e155771b19776e8bea38af46da0f17820b7bbf4bedb8db09f8abfc6932->leave($__internal_f41664e155771b19776e8bea38af46da0f17820b7bbf4bedb8db09f8abfc6932_prof);

        
        $__internal_dc1edfb1ac3b0e277f951b79487588abef47fa052e6619d1641f4599db9de941->leave($__internal_dc1edfb1ac3b0e277f951b79487588abef47fa052e6619d1641f4599db9de941_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_5c886df605b85f675af97efa5edb26773bc80d9d1d109553df4fac97a721dd3b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5c886df605b85f675af97efa5edb26773bc80d9d1d109553df4fac97a721dd3b->enter($__internal_5c886df605b85f675af97efa5edb26773bc80d9d1d109553df4fac97a721dd3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_55ceeb9d78a327386216f818f0ea9fc88a6aad36063504f7f4e3c0f4babe4dc3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_55ceeb9d78a327386216f818f0ea9fc88a6aad36063504f7f4e3c0f4babe4dc3->enter($__internal_55ceeb9d78a327386216f818f0ea9fc88a6aad36063504f7f4e3c0f4babe4dc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_edit";
        
        $__internal_55ceeb9d78a327386216f818f0ea9fc88a6aad36063504f7f4e3c0f4babe4dc3->leave($__internal_55ceeb9d78a327386216f818f0ea9fc88a6aad36063504f7f4e3c0f4babe4dc3_prof);

        
        $__internal_5c886df605b85f675af97efa5edb26773bc80d9d1d109553df4fac97a721dd3b->leave($__internal_5c886df605b85f675af97efa5edb26773bc80d9d1d109553df4fac97a721dd3b_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_cb2ddbfa6f29171ee01e64675fc799f9fc68614c83a544439afba61a1353501e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cb2ddbfa6f29171ee01e64675fc799f9fc68614c83a544439afba61a1353501e->enter($__internal_cb2ddbfa6f29171ee01e64675fc799f9fc68614c83a544439afba61a1353501e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_cc36dc68f196add480aa69c83462c21eeb940c83fd5598940a66a2a7eab1b0ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cc36dc68f196add480aa69c83462c21eeb940c83fd5598940a66a2a7eab1b0ef->enter($__internal_cc36dc68f196add480aa69c83462c21eeb940c83fd5598940a66a2a7eab1b0ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.edit_post", array("%id%" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo twig_include($this->env, $context, "admin/blog/_form.html.twig", array("form" =>         // line 9
(isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "button_label" => $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.save"), "include_back_to_home_link" => true), false);
        // line 12
        echo "
";
        
        $__internal_cc36dc68f196add480aa69c83462c21eeb940c83fd5598940a66a2a7eab1b0ef->leave($__internal_cc36dc68f196add480aa69c83462c21eeb940c83fd5598940a66a2a7eab1b0ef_prof);

        
        $__internal_cb2ddbfa6f29171ee01e64675fc799f9fc68614c83a544439afba61a1353501e->leave($__internal_cb2ddbfa6f29171ee01e64675fc799f9fc68614c83a544439afba61a1353501e_prof);

    }

    // line 15
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_fea10f406b412ec3c8e1c8a2e1a634c34f7c24b4a543116f33d2ed7e1ab3c9bb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fea10f406b412ec3c8e1c8a2e1a634c34f7c24b4a543116f33d2ed7e1ab3c9bb->enter($__internal_fea10f406b412ec3c8e1c8a2e1a634c34f7c24b4a543116f33d2ed7e1ab3c9bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_2fb8fb2e5968d5cd2ac6639e2880e87ee3376d289fb12d0b064e7cbe522e8aeb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2fb8fb2e5968d5cd2ac6639e2880e87ee3376d289fb12d0b064e7cbe522e8aeb->enter($__internal_2fb8fb2e5968d5cd2ac6639e2880e87ee3376d289fb12d0b064e7cbe522e8aeb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 16
        echo "    <div class=\"section actions\">
        ";
        // line 17
        echo twig_include($this->env, $context, "admin/blog/_delete_form.html.twig", array("post" => (isset($context["post"]) ? $context["post"] : $this->getContext($context, "post"))), false);
        echo "
    </div>

    ";
        // line 20
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 22
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_2fb8fb2e5968d5cd2ac6639e2880e87ee3376d289fb12d0b064e7cbe522e8aeb->leave($__internal_2fb8fb2e5968d5cd2ac6639e2880e87ee3376d289fb12d0b064e7cbe522e8aeb_prof);

        
        $__internal_fea10f406b412ec3c8e1c8a2e1a634c34f7c24b4a543116f33d2ed7e1ab3c9bb->leave($__internal_fea10f406b412ec3c8e1c8a2e1a634c34f7c24b4a543116f33d2ed7e1ab3c9bb_prof);

    }

    public function getTemplateName()
    {
        return ":admin/blog:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  112 => 22,  107 => 20,  101 => 17,  98 => 16,  89 => 15,  78 => 12,  76 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_edit' %}

{% block main %}
    <h1>{{ 'title.edit_post'|trans({'%id%': post.id}) }}</h1>

    {{ include('admin/blog/_form.html.twig', {
        form: form,
        button_label: 'action.save'|trans,
        include_back_to_home_link: true,
    }, with_context = false) }}
{% endblock %}

{% block sidebar %}
    <div class=\"section actions\">
        {{ include('admin/blog/_delete_form.html.twig', { post: post }, with_context = false) }}
    </div>

    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", ":admin/blog:edit.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/admin/blog/edit.html.twig");
    }
}
