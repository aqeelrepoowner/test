<?php

/* @Twig/Exception/error.rdf.twig */
class __TwigTemplate_419b706bac259489639766f63c3933734e22acd92604aeeb26f48b6beee6c51f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7408cc245f6809b968a649e65bd546c30efbe503ec5a39e5e210b3ab19a97b4a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7408cc245f6809b968a649e65bd546c30efbe503ec5a39e5e210b3ab19a97b4a->enter($__internal_7408cc245f6809b968a649e65bd546c30efbe503ec5a39e5e210b3ab19a97b4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        $__internal_deac7a4d0d9eaa6789abd39b941ba11ccdc27222a91a50a83f72cf009d8160c0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_deac7a4d0d9eaa6789abd39b941ba11ccdc27222a91a50a83f72cf009d8160c0->enter($__internal_deac7a4d0d9eaa6789abd39b941ba11ccdc27222a91a50a83f72cf009d8160c0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.rdf.twig", 1)->display($context);
        
        $__internal_7408cc245f6809b968a649e65bd546c30efbe503ec5a39e5e210b3ab19a97b4a->leave($__internal_7408cc245f6809b968a649e65bd546c30efbe503ec5a39e5e210b3ab19a97b4a_prof);

        
        $__internal_deac7a4d0d9eaa6789abd39b941ba11ccdc27222a91a50a83f72cf009d8160c0->leave($__internal_deac7a4d0d9eaa6789abd39b941ba11ccdc27222a91a50a83f72cf009d8160c0_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.rdf.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.rdf.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.rdf.twig");
    }
}
