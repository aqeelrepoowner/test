<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_eba142bbefb7b1565e7f390bb8b6f2f4bbc67e73aa6a72ff2af497c4e3337774 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_274753f4a90b9032dae721cf1000bf83785c6d81fae181539b52a46652848141 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_274753f4a90b9032dae721cf1000bf83785c6d81fae181539b52a46652848141->enter($__internal_274753f4a90b9032dae721cf1000bf83785c6d81fae181539b52a46652848141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        $__internal_37fbec76458e4183bcd40acd268d4e3bc3e949d822ee39ad88011752109b0e19 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_37fbec76458e4183bcd40acd268d4e3bc3e949d822ee39ad88011752109b0e19->enter($__internal_37fbec76458e4183bcd40acd268d4e3bc3e949d822ee39ad88011752109b0e19_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_274753f4a90b9032dae721cf1000bf83785c6d81fae181539b52a46652848141->leave($__internal_274753f4a90b9032dae721cf1000bf83785c6d81fae181539b52a46652848141_prof);

        
        $__internal_37fbec76458e4183bcd40acd268d4e3bc3e949d822ee39ad88011752109b0e19->leave($__internal_37fbec76458e4183bcd40acd268d4e3bc3e949d822ee39ad88011752109b0e19_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "TwigBundle:Exception:error.atom.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.atom.twig");
    }
}
