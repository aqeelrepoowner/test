<?php

/* @Twig/Exception/error.atom.twig */
class __TwigTemplate_2b281973648c946c1d82b53cb7d3e27e86222cc7991c33fe2fa1594406dfcd0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e2949ecc6abb8627cb09eb75c55e5cc9adfad735414ba6195d56ebf6af19fee1 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e2949ecc6abb8627cb09eb75c55e5cc9adfad735414ba6195d56ebf6af19fee1->enter($__internal_e2949ecc6abb8627cb09eb75c55e5cc9adfad735414ba6195d56ebf6af19fee1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        $__internal_e6e17923feabcffa22874647d404cccc5f9d1aa22fa25093387120a3a60302a6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6e17923feabcffa22874647d404cccc5f9d1aa22fa25093387120a3a60302a6->enter($__internal_e6e17923feabcffa22874647d404cccc5f9d1aa22fa25093387120a3a60302a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "@Twig/Exception/error.atom.twig", 1)->display($context);
        
        $__internal_e2949ecc6abb8627cb09eb75c55e5cc9adfad735414ba6195d56ebf6af19fee1->leave($__internal_e2949ecc6abb8627cb09eb75c55e5cc9adfad735414ba6195d56ebf6af19fee1_prof);

        
        $__internal_e6e17923feabcffa22874647d404cccc5f9d1aa22fa25093387120a3a60302a6->leave($__internal_e6e17923feabcffa22874647d404cccc5f9d1aa22fa25093387120a3a60302a6_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/error.xml.twig' %}
", "@Twig/Exception/error.atom.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.atom.twig");
    }
}
