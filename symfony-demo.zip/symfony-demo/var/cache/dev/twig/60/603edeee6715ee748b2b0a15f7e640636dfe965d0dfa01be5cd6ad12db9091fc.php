<?php

/* admin/students/new.html.twig */
class __TwigTemplate_bb81acfae86c100da3e046f643be29e89f83c4b4fcc93434cc650de14bd5f8b7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("admin/layout.html.twig", "admin/students/new.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "admin/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f955de4a85fc47b773340896cddf68baf9b12fa42fa5561548f746a5256d6cab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f955de4a85fc47b773340896cddf68baf9b12fa42fa5561548f746a5256d6cab->enter($__internal_f955de4a85fc47b773340896cddf68baf9b12fa42fa5561548f746a5256d6cab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/students/new.html.twig"));

        $__internal_e6ef9873a2ab637258d0e4acb0e4c589f62d04c239f12fd15210d2408011d001 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e6ef9873a2ab637258d0e4acb0e4c589f62d04c239f12fd15210d2408011d001->enter($__internal_e6ef9873a2ab637258d0e4acb0e4c589f62d04c239f12fd15210d2408011d001_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/students/new.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f955de4a85fc47b773340896cddf68baf9b12fa42fa5561548f746a5256d6cab->leave($__internal_f955de4a85fc47b773340896cddf68baf9b12fa42fa5561548f746a5256d6cab_prof);

        
        $__internal_e6ef9873a2ab637258d0e4acb0e4c589f62d04c239f12fd15210d2408011d001->leave($__internal_e6ef9873a2ab637258d0e4acb0e4c589f62d04c239f12fd15210d2408011d001_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_2b049edbf317e68a92eca60370714b39ae4f5c59eab8ed3f1fa3352aa2ea5a5e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2b049edbf317e68a92eca60370714b39ae4f5c59eab8ed3f1fa3352aa2ea5a5e->enter($__internal_2b049edbf317e68a92eca60370714b39ae4f5c59eab8ed3f1fa3352aa2ea5a5e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_034dfd2612dd406f0654f734af1a44ba0e5e6a91d9b38000ab24b509d86d112a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_034dfd2612dd406f0654f734af1a44ba0e5e6a91d9b38000ab24b509d86d112a->enter($__internal_034dfd2612dd406f0654f734af1a44ba0e5e6a91d9b38000ab24b509d86d112a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "admin_post_new";
        
        $__internal_034dfd2612dd406f0654f734af1a44ba0e5e6a91d9b38000ab24b509d86d112a->leave($__internal_034dfd2612dd406f0654f734af1a44ba0e5e6a91d9b38000ab24b509d86d112a_prof);

        
        $__internal_2b049edbf317e68a92eca60370714b39ae4f5c59eab8ed3f1fa3352aa2ea5a5e->leave($__internal_2b049edbf317e68a92eca60370714b39ae4f5c59eab8ed3f1fa3352aa2ea5a5e_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_c8c59c59f2b8f50338fcb1523165ab05eb91646ff6dca5a94a4722c747eda5d3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c8c59c59f2b8f50338fcb1523165ab05eb91646ff6dca5a94a4722c747eda5d3->enter($__internal_c8c59c59f2b8f50338fcb1523165ab05eb91646ff6dca5a94a4722c747eda5d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_c2aee2beee14186eaa6ba241a0867301c1f1e88437cb3a42590601951350068a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c2aee2beee14186eaa6ba241a0867301c1f1e88437cb3a42590601951350068a->enter($__internal_c2aee2beee14186eaa6ba241a0867301c1f1e88437cb3a42590601951350068a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.student_new"), "html", null, true);
        echo "</h1>

    ";
        // line 8
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
        ";
        // line 9
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "first_name", array()), 'row');
        echo "
        ";
        // line 10
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "last_name", array()), 'row');
        echo "
        ";
        // line 11
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "email", array()), 'row');
        echo "
        ";
        // line 12
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fatherName", array()), 'row');
        echo "
        ";
        // line 13
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "dob", array()), 'row');
        echo "
        ";
        // line 14
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "gender", array()), 'row');
        echo "
        ";
        // line 15
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "registered_date", array()), 'row');
        echo "
        ";
        // line 16
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "contact_no", array()), 'row');
        echo "
        ";
        // line 17
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "maktabId", array()), 'row');
        echo "
        ";
        // line 18
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "courseId", array()), 'row');
        echo "
        ";
        // line 19
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "teacherId", array()), 'row');
        echo "

        <input type=\"submit\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("label.create_student"), "html", null, true);
        echo "\" class=\"btn btn-primary\" />
        ";
        // line 22
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveAndCreateNew", array()), 'widget', array("label" => "label.save_and_create_new", "attr" => array("class" => "btn btn-primary")));
        echo "
        <a href=\"";
        // line 23
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_student_index");
        echo "\" class=\"btn btn-link\">
            ";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.back_to_list"), "html", null, true);
        echo "
        </a>
    ";
        // line 26
        echo         $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
";
        
        $__internal_c2aee2beee14186eaa6ba241a0867301c1f1e88437cb3a42590601951350068a->leave($__internal_c2aee2beee14186eaa6ba241a0867301c1f1e88437cb3a42590601951350068a_prof);

        
        $__internal_c8c59c59f2b8f50338fcb1523165ab05eb91646ff6dca5a94a4722c747eda5d3->leave($__internal_c8c59c59f2b8f50338fcb1523165ab05eb91646ff6dca5a94a4722c747eda5d3_prof);

    }

    // line 29
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_6e62b6ba2ccaea89af945e820aa625da99dfb7009d3fdf5702989e2735d4f140 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e62b6ba2ccaea89af945e820aa625da99dfb7009d3fdf5702989e2735d4f140->enter($__internal_6e62b6ba2ccaea89af945e820aa625da99dfb7009d3fdf5702989e2735d4f140_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_829f19c2151690906879b922c96d3509d114d0fe0aa4cca9c3af3f452875a340 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_829f19c2151690906879b922c96d3509d114d0fe0aa4cca9c3af3f452875a340->enter($__internal_829f19c2151690906879b922c96d3509d114d0fe0aa4cca9c3af3f452875a340_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 30
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 32
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
";
        
        $__internal_829f19c2151690906879b922c96d3509d114d0fe0aa4cca9c3af3f452875a340->leave($__internal_829f19c2151690906879b922c96d3509d114d0fe0aa4cca9c3af3f452875a340_prof);

        
        $__internal_6e62b6ba2ccaea89af945e820aa625da99dfb7009d3fdf5702989e2735d4f140->leave($__internal_6e62b6ba2ccaea89af945e820aa625da99dfb7009d3fdf5702989e2735d4f140_prof);

    }

    public function getTemplateName()
    {
        return "admin/students/new.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  168 => 32,  162 => 30,  153 => 29,  141 => 26,  136 => 24,  132 => 23,  128 => 22,  124 => 21,  119 => 19,  115 => 18,  111 => 17,  107 => 16,  103 => 15,  99 => 14,  95 => 13,  91 => 12,  87 => 11,  83 => 10,  79 => 9,  75 => 8,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'admin/layout.html.twig' %}

{% block body_id 'admin_post_new' %}

{% block main %}
    <h1>{{ 'title.student_new'|trans }}</h1>

    {{ form_start(form) }}
        {{ form_row(form.first_name) }}
        {{ form_row(form.last_name) }}
        {{ form_row(form.email) }}
        {{ form_row(form.fatherName) }}
        {{ form_row(form.dob) }}
        {{ form_row(form.gender) }}
        {{ form_row(form.registered_date) }}
        {{ form_row(form.contact_no) }}
        {{ form_row(form.maktabId) }}
        {{ form_row(form.courseId) }}
        {{ form_row(form.teacherId) }}

        <input type=\"submit\" value=\"{{ 'label.create_student'|trans }}\" class=\"btn btn-primary\" />
        {{ form_widget(form.saveAndCreateNew, { label: 'label.save_and_create_new', attr: { class: 'btn btn-primary' } }) }}
        <a href=\"{{ path('admin_student_index') }}\" class=\"btn btn-link\">
            {{ 'action.back_to_list'|trans }}
        </a>
    {{ form_end(form) }}
{% endblock %}

{% block sidebar %}
    {{ parent() }}

    {{ show_source_code(_self) }}
{% endblock %}
", "admin/students/new.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\admin\\students\\new.html.twig");
    }
}
