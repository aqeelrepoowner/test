<?php

/* @Framework/Form/choice_attributes.html.php */
class __TwigTemplate_e582e1895b5a072be637a874dab6acfe884bd07a8fa4bc65923ae87ea0cf4953 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8b6eb2830f14e2c95ec26f77f176bcb1cbffc39682962b95e06ff89ca96bc60 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b8b6eb2830f14e2c95ec26f77f176bcb1cbffc39682962b95e06ff89ca96bc60->enter($__internal_b8b6eb2830f14e2c95ec26f77f176bcb1cbffc39682962b95e06ff89ca96bc60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        $__internal_d75e5158758cc007146ec9d80c7bbe30891794c70e07b22b1c853a531245073a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d75e5158758cc007146ec9d80c7bbe30891794c70e07b22b1c853a531245073a->enter($__internal_d75e5158758cc007146ec9d80c7bbe30891794c70e07b22b1c853a531245073a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_attributes.html.php"));

        // line 1
        echo "<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
";
        
        $__internal_b8b6eb2830f14e2c95ec26f77f176bcb1cbffc39682962b95e06ff89ca96bc60->leave($__internal_b8b6eb2830f14e2c95ec26f77f176bcb1cbffc39682962b95e06ff89ca96bc60_prof);

        
        $__internal_d75e5158758cc007146ec9d80c7bbe30891794c70e07b22b1c853a531245073a->leave($__internal_d75e5158758cc007146ec9d80c7bbe30891794c70e07b22b1c853a531245073a_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php if (\$disabled): ?>disabled=\"disabled\" <?php endif ?>
<?php foreach (\$choice_attr as \$k => \$v): ?>
<?php if (\$v === true): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$k)) ?>
<?php elseif (\$v !== false): ?>
<?php printf('%s=\"%s\" ', \$view->escape(\$k), \$view->escape(\$v)) ?>
<?php endif ?>
<?php endforeach ?>
", "@Framework/Form/choice_attributes.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\choice_attributes.html.php");
    }
}
