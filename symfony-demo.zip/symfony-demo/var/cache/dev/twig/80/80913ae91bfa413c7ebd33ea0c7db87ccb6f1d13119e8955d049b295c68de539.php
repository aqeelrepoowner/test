<?php

/* blog/comment_form_error.html.twig */
class __TwigTemplate_1c62d5352dc9efd717008680bdbcaad79ab48642771dc7aaa007c7d45e704e4e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "blog/comment_form_error.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0767e5eff0bac326b9346ca58b43de79dbe744f6e89aff1ab0c591b92a712b67 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0767e5eff0bac326b9346ca58b43de79dbe744f6e89aff1ab0c591b92a712b67->enter($__internal_0767e5eff0bac326b9346ca58b43de79dbe744f6e89aff1ab0c591b92a712b67_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/comment_form_error.html.twig"));

        $__internal_338a15cb53229b768bdc794b4fed7cd5acd91fcbd1c420a0b4fddf53c3224448 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_338a15cb53229b768bdc794b4fed7cd5acd91fcbd1c420a0b4fddf53c3224448->enter($__internal_338a15cb53229b768bdc794b4fed7cd5acd91fcbd1c420a0b4fddf53c3224448_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "blog/comment_form_error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0767e5eff0bac326b9346ca58b43de79dbe744f6e89aff1ab0c591b92a712b67->leave($__internal_0767e5eff0bac326b9346ca58b43de79dbe744f6e89aff1ab0c591b92a712b67_prof);

        
        $__internal_338a15cb53229b768bdc794b4fed7cd5acd91fcbd1c420a0b4fddf53c3224448->leave($__internal_338a15cb53229b768bdc794b4fed7cd5acd91fcbd1c420a0b4fddf53c3224448_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_aa13138b9da070506141c7927f0a516b8c15ed2cfcc01db44b0539ae36de5265 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aa13138b9da070506141c7927f0a516b8c15ed2cfcc01db44b0539ae36de5265->enter($__internal_aa13138b9da070506141c7927f0a516b8c15ed2cfcc01db44b0539ae36de5265_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_6c1943196fd4bf52365c810e636bd7ed30552d6726a5a0b5a4edd6e83b4f0c22 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6c1943196fd4bf52365c810e636bd7ed30552d6726a5a0b5a4edd6e83b4f0c22->enter($__internal_6c1943196fd4bf52365c810e636bd7ed30552d6726a5a0b5a4edd6e83b4f0c22_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "comment_form_error";
        
        $__internal_6c1943196fd4bf52365c810e636bd7ed30552d6726a5a0b5a4edd6e83b4f0c22->leave($__internal_6c1943196fd4bf52365c810e636bd7ed30552d6726a5a0b5a4edd6e83b4f0c22_prof);

        
        $__internal_aa13138b9da070506141c7927f0a516b8c15ed2cfcc01db44b0539ae36de5265->leave($__internal_aa13138b9da070506141c7927f0a516b8c15ed2cfcc01db44b0539ae36de5265_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_8d45de33a29ba66d29452f8b9c1ae67a7ae757ffe61930e66bf6430a591cf0ee = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d45de33a29ba66d29452f8b9c1ae67a7ae757ffe61930e66bf6430a591cf0ee->enter($__internal_8d45de33a29ba66d29452f8b9c1ae67a7ae757ffe61930e66bf6430a591cf0ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_282428417abfa2ccb17a19a16271daee1078eccf42bbd7fd6da4ccd882ccd0d1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_282428417abfa2ccb17a19a16271daee1078eccf42bbd7fd6da4ccd882ccd0d1->enter($__internal_282428417abfa2ccb17a19a16271daee1078eccf42bbd7fd6da4ccd882ccd0d1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1 class=\"text-danger\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("title.comment_error"), "html", null, true);
        echo "</h1>

    <div class=\"well\">
        ";
        // line 9
        echo twig_include($this->env, $context, "blog/_comment_form.html.twig");
        echo "
    </div>
";
        
        $__internal_282428417abfa2ccb17a19a16271daee1078eccf42bbd7fd6da4ccd882ccd0d1->leave($__internal_282428417abfa2ccb17a19a16271daee1078eccf42bbd7fd6da4ccd882ccd0d1_prof);

        
        $__internal_8d45de33a29ba66d29452f8b9c1ae67a7ae757ffe61930e66bf6430a591cf0ee->leave($__internal_8d45de33a29ba66d29452f8b9c1ae67a7ae757ffe61930e66bf6430a591cf0ee_prof);

    }

    public function getTemplateName()
    {
        return "blog/comment_form_error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 9,  68 => 6,  59 => 5,  41 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'comment_form_error' %}

{% block main %}
    <h1 class=\"text-danger\">{{ 'title.comment_error'|trans }}</h1>

    <div class=\"well\">
        {{ include('blog/_comment_form.html.twig') }}
    </div>
{% endblock %}
", "blog/comment_form_error.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\blog\\comment_form_error.html.twig");
    }
}
