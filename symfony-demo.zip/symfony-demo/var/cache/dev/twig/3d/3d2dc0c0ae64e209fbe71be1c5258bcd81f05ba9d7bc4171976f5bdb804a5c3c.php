<?php

/* admin/blog/_delete_form.html.twig */
class __TwigTemplate_9cf86030cf90516d21f64134ce477b396a25d9d71d4cbd264c35c18ed8975907 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6aeb34dc2ee5da6cf7733055d75c3c53fd327086f16c160af70ebdf67fe0b74c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6aeb34dc2ee5da6cf7733055d75c3c53fd327086f16c160af70ebdf67fe0b74c->enter($__internal_6aeb34dc2ee5da6cf7733055d75c3c53fd327086f16c160af70ebdf67fe0b74c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/_delete_form.html.twig"));

        $__internal_f450c4fdbf6ef842291d1992395baaa31d11dabb53a81bad65fee15b1ec064ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f450c4fdbf6ef842291d1992395baaa31d11dabb53a81bad65fee15b1ec064ed->enter($__internal_f450c4fdbf6ef842291d1992395baaa31d11dabb53a81bad65fee15b1ec064ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "admin/blog/_delete_form.html.twig"));

        // line 1
        echo twig_include($this->env, $context, "blog/_delete_post_confirmation.html.twig");
        echo "
<form action=\"";
        // line 2
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getUrl("admin_post_delete", array("id" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
        echo "\" method=\"post\" data-confirmation=\"true\">
    <input type=\"hidden\" name=\"token\" value=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->renderCsrfToken("delete"), "html", null, true);
        echo "\" />
    <input type=\"submit\" value=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.delete_post"), "html", null, true);
        echo "\" class=\"btn btn-lg btn-block btn-danger\" />
</form>
";
        
        $__internal_6aeb34dc2ee5da6cf7733055d75c3c53fd327086f16c160af70ebdf67fe0b74c->leave($__internal_6aeb34dc2ee5da6cf7733055d75c3c53fd327086f16c160af70ebdf67fe0b74c_prof);

        
        $__internal_f450c4fdbf6ef842291d1992395baaa31d11dabb53a81bad65fee15b1ec064ed->leave($__internal_f450c4fdbf6ef842291d1992395baaa31d11dabb53a81bad65fee15b1ec064ed_prof);

    }

    public function getTemplateName()
    {
        return "admin/blog/_delete_form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 4,  33 => 3,  29 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ include('blog/_delete_post_confirmation.html.twig') }}
<form action=\"{{ url('admin_post_delete', { id: post.id }) }}\" method=\"post\" data-confirmation=\"true\">
    <input type=\"hidden\" name=\"token\" value=\"{{ csrf_token('delete') }}\" />
    <input type=\"submit\" value=\"{{ 'action.delete_post'|trans }}\" class=\"btn btn-lg btn-block btn-danger\" />
</form>
", "admin/blog/_delete_form.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\admin\\blog\\_delete_form.html.twig");
    }
}
