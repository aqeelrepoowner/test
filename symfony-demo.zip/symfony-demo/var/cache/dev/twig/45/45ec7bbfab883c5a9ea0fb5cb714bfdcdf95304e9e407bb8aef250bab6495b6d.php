<?php

/* :blog:post_show.html.twig */
class __TwigTemplate_23e4716703d4e8093a8a511e2c2ebbae2f846a33b4395990ca41ed74243669d5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", ":blog:post_show.html.twig", 1);
        $this->blocks = array(
            'body_id' => array($this, 'block_body_id'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_821f17298899aa005b5783fd74865373a7f8acce80affe23e72250ffb728e269 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_821f17298899aa005b5783fd74865373a7f8acce80affe23e72250ffb728e269->enter($__internal_821f17298899aa005b5783fd74865373a7f8acce80affe23e72250ffb728e269_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:post_show.html.twig"));

        $__internal_f48087a22b05ab317be512266a73bc5d904d9efefc442c7e00e162fd0f1c388c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f48087a22b05ab317be512266a73bc5d904d9efefc442c7e00e162fd0f1c388c->enter($__internal_f48087a22b05ab317be512266a73bc5d904d9efefc442c7e00e162fd0f1c388c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:post_show.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_821f17298899aa005b5783fd74865373a7f8acce80affe23e72250ffb728e269->leave($__internal_821f17298899aa005b5783fd74865373a7f8acce80affe23e72250ffb728e269_prof);

        
        $__internal_f48087a22b05ab317be512266a73bc5d904d9efefc442c7e00e162fd0f1c388c->leave($__internal_f48087a22b05ab317be512266a73bc5d904d9efefc442c7e00e162fd0f1c388c_prof);

    }

    // line 3
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_fa03593775cb3c15176581de123b52155f75e16e21ee971e4a25118676d622ad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa03593775cb3c15176581de123b52155f75e16e21ee971e4a25118676d622ad->enter($__internal_fa03593775cb3c15176581de123b52155f75e16e21ee971e4a25118676d622ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_ecbeef6a904164029b11e27c606443e3813e589c381d8c62aef59bb2629c336c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ecbeef6a904164029b11e27c606443e3813e589c381d8c62aef59bb2629c336c->enter($__internal_ecbeef6a904164029b11e27c606443e3813e589c381d8c62aef59bb2629c336c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        echo "blog_post_show";
        
        $__internal_ecbeef6a904164029b11e27c606443e3813e589c381d8c62aef59bb2629c336c->leave($__internal_ecbeef6a904164029b11e27c606443e3813e589c381d8c62aef59bb2629c336c_prof);

        
        $__internal_fa03593775cb3c15176581de123b52155f75e16e21ee971e4a25118676d622ad->leave($__internal_fa03593775cb3c15176581de123b52155f75e16e21ee971e4a25118676d622ad_prof);

    }

    // line 5
    public function block_main($context, array $blocks = array())
    {
        $__internal_5221e32bff3b7306adf0f1ff3dbfa16ff156766b079f25cf544614c4beaadf08 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5221e32bff3b7306adf0f1ff3dbfa16ff156766b079f25cf544614c4beaadf08->enter($__internal_5221e32bff3b7306adf0f1ff3dbfa16ff156766b079f25cf544614c4beaadf08_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_26b1e0af10ba3ae4ad0cc71baabdebb5e9e398a02562ace9791d8af67dd77aba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_26b1e0af10ba3ae4ad0cc71baabdebb5e9e398a02562ace9791d8af67dd77aba->enter($__internal_26b1e0af10ba3ae4ad0cc71baabdebb5e9e398a02562ace9791d8af67dd77aba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 6
        echo "    <h1>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo "</h1>

    <p class=\"post-metadata\">
        <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> ";
        // line 9
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "publishedAt", array()), "long", "medium", null, "UTC"), "html", null, true);
        echo "</span>
        <span class=\"metadata\"><i class=\"fa fa-user\"></i> ";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "author", array()), "email", array()), "html", null, true);
        echo "</span>
    </p>

    ";
        // line 13
        echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "content", array()));
        echo "

    <div id=\"post-add-comment\" class=\"well\">
        ";
        // line 22
        echo "        ";
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("IS_AUTHENTICATED_FULLY")) {
            // line 23
            echo "            ";
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("AppBundle:Blog:commentForm", array("id" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))));
            echo "
        ";
        } else {
            // line 25
            echo "            <p>
                <a class=\"btn btn-success\" href=\"";
            // line 26
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_login");
            echo "\">
                    <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> ";
            // line 27
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.sign_in"), "html", null, true);
            echo "
                </a>
                ";
            // line 29
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.to_publish_a_comment"), "html", null, true);
            echo "
            </p>
        ";
        }
        // line 32
        echo "    </div>

    <h3>";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->transchoice("post.num_comments", twig_length_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "comments", array()))), "html", null, true);
        echo "</h3>

    ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "comments", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
            // line 37
            echo "        <div class=\"row post-comment\">
            <a name=\"comment_";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["comment"], "id", array()), "html", null, true);
            echo "\"></a>
            <h4 class=\"col-sm-3\">
                <strong>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["comment"], "author", array()), "email", array()), "html", null, true);
            echo "</strong> ";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.commented_on"), "html", null, true);
            echo "
                ";
            // line 44
            echo "                <strong>";
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["comment"], "publishedAt", array()), "medium", "short", null, "UTC"), "html", null, true);
            echo "</strong>
            </h4>
            <div class=\"col-sm-9\">
                ";
            // line 47
            echo $this->env->getExtension('AppBundle\Twig\AppExtension')->markdownToHtml($this->getAttribute($context["comment"], "content", array()));
            echo "
            </div>
        </div>
    ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 51
            echo "        <div class=\"post-comment\">
            <p>";
            // line 52
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("post.no_comments"), "html", null, true);
            echo "</p>
        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_26b1e0af10ba3ae4ad0cc71baabdebb5e9e398a02562ace9791d8af67dd77aba->leave($__internal_26b1e0af10ba3ae4ad0cc71baabdebb5e9e398a02562ace9791d8af67dd77aba_prof);

        
        $__internal_5221e32bff3b7306adf0f1ff3dbfa16ff156766b079f25cf544614c4beaadf08->leave($__internal_5221e32bff3b7306adf0f1ff3dbfa16ff156766b079f25cf544614c4beaadf08_prof);

    }

    // line 57
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_404d4af119caa2966c354820fe9a95ef91b0579a3d1bd27235c2a5ac9b4aebd0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_404d4af119caa2966c354820fe9a95ef91b0579a3d1bd27235c2a5ac9b4aebd0->enter($__internal_404d4af119caa2966c354820fe9a95ef91b0579a3d1bd27235c2a5ac9b4aebd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_d9e669ef8a308523e3a780c3f365674e9632f5568e7f78864389ca43b51cfe43 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d9e669ef8a308523e3a780c3f365674e9632f5568e7f78864389ca43b51cfe43->enter($__internal_d9e669ef8a308523e3a780c3f365674e9632f5568e7f78864389ca43b51cfe43_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 58
        echo "    ";
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("edit", (isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")))) {
            // line 59
            echo "        <div class=\"section\">
            <a class=\"btn btn-lg btn-block btn-success\" href=\"";
            // line 60
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_edit", array("id" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "id", array()))), "html", null, true);
            echo "\">
                <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> ";
            // line 61
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("action.edit_post"), "html", null, true);
            echo "
            </a>
        </div>
    ";
        }
        // line 65
        echo "
    ";
        // line 69
        echo "    ";
        $this->displayParentBlock("sidebar", $context, $blocks);
        echo "

    ";
        // line 71
        echo $this->env->getExtension('CodeExplorerBundle\Twig\SourceCodeExtension')->showSourceCode($this->env, $this);
        echo "
    ";
        // line 72
        echo twig_include($this->env, $context, "blog/_rss.html.twig");
        echo "
";
        
        $__internal_d9e669ef8a308523e3a780c3f365674e9632f5568e7f78864389ca43b51cfe43->leave($__internal_d9e669ef8a308523e3a780c3f365674e9632f5568e7f78864389ca43b51cfe43_prof);

        
        $__internal_404d4af119caa2966c354820fe9a95ef91b0579a3d1bd27235c2a5ac9b4aebd0->leave($__internal_404d4af119caa2966c354820fe9a95ef91b0579a3d1bd27235c2a5ac9b4aebd0_prof);

    }

    public function getTemplateName()
    {
        return ":blog:post_show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  222 => 72,  218 => 71,  212 => 69,  209 => 65,  202 => 61,  198 => 60,  195 => 59,  192 => 58,  183 => 57,  166 => 52,  163 => 51,  154 => 47,  147 => 44,  141 => 40,  136 => 38,  133 => 37,  128 => 36,  123 => 34,  119 => 32,  113 => 29,  108 => 27,  104 => 26,  101 => 25,  95 => 23,  92 => 22,  86 => 13,  80 => 10,  76 => 9,  69 => 6,  60 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body_id 'blog_post_show' %}

{% block main %}
    <h1>{{ post.title }}</h1>

    <p class=\"post-metadata\">
        <span class=\"metadata\"><i class=\"fa fa-calendar\"></i> {{ post.publishedAt|localizeddate('long', 'medium', null, 'UTC') }}</span>
        <span class=\"metadata\"><i class=\"fa fa-user\"></i> {{ post.author.email }}</span>
    </p>

    {{ post.content|md2html }}

    <div id=\"post-add-comment\" class=\"well\">
        {# The 'IS_AUTHENTICATED_FULLY' role ensures that the user has entered
        his/her credentials (login + password) during this session. If he/she
        is automatically logged via the 'Remember Me' functionality, he/she won't
        be able to add a comment.
        See http://symfony.com/doc/current/cookbook/security/remember_me.html#forcing-the-user-to-re-authenticate-before-accessing-certain-resources
        #}
        {% if is_granted('IS_AUTHENTICATED_FULLY') %}
            {{ render(controller('AppBundle:Blog:commentForm', { 'id': post.id })) }}
        {% else %}
            <p>
                <a class=\"btn btn-success\" href=\"{{ path('security_login') }}\">
                    <i class=\"fa fa-sign-in\" aria-hidden=\"true\"></i> {{ 'action.sign_in'|trans }}
                </a>
                {{ 'post.to_publish_a_comment'|trans }}
            </p>
        {% endif %}
    </div>

    <h3>{{ 'post.num_comments'|transchoice(post.comments|length) }}</h3>

    {% for comment in post.comments %}
        <div class=\"row post-comment\">
            <a name=\"comment_{{ comment.id }}\"></a>
            <h4 class=\"col-sm-3\">
                <strong>{{ comment.author.email }}</strong> {{ 'post.commented_on'|trans }}
                {# it's not mandatory to set the timezone in localizeddate(). This is done to
                   avoid errors when the 'intl' PHP extension is not available and the application
                   is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
                <strong>{{ comment.publishedAt|localizeddate('medium', 'short', null, 'UTC') }}</strong>
            </h4>
            <div class=\"col-sm-9\">
                {{ comment.content|md2html }}
            </div>
        </div>
    {% else %}
        <div class=\"post-comment\">
            <p>{{ 'post.no_comments'|trans }}</p>
        </div>
    {% endfor %}
{% endblock %}

{% block sidebar %}
    {% if is_granted('edit', post) %}
        <div class=\"section\">
            <a class=\"btn btn-lg btn-block btn-success\" href=\"{{ path('admin_post_edit', { id: post.id }) }}\">
                <i class=\"fa fa-edit\" aria-hidden=\"true\"></i> {{ 'action.edit_post'|trans }}
            </a>
        </div>
    {% endif %}

    {# the parent() function includes the contents defined by the parent template
      ('base.html.twig') for this block ('sidebar'). This is a very convenient way
      to share common contents in different templates #}
    {{ parent() }}

    {{ show_source_code(_self) }}
    {{ include('blog/_rss.html.twig') }}
{% endblock %}
", ":blog:post_show.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/blog/post_show.html.twig");
    }
}
