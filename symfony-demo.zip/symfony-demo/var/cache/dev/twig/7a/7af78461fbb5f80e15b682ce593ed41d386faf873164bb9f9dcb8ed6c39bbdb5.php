<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_731052810b9b56d03a8024a5fb5efb4dff4f6d8cd98eb16a4da1c6bdcd86a4f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bba50adab41262a31376eda01c3c678a6a6ebcb8f1f2c1a508720175e9bdb4c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bba50adab41262a31376eda01c3c678a6a6ebcb8f1f2c1a508720175e9bdb4c9->enter($__internal_bba50adab41262a31376eda01c3c678a6a6ebcb8f1f2c1a508720175e9bdb4c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        $__internal_b3f32d1b4b15b66f58fe869ca77ebd550d385448e8027538bfecd0e280b1e887 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b3f32d1b4b15b66f58fe869ca77ebd550d385448e8027538bfecd0e280b1e887->enter($__internal_b3f32d1b4b15b66f58fe869ca77ebd550d385448e8027538bfecd0e280b1e887_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_bba50adab41262a31376eda01c3c678a6a6ebcb8f1f2c1a508720175e9bdb4c9->leave($__internal_bba50adab41262a31376eda01c3c678a6a6ebcb8f1f2c1a508720175e9bdb4c9_prof);

        
        $__internal_b3f32d1b4b15b66f58fe869ca77ebd550d385448e8027538bfecd0e280b1e887->leave($__internal_b3f32d1b4b15b66f58fe869ca77ebd550d385448e8027538bfecd0e280b1e887_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}
", "TwigBundle:Exception:exception.rdf.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/exception.rdf.twig");
    }
}
