<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_60cf64796c09e9324911092104d5fb91dee1067b157f2ec489c0462d7869eb2f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4394d593e4b835872505118e039987198d3ab5931774bf04eb327b8c17c71538 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4394d593e4b835872505118e039987198d3ab5931774bf04eb327b8c17c71538->enter($__internal_4394d593e4b835872505118e039987198d3ab5931774bf04eb327b8c17c71538_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        $__internal_f4af095580c75e84404f516d1464cbbd41609d27432d00e3c1c51e993f919c49 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f4af095580c75e84404f516d1464cbbd41609d27432d00e3c1c51e993f919c49->enter($__internal_f4af095580c75e84404f516d1464cbbd41609d27432d00e3c1c51e993f919c49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_4394d593e4b835872505118e039987198d3ab5931774bf04eb327b8c17c71538->leave($__internal_4394d593e4b835872505118e039987198d3ab5931774bf04eb327b8c17c71538_prof);

        
        $__internal_f4af095580c75e84404f516d1464cbbd41609d27432d00e3c1c51e993f919c49->leave($__internal_f4af095580c75e84404f516d1464cbbd41609d27432d00e3c1c51e993f919c49_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
", "@Framework/FormTable/form_widget_compound.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\form_widget_compound.html.php");
    }
}
