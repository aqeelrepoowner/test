<?php

/* @Twig/Exception/exception.json.twig */
class __TwigTemplate_ddf2ad6c69d5ce0ccc8ed1e11bb6f2bdcbc8ee15d74f4183f1ef18e05425a40f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9d9dda68203894e841184851e2ceeb005cef4735fe050aebea2db88861f25c9c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9d9dda68203894e841184851e2ceeb005cef4735fe050aebea2db88861f25c9c->enter($__internal_9d9dda68203894e841184851e2ceeb005cef4735fe050aebea2db88861f25c9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        $__internal_95b450f5f324b6458430a307e51d11421ce64b6c27201eafe2c5eb642f5b64a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_95b450f5f324b6458430a307e51d11421ce64b6c27201eafe2c5eb642f5b64a8->enter($__internal_95b450f5f324b6458430a307e51d11421ce64b6c27201eafe2c5eb642f5b64a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "exception" => $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "toarray", array()))));
        echo "
";
        
        $__internal_9d9dda68203894e841184851e2ceeb005cef4735fe050aebea2db88861f25c9c->leave($__internal_9d9dda68203894e841184851e2ceeb005cef4735fe050aebea2db88861f25c9c_prof);

        
        $__internal_95b450f5f324b6458430a307e51d11421ce64b6c27201eafe2c5eb642f5b64a8->leave($__internal_95b450f5f324b6458430a307e51d11421ce64b6c27201eafe2c5eb642f5b64a8_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text, 'exception': exception.toarray } }|json_encode|raw }}
", "@Twig/Exception/exception.json.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\exception.json.twig");
    }
}
