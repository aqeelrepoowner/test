<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_20a10cf41de9405f54b5d3006376101d6fb34982a9eeaf96ff910046b37bd94c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f6f8420d801329ab01b890dbd5c45dc26f08a2022790431267986ad054c6e208 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f6f8420d801329ab01b890dbd5c45dc26f08a2022790431267986ad054c6e208->enter($__internal_f6f8420d801329ab01b890dbd5c45dc26f08a2022790431267986ad054c6e208_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        $__internal_f09504a21127a4ad593d1412d62ee6c3966ed9e10f944a413a45c6579f4c7d0e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f09504a21127a4ad593d1412d62ee6c3966ed9e10f944a413a45c6579f4c7d0e->enter($__internal_f09504a21127a4ad593d1412d62ee6c3966ed9e10f944a413a45c6579f4c7d0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_f6f8420d801329ab01b890dbd5c45dc26f08a2022790431267986ad054c6e208->leave($__internal_f6f8420d801329ab01b890dbd5c45dc26f08a2022790431267986ad054c6e208_prof);

        
        $__internal_f09504a21127a4ad593d1412d62ee6c3966ed9e10f944a413a45c6579f4c7d0e->leave($__internal_f09504a21127a4ad593d1412d62ee6c3966ed9e10f944a413a45c6579f4c7d0e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{{ status_code }} {{ status_text }}

*/
", "TwigBundle:Exception:error.js.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle/Resources/views/Exception/error.js.twig");
    }
}
