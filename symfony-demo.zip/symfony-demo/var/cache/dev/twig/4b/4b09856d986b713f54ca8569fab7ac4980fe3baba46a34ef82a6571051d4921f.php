<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_10699f67b2bb840c56466dc0e46625e48fb347e2e6a731c1efd8cec31cd1fe5d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc57afe3336739cb3403f9819dadd1f9eb72c767a4d1db557321aaa1c4a942f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cc57afe3336739cb3403f9819dadd1f9eb72c767a4d1db557321aaa1c4a942f6->enter($__internal_cc57afe3336739cb3403f9819dadd1f9eb72c767a4d1db557321aaa1c4a942f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        $__internal_1e47d7651af20f35a81f3485f09069711176c5daf4e9734fc8cc3d534e82b35f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e47d7651af20f35a81f3485f09069711176c5daf4e9734fc8cc3d534e82b35f->enter($__internal_1e47d7651af20f35a81f3485f09069711176c5daf4e9734fc8cc3d534e82b35f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_cc57afe3336739cb3403f9819dadd1f9eb72c767a4d1db557321aaa1c4a942f6->leave($__internal_cc57afe3336739cb3403f9819dadd1f9eb72c767a4d1db557321aaa1c4a942f6_prof);

        
        $__internal_1e47d7651af20f35a81f3485f09069711176c5daf4e9734fc8cc3d534e82b35f->leave($__internal_1e47d7651af20f35a81f3485f09069711176c5daf4e9734fc8cc3d534e82b35f_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
", "@Framework/Form/form_rest.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\Form\\form_rest.html.php");
    }
}
