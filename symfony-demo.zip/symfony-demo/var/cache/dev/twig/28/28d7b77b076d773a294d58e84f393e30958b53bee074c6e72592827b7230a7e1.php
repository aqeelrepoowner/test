<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_8ee53ad126ad82215f5c2ac1025d5c3a015a3163ebceb736d28fdafa8b31a171 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8d33e5123a5219edb8312cba7eb7bd001b326eb1394abe8fba03e2335ae1c71f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8d33e5123a5219edb8312cba7eb7bd001b326eb1394abe8fba03e2335ae1c71f->enter($__internal_8d33e5123a5219edb8312cba7eb7bd001b326eb1394abe8fba03e2335ae1c71f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        $__internal_c11e08125114c3cfa27423fdb97cedcbb9fc89f1c383ddfc051d5cbb5b3eae3c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c11e08125114c3cfa27423fdb97cedcbb9fc89f1c383ddfc051d5cbb5b3eae3c->enter($__internal_c11e08125114c3cfa27423fdb97cedcbb9fc89f1c383ddfc051d5cbb5b3eae3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_8d33e5123a5219edb8312cba7eb7bd001b326eb1394abe8fba03e2335ae1c71f->leave($__internal_8d33e5123a5219edb8312cba7eb7bd001b326eb1394abe8fba03e2335ae1c71f_prof);

        
        $__internal_c11e08125114c3cfa27423fdb97cedcbb9fc89f1c383ddfc051d5cbb5b3eae3c->leave($__internal_c11e08125114c3cfa27423fdb97cedcbb9fc89f1c383ddfc051d5cbb5b3eae3c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
", "@Framework/FormTable/hidden_row.html.php", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\FrameworkBundle\\Resources\\views\\FormTable\\hidden_row.html.php");
    }
}
