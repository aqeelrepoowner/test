<?php

/* ::base.html.twig */
class __TwigTemplate_56c0efbdbf3c70abb905f082d8ac76c68bf364dcaa9a69338eee08c13f65212b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'header_navigation_links' => array($this, 'block_header_navigation_links'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'sidebar' => array($this, 'block_sidebar'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99725f79661c84f4c9caa681abec2285f25800a431c65cb454fe622f007458bd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99725f79661c84f4c9caa681abec2285f25800a431c65cb454fe622f007458bd->enter($__internal_99725f79661c84f4c9caa681abec2285f25800a431c65cb454fe622f007458bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_293831a12650eb6ea2101cf00db4c214bd977121710b0fb67b7b59d4a26690b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_293831a12650eb6ea2101cf00db4c214bd977121710b0fb67b7b59d4a26690b3->enter($__internal_293831a12650eb6ea2101cf00db4c214bd977121710b0fb67b7b59d4a26690b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()), "html", null, true);
        echo "\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("rss.title"), "html", null, true);
        echo "\" href=\"";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        ";
        // line 13
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 21
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>

    <body id=\"";
        // line 24
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

        ";
        // line 26
        $this->displayBlock('header', $context, $blocks);
        // line 89
        echo "
        <div class=\"container body-container\">
            ";
        // line 91
        $this->displayBlock('body', $context, $blocks);
        // line 110
        echo "        </div>

        ";
        // line 112
        $this->displayBlock('footer', $context, $blocks);
        // line 137
        echo "
        ";
        // line 138
        $this->displayBlock('javascripts', $context, $blocks);
        // line 146
        echo "
        ";
        // line 150
        echo "        <!-- Page rendered on ";
        echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, "now", "long", "long", null, "UTC"), "html", null, true);
        echo " -->
    </body>
</html>
";
        
        $__internal_99725f79661c84f4c9caa681abec2285f25800a431c65cb454fe622f007458bd->leave($__internal_99725f79661c84f4c9caa681abec2285f25800a431c65cb454fe622f007458bd_prof);

        
        $__internal_293831a12650eb6ea2101cf00db4c214bd977121710b0fb67b7b59d4a26690b3->leave($__internal_293831a12650eb6ea2101cf00db4c214bd977121710b0fb67b7b59d4a26690b3_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_6e83e318e852a481e4f453821dae6c89617b2fc8ed4e6be7af2b99696375432a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e83e318e852a481e4f453821dae6c89617b2fc8ed4e6be7af2b99696375432a->enter($__internal_6e83e318e852a481e4f453821dae6c89617b2fc8ed4e6be7af2b99696375432a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_343d75f16d98c73aa1440520ac0d7498a629286f321815023027e26bfe84c141 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_343d75f16d98c73aa1440520ac0d7498a629286f321815023027e26bfe84c141->enter($__internal_343d75f16d98c73aa1440520ac0d7498a629286f321815023027e26bfe84c141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symfony Demo application";
        
        $__internal_343d75f16d98c73aa1440520ac0d7498a629286f321815023027e26bfe84c141->leave($__internal_343d75f16d98c73aa1440520ac0d7498a629286f321815023027e26bfe84c141_prof);

        
        $__internal_6e83e318e852a481e4f453821dae6c89617b2fc8ed4e6be7af2b99696375432a->leave($__internal_6e83e318e852a481e4f453821dae6c89617b2fc8ed4e6be7af2b99696375432a_prof);

    }

    // line 13
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f85c6537b21aa00f84d8dab3db3c002347abc3b6c55204a00305a59c77456ac7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f85c6537b21aa00f84d8dab3db3c002347abc3b6c55204a00305a59c77456ac7->enter($__internal_f85c6537b21aa00f84d8dab3db3c002347abc3b6c55204a00305a59c77456ac7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_d1ed558a501dc1e4a3eb73e75d1b386cad8992c62e2036504eed9412133318a0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1ed558a501dc1e4a3eb73e75d1b386cad8992c62e2036504eed9412133318a0->enter($__internal_d1ed558a501dc1e4a3eb73e75d1b386cad8992c62e2036504eed9412133318a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 14
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-flatly-3.3.7.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-awesome-4.6.3.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 16
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/font-lato.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/highlight-solarized-light.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/main.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_d1ed558a501dc1e4a3eb73e75d1b386cad8992c62e2036504eed9412133318a0->leave($__internal_d1ed558a501dc1e4a3eb73e75d1b386cad8992c62e2036504eed9412133318a0_prof);

        
        $__internal_f85c6537b21aa00f84d8dab3db3c002347abc3b6c55204a00305a59c77456ac7->leave($__internal_f85c6537b21aa00f84d8dab3db3c002347abc3b6c55204a00305a59c77456ac7_prof);

    }

    // line 24
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_6e82b4ff228142bf8ab029bcf06fb0e77458ebf6616e86805ae81968eb467233 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6e82b4ff228142bf8ab029bcf06fb0e77458ebf6616e86805ae81968eb467233->enter($__internal_6e82b4ff228142bf8ab029bcf06fb0e77458ebf6616e86805ae81968eb467233_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_6f03ddec160dfade5cc22da4f8404395568f5258b5f3d0922ce70a7662f02ec6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f03ddec160dfade5cc22da4f8404395568f5258b5f3d0922ce70a7662f02ec6->enter($__internal_6f03ddec160dfade5cc22da4f8404395568f5258b5f3d0922ce70a7662f02ec6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_6f03ddec160dfade5cc22da4f8404395568f5258b5f3d0922ce70a7662f02ec6->leave($__internal_6f03ddec160dfade5cc22da4f8404395568f5258b5f3d0922ce70a7662f02ec6_prof);

        
        $__internal_6e82b4ff228142bf8ab029bcf06fb0e77458ebf6616e86805ae81968eb467233->leave($__internal_6e82b4ff228142bf8ab029bcf06fb0e77458ebf6616e86805ae81968eb467233_prof);

    }

    // line 26
    public function block_header($context, array $blocks = array())
    {
        $__internal_9a2be1c0c239f9d251b51ba3092475569aeae8940c651e39df3ff2c36950c50f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9a2be1c0c239f9d251b51ba3092475569aeae8940c651e39df3ff2c36950c50f->enter($__internal_9a2be1c0c239f9d251b51ba3092475569aeae8940c651e39df3ff2c36950c50f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_54d1c6bf8fbe607e70088eb15899a3e9f7fe4ce7561fe56ff92dca6babbebc39 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_54d1c6bf8fbe607e70088eb15899a3e9f7fe4ce7561fe56ff92dca6babbebc39->enter($__internal_54d1c6bf8fbe607e70088eb15899a3e9f7fe4ce7561fe56ff92dca6babbebc39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 27
        echo "            <header>
                <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
                    <div class=\"container\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"";
        // line 31
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("homepage");
        echo "\">
                                Symfony Demo
                            </a>

                            <button type=\"button\" class=\"navbar-toggle\"
                                    data-toggle=\"collapse\"
                                    data-target=\".navbar-collapse\">
                                <span class=\"sr-only\">";
        // line 38
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.toggle_nav"), "html", null, true);
        echo "</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav navbar-right\">

                                ";
        // line 47
        $this->displayBlock('header_navigation_links', $context, $blocks);
        // line 62
        echo "
                                ";
        // line 63
        if ($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array())) {
            // line 64
            echo "                                    <li>
                                        <a href=\"";
            // line 65
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("security_logout");
            echo "\">
                                            <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> ";
            // line 66
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.logout"), "html", null, true);
            echo "
                                        </a>
                                    </li>
                                ";
        }
        // line 70
        echo "
                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" id=\"locales\">
                                        <i class=\"fa fa-globe\" aria-hidden=\"true\"></i>
                                        <span class=\"caret\"></span>
                                        <span class=\"sr-only\">";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.choose_language"), "html", null, true);
        echo "</span>
                                    </a>
                                    <ul class=\"dropdown-menu locales\" role=\"menu\" aria-labelledby=\"locales\">
                                        ";
        // line 78
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->env->getExtension('AppBundle\Twig\AppExtension')->getLocales());
        foreach ($context['_seq'] as $context["_key"] => $context["locale"]) {
            // line 79
            echo "                                            <li ";
            if (($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()) == $this->getAttribute($context["locale"], "code", array()))) {
                echo "aria-checked=\"true\" class=\"active\"";
            } else {
                echo "aria-checked=\"false\"";
            }
            echo " role=\"menuitem\"><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route", 1 => "blog_index"), "method"), twig_array_merge($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "get", array(0 => "_route_params", 1 => array()), "method"), array("_locale" => $this->getAttribute($context["locale"], "code", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_capitalize_string_filter($this->env, $this->getAttribute($context["locale"], "name", array())), "html", null, true);
            echo "</a></li>
                                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['locale'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 81
        echo "                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        ";
        
        $__internal_54d1c6bf8fbe607e70088eb15899a3e9f7fe4ce7561fe56ff92dca6babbebc39->leave($__internal_54d1c6bf8fbe607e70088eb15899a3e9f7fe4ce7561fe56ff92dca6babbebc39_prof);

        
        $__internal_9a2be1c0c239f9d251b51ba3092475569aeae8940c651e39df3ff2c36950c50f->leave($__internal_9a2be1c0c239f9d251b51ba3092475569aeae8940c651e39df3ff2c36950c50f_prof);

    }

    // line 47
    public function block_header_navigation_links($context, array $blocks = array())
    {
        $__internal_8f161db76a56c22522c8f78794199a4e144cdfdb0ad86699f28e98fbb4b88f28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8f161db76a56c22522c8f78794199a4e144cdfdb0ad86699f28e98fbb4b88f28->enter($__internal_8f161db76a56c22522c8f78794199a4e144cdfdb0ad86699f28e98fbb4b88f28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        $__internal_43abf42ec04126b5262b704385179603ce9c3f8f24a25a6e5ba1c41878aca0fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_43abf42ec04126b5262b704385179603ce9c3f8f24a25a6e5ba1c41878aca0fc->enter($__internal_43abf42ec04126b5262b704385179603ce9c3f8f24a25a6e5ba1c41878aca0fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_navigation_links"));

        // line 48
        echo "                                    <li>
                                        <a href=\"";
        // line 49
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_index");
        echo "\">
                                            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> ";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.homepage"), "html", null, true);
        echo "
                                        </a>
                                    </li>

                                    ";
        // line 54
        if ($this->env->getExtension('Symfony\Bridge\Twig\Extension\SecurityExtension')->isGranted("ROLE_ADMIN")) {
            // line 55
            echo "                                        <li>
                                            <a href=\"";
            // line 56
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("admin_post_index");
            echo "\">
                                                <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> ";
            // line 57
            echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.admin"), "html", null, true);
            echo "
                                            </a>
                                        </li>
                                    ";
        }
        // line 61
        echo "                                ";
        
        $__internal_43abf42ec04126b5262b704385179603ce9c3f8f24a25a6e5ba1c41878aca0fc->leave($__internal_43abf42ec04126b5262b704385179603ce9c3f8f24a25a6e5ba1c41878aca0fc_prof);

        
        $__internal_8f161db76a56c22522c8f78794199a4e144cdfdb0ad86699f28e98fbb4b88f28->leave($__internal_8f161db76a56c22522c8f78794199a4e144cdfdb0ad86699f28e98fbb4b88f28_prof);

    }

    // line 91
    public function block_body($context, array $blocks = array())
    {
        $__internal_a22449486651e3f70a6318e0641f7f916b3c14adf9be908be61ad16945dd3e35 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a22449486651e3f70a6318e0641f7f916b3c14adf9be908be61ad16945dd3e35->enter($__internal_a22449486651e3f70a6318e0641f7f916b3c14adf9be908be61ad16945dd3e35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_7b32f76624f4b750934b4b28338f298b35945bcf886a8701ae6deb73f28c5506 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b32f76624f4b750934b4b28338f298b35945bcf886a8701ae6deb73f28c5506->enter($__internal_7b32f76624f4b750934b4b28338f298b35945bcf886a8701ae6deb73f28c5506_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 92
        echo "                <div class=\"row\">
                    <div id=\"main\" class=\"col-sm-9\">
                        ";
        // line 94
        echo twig_include($this->env, $context, "default/_flash_messages.html.twig");
        echo "

                        ";
        // line 96
        $this->displayBlock('main', $context, $blocks);
        // line 97
        echo "                    </div>

                    <div id=\"sidebar\" class=\"col-sm-3\">
                        ";
        // line 100
        $this->displayBlock('sidebar', $context, $blocks);
        // line 107
        echo "                    </div>
                </div>
            ";
        
        $__internal_7b32f76624f4b750934b4b28338f298b35945bcf886a8701ae6deb73f28c5506->leave($__internal_7b32f76624f4b750934b4b28338f298b35945bcf886a8701ae6deb73f28c5506_prof);

        
        $__internal_a22449486651e3f70a6318e0641f7f916b3c14adf9be908be61ad16945dd3e35->leave($__internal_a22449486651e3f70a6318e0641f7f916b3c14adf9be908be61ad16945dd3e35_prof);

    }

    // line 96
    public function block_main($context, array $blocks = array())
    {
        $__internal_cbf31fff7fc60f0e0508273dee148b67b51a1b9acbb0cf1187cd034a115e79fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cbf31fff7fc60f0e0508273dee148b67b51a1b9acbb0cf1187cd034a115e79fe->enter($__internal_cbf31fff7fc60f0e0508273dee148b67b51a1b9acbb0cf1187cd034a115e79fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_566c14b07e57eedb0bbadc79e5331c7fd2c9d43ce9d55d061c23ac061f7043b6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_566c14b07e57eedb0bbadc79e5331c7fd2c9d43ce9d55d061c23ac061f7043b6->enter($__internal_566c14b07e57eedb0bbadc79e5331c7fd2c9d43ce9d55d061c23ac061f7043b6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_566c14b07e57eedb0bbadc79e5331c7fd2c9d43ce9d55d061c23ac061f7043b6->leave($__internal_566c14b07e57eedb0bbadc79e5331c7fd2c9d43ce9d55d061c23ac061f7043b6_prof);

        
        $__internal_cbf31fff7fc60f0e0508273dee148b67b51a1b9acbb0cf1187cd034a115e79fe->leave($__internal_cbf31fff7fc60f0e0508273dee148b67b51a1b9acbb0cf1187cd034a115e79fe_prof);

    }

    // line 100
    public function block_sidebar($context, array $blocks = array())
    {
        $__internal_d9142f65ef0088c742b2453bb4742a0bbeef4e05423a1329082f0acdd2d24505 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d9142f65ef0088c742b2453bb4742a0bbeef4e05423a1329082f0acdd2d24505->enter($__internal_d9142f65ef0088c742b2453bb4742a0bbeef4e05423a1329082f0acdd2d24505_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        $__internal_40f2b691c67945385d7e0883a293bfe3dc592e0424220f68791688e4f3c017c9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_40f2b691c67945385d7e0883a293bfe3dc592e0424220f68791688e4f3c017c9->enter($__internal_40f2b691c67945385d7e0883a293bfe3dc592e0424220f68791688e4f3c017c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "sidebar"));

        // line 101
        echo "                            ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragmentStrategy("esi", Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("FrameworkBundle:Template:template", array("template" => "blog/about.html.twig", "sharedAge" => 600, "_locale" => $this->getAttribute($this->getAttribute(        // line 104
(isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()))));
        // line 105
        echo "
                        ";
        
        $__internal_40f2b691c67945385d7e0883a293bfe3dc592e0424220f68791688e4f3c017c9->leave($__internal_40f2b691c67945385d7e0883a293bfe3dc592e0424220f68791688e4f3c017c9_prof);

        
        $__internal_d9142f65ef0088c742b2453bb4742a0bbeef4e05423a1329082f0acdd2d24505->leave($__internal_d9142f65ef0088c742b2453bb4742a0bbeef4e05423a1329082f0acdd2d24505_prof);

    }

    // line 112
    public function block_footer($context, array $blocks = array())
    {
        $__internal_a59abb74c12a566ce1a0861bf11c08eadb10067af3857d8405957449ede9532c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a59abb74c12a566ce1a0861bf11c08eadb10067af3857d8405957449ede9532c->enter($__internal_a59abb74c12a566ce1a0861bf11c08eadb10067af3857d8405957449ede9532c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_c67ed66f375868ffb523caab9eefe45d7d6b7c3229af6a3a84c9b27106963b6c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c67ed66f375868ffb523caab9eefe45d7d6b7c3229af6a3a84c9b27106963b6c->enter($__internal_c67ed66f375868ffb523caab9eefe45d7d6b7c3229af6a3a84c9b27106963b6c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 113
        echo "            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\">
                            <p>&copy; ";
        // line 117
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " - The Symfony Project</p>
                            <p>";
        // line 118
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("mit_license"), "html", null, true);
        echo "</p>
                        </div>
                        <div id=\"footer-resources\" class=\"col-md-6\">
                            <p>
                                <a href=\"https://twitter.com/symfony\" title=\"Symfony Twitter\">
                                    <i class=\"fa fa-twitter\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://www.facebook.com/SensioLabs\" title=\"SensioLabs Facebook\">
                                    <i class=\"fa fa-facebook\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://symfony.com/blog/\" title=\"Symfony Blog\">
                                    <i class=\"fa fa-rss\" aria-hidden=\"true\"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        ";
        
        $__internal_c67ed66f375868ffb523caab9eefe45d7d6b7c3229af6a3a84c9b27106963b6c->leave($__internal_c67ed66f375868ffb523caab9eefe45d7d6b7c3229af6a3a84c9b27106963b6c_prof);

        
        $__internal_a59abb74c12a566ce1a0861bf11c08eadb10067af3857d8405957449ede9532c->leave($__internal_a59abb74c12a566ce1a0861bf11c08eadb10067af3857d8405957449ede9532c_prof);

    }

    // line 138
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_48eebde87f74c604646c00b39b7acf124a1fd86bf30a4b69da15ad19773734df = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_48eebde87f74c604646c00b39b7acf124a1fd86bf30a4b69da15ad19773734df->enter($__internal_48eebde87f74c604646c00b39b7acf124a1fd86bf30a4b69da15ad19773734df_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_fae9b2baed58be5123a6cf3d1bad39d3459b573ec37987053646025fbe7b8a64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fae9b2baed58be5123a6cf3d1bad39d3459b573ec37987053646025fbe7b8a64->enter($__internal_fae9b2baed58be5123a6cf3d1bad39d3459b573ec37987053646025fbe7b8a64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 139
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 140
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 141
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-3.3.7.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 142
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/highlight.pack.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 143
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 144
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/main.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_fae9b2baed58be5123a6cf3d1bad39d3459b573ec37987053646025fbe7b8a64->leave($__internal_fae9b2baed58be5123a6cf3d1bad39d3459b573ec37987053646025fbe7b8a64_prof);

        
        $__internal_48eebde87f74c604646c00b39b7acf124a1fd86bf30a4b69da15ad19773734df->leave($__internal_48eebde87f74c604646c00b39b7acf124a1fd86bf30a4b69da15ad19773734df_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  499 => 144,  495 => 143,  491 => 142,  487 => 141,  483 => 140,  478 => 139,  469 => 138,  440 => 118,  436 => 117,  430 => 113,  421 => 112,  410 => 105,  408 => 104,  406 => 101,  397 => 100,  380 => 96,  368 => 107,  366 => 100,  361 => 97,  359 => 96,  354 => 94,  350 => 92,  341 => 91,  331 => 61,  324 => 57,  320 => 56,  317 => 55,  315 => 54,  308 => 50,  304 => 49,  301 => 48,  292 => 47,  275 => 81,  258 => 79,  254 => 78,  248 => 75,  241 => 70,  234 => 66,  230 => 65,  227 => 64,  225 => 63,  222 => 62,  220 => 47,  208 => 38,  198 => 31,  192 => 27,  183 => 26,  166 => 24,  154 => 19,  150 => 18,  146 => 17,  142 => 16,  138 => 15,  133 => 14,  124 => 13,  106 => 11,  91 => 150,  88 => 146,  86 => 138,  83 => 137,  81 => 112,  77 => 110,  75 => 91,  71 => 89,  69 => 26,  64 => 24,  57 => 21,  55 => 13,  49 => 12,  45 => 11,  38 => 7,  35 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"{{ app.request.locale }}\">
    <head>
        <meta charset=\"UTF-8\" />
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
        <title>{% block title %}Symfony Demo application{% endblock %}</title>
        <link rel=\"alternate\" type=\"application/rss+xml\" title=\"{{ 'rss.title'|trans }}\" href=\"{{ path('blog_rss') }}\">
        {% block stylesheets %}
            <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-flatly-3.3.7.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/font-awesome-4.6.3.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/font-lato.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/highlight-solarized-light.css') }}\">
            <link rel=\"stylesheet\" href=\"{{ asset('css/main.css') }}\">
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>

    <body id=\"{% block body_id %}{% endblock %}\">

        {% block header %}
            <header>
                <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
                    <div class=\"container\">
                        <div class=\"navbar-header\">
                            <a class=\"navbar-brand\" href=\"{{ path('homepage') }}\">
                                Symfony Demo
                            </a>

                            <button type=\"button\" class=\"navbar-toggle\"
                                    data-toggle=\"collapse\"
                                    data-target=\".navbar-collapse\">
                                <span class=\"sr-only\">{{ 'menu.toggle_nav'|trans }}</span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                                <span class=\"icon-bar\"></span>
                            </button>
                        </div>
                        <div class=\"navbar-collapse collapse\">
                            <ul class=\"nav navbar-nav navbar-right\">

                                {% block header_navigation_links %}
                                    <li>
                                        <a href=\"{{ path('blog_index') }}\">
                                            <i class=\"fa fa-home\" aria-hidden=\"true\"></i> {{ 'menu.homepage'|trans }}
                                        </a>
                                    </li>

                                    {% if is_granted('ROLE_ADMIN') %}
                                        <li>
                                            <a href=\"{{ path('admin_post_index') }}\">
                                                <i class=\"fa fa-lock\" aria-hidden=\"true\"></i> {{ 'menu.admin'|trans }}
                                            </a>
                                        </li>
                                    {% endif %}
                                {% endblock %}

                                {% if app.user %}
                                    <li>
                                        <a href=\"{{ path('security_logout') }}\">
                                            <i class=\"fa fa-sign-out\" aria-hidden=\"true\"></i> {{ 'menu.logout'|trans }}
                                        </a>
                                    </li>
                                {% endif %}

                                <li class=\"dropdown\">
                                    <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-expanded=\"false\" id=\"locales\">
                                        <i class=\"fa fa-globe\" aria-hidden=\"true\"></i>
                                        <span class=\"caret\"></span>
                                        <span class=\"sr-only\">{{ 'menu.choose_language'|trans }}</span>
                                    </a>
                                    <ul class=\"dropdown-menu locales\" role=\"menu\" aria-labelledby=\"locales\">
                                        {% for locale in locales() %}
                                            <li {% if app.request.locale == locale.code %}aria-checked=\"true\" class=\"active\"{%else%}aria-checked=\"false\"{% endif %} role=\"menuitem\"><a href=\"{{ path(app.request.get('_route', 'blog_index'), app.request.get('_route_params', [])|merge({ _locale: locale.code })) }}\">{{ locale.name|capitalize }}</a></li>
                                        {% endfor %}
                                    </ul>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </header>
        {% endblock %}

        <div class=\"container body-container\">
            {% block body %}
                <div class=\"row\">
                    <div id=\"main\" class=\"col-sm-9\">
                        {{ include('default/_flash_messages.html.twig') }}

                        {% block main %}{% endblock %}
                    </div>

                    <div id=\"sidebar\" class=\"col-sm-3\">
                        {% block sidebar %}
                            {{ render_esi(controller('FrameworkBundle:Template:template', {
                                'template': 'blog/about.html.twig',
                                'sharedAge': 600,
                                '_locale': app.request.locale
                            })) }}
                        {% endblock %}
                    </div>
                </div>
            {% endblock %}
        </div>

        {% block footer %}
            <footer>
                <div class=\"container\">
                    <div class=\"row\">
                        <div id=\"footer-copyright\" class=\"col-md-6\">
                            <p>&copy; {{ 'now'|date('Y') }} - The Symfony Project</p>
                            <p>{{ 'mit_license'|trans }}</p>
                        </div>
                        <div id=\"footer-resources\" class=\"col-md-6\">
                            <p>
                                <a href=\"https://twitter.com/symfony\" title=\"Symfony Twitter\">
                                    <i class=\"fa fa-twitter\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://www.facebook.com/SensioLabs\" title=\"SensioLabs Facebook\">
                                    <i class=\"fa fa-facebook\" aria-hidden=\"true\"></i>
                                </a>
                                <a href=\"https://symfony.com/blog/\" title=\"Symfony Blog\">
                                    <i class=\"fa fa-rss\" aria-hidden=\"true\"></i>
                                </a>
                            </p>
                        </div>
                    </div>
                </div>
            </footer>
        {% endblock %}

        {% block javascripts %}
            <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
            <script src=\"{{ asset('js/moment.min.js') }}\"></script>
            <script src=\"{{ asset('js/bootstrap-3.3.7.min.js') }}\"></script>
            <script src=\"{{ asset('js/highlight.pack.js') }}\"></script>
            <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
            <script src=\"{{ asset('js/main.js') }}\"></script>
        {% endblock %}

        {# it's not mandatory to set the timezone in localizeddate(). This is done to
           avoid errors when the 'intl' PHP extension is not available and the application
           is forced to use the limited \"intl polyfill\", which only supports UTC and GMT #}
        <!-- Page rendered on {{ 'now'|localizeddate('long', 'long', null, 'UTC') }} -->
    </body>
</html>
", "::base.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/base.html.twig");
    }
}
