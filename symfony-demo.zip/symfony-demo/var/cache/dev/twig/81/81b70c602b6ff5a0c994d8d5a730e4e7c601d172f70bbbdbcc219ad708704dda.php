<?php

/* :blog:_rss.html.twig */
class __TwigTemplate_1c149b881c0509b35889b717d830d758206e8b5de0e36fb58241e96394d49240 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f2c8c0da10fb81e2fe2dac62ec01cb53bca041d77f81cfd7e434af663358bb7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5f2c8c0da10fb81e2fe2dac62ec01cb53bca041d77f81cfd7e434af663358bb7->enter($__internal_5f2c8c0da10fb81e2fe2dac62ec01cb53bca041d77f81cfd7e434af663358bb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:_rss.html.twig"));

        $__internal_9695cd6c7208874b54bf0c2a5f4f91e0f10c526b8129fd29308e98ffbcc7a2a9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9695cd6c7208874b54bf0c2a5f4f91e0f10c526b8129fd29308e98ffbcc7a2a9->enter($__internal_9695cd6c7208874b54bf0c2a5f4f91e0f10c526b8129fd29308e98ffbcc7a2a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":blog:_rss.html.twig"));

        // line 1
        echo "<div class=\"section rss\">
    <a href=\"";
        // line 2
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("blog_rss");
        echo "\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> ";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\TranslationExtension')->trans("menu.rss"), "html", null, true);
        echo "
    </a>
</div>
";
        
        $__internal_5f2c8c0da10fb81e2fe2dac62ec01cb53bca041d77f81cfd7e434af663358bb7->leave($__internal_5f2c8c0da10fb81e2fe2dac62ec01cb53bca041d77f81cfd7e434af663358bb7_prof);

        
        $__internal_9695cd6c7208874b54bf0c2a5f4f91e0f10c526b8129fd29308e98ffbcc7a2a9->leave($__internal_9695cd6c7208874b54bf0c2a5f4f91e0f10c526b8129fd29308e98ffbcc7a2a9_prof);

    }

    public function getTemplateName()
    {
        return ":blog:_rss.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"section rss\">
    <a href=\"{{ path('blog_rss') }}\">
        <i class=\"fa fa-rss\" aria-hidden=\"true\"></i> {{ 'menu.rss'|trans }}
    </a>
</div>
", ":blog:_rss.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app/Resources\\views/blog/_rss.html.twig");
    }
}
