<?php

/* form/fields.html.twig */
class __TwigTemplate_e3b5afee12eb256ea263fafec231d229374385cf973b9670910118e3c8584d5f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7ba537ae5c7f87f4c471911b20169840b67ea8fa1a03e084914603b532150e4f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ba537ae5c7f87f4c471911b20169840b67ea8fa1a03e084914603b532150e4f->enter($__internal_7ba537ae5c7f87f4c471911b20169840b67ea8fa1a03e084914603b532150e4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        $__internal_74b781befd3c1f1d872493946123d240fe3ec0a9d494b3b329d95f886b879259 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_74b781befd3c1f1d872493946123d240fe3ec0a9d494b3b329d95f886b879259->enter($__internal_74b781befd3c1f1d872493946123d240fe3ec0a9d494b3b329d95f886b879259_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        
        $__internal_7ba537ae5c7f87f4c471911b20169840b67ea8fa1a03e084914603b532150e4f->leave($__internal_7ba537ae5c7f87f4c471911b20169840b67ea8fa1a03e084914603b532150e4f_prof);

        
        $__internal_74b781befd3c1f1d872493946123d240fe3ec0a9d494b3b329d95f886b879259->leave($__internal_74b781befd3c1f1d872493946123d240fe3ec0a9d494b3b329d95f886b879259_prof);

    }

    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_4ecb10518b6ef15325503b25e0d32800ec2d52b90f952a7a6ad7948cbf80fa5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4ecb10518b6ef15325503b25e0d32800ec2d52b90f952a7a6ad7948cbf80fa5f->enter($__internal_4ecb10518b6ef15325503b25e0d32800ec2d52b90f952a7a6ad7948cbf80fa5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        $__internal_feba9d68a17d253c79f4ecb4e4acdde48d8818713fd0d64be09ed015083613b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_feba9d68a17d253c79f4ecb4e4acdde48d8818713fd0d64be09ed015083613b7->enter($__internal_feba9d68a17d253c79f4ecb4e4acdde48d8818713fd0d64be09ed015083613b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        ";
        // line 12
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
";
        
        $__internal_feba9d68a17d253c79f4ecb4e4acdde48d8818713fd0d64be09ed015083613b7->leave($__internal_feba9d68a17d253c79f4ecb4e4acdde48d8818713fd0d64be09ed015083613b7_prof);

        
        $__internal_4ecb10518b6ef15325503b25e0d32800ec2d52b90f952a7a6ad7948cbf80fa5f->leave($__internal_4ecb10518b6ef15325503b25e0d32800ec2d52b90f952a7a6ad7948cbf80fa5f_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  50 => 12,  47 => 11,  29 => 10,  26 => 9,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    <div class=\"input-group date\" data-toggle=\"datetimepicker\">
        {{ block('datetime_widget') }}
        <span class=\"input-group-addon\">
            <span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>
        </span>
    </div>
{% endblock %}
", "form/fields.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\app\\Resources\\views\\form\\fields.html.twig");
    }
}
