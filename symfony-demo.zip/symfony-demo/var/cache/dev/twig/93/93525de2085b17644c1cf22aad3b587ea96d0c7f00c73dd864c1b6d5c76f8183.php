<?php

/* @Twig/Exception/error.json.twig */
class __TwigTemplate_8a531fbec75105cb788a00f2bdecdf2312d2c096d0e1f2f9e038ebceb164ca34 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_124ffa8ceef233318dbd6066c0e7dbb0bbde68159f1a4fec5d8540dbde7bcbae = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_124ffa8ceef233318dbd6066c0e7dbb0bbde68159f1a4fec5d8540dbde7bcbae->enter($__internal_124ffa8ceef233318dbd6066c0e7dbb0bbde68159f1a4fec5d8540dbde7bcbae_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        $__internal_8a4bbb329bdc58ea5763a7dc49dd7f828be5c315022cd3212bf756f491e572e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8a4bbb329bdc58ea5763a7dc49dd7f828be5c315022cd3212bf756f491e572e3->enter($__internal_8a4bbb329bdc58ea5763a7dc49dd7f828be5c315022cd3212bf756f491e572e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/error.json.twig"));

        // line 1
        echo twig_jsonencode_filter(array("error" => array("code" => (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "message" => (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")))));
        echo "
";
        
        $__internal_124ffa8ceef233318dbd6066c0e7dbb0bbde68159f1a4fec5d8540dbde7bcbae->leave($__internal_124ffa8ceef233318dbd6066c0e7dbb0bbde68159f1a4fec5d8540dbde7bcbae_prof);

        
        $__internal_8a4bbb329bdc58ea5763a7dc49dd7f828be5c315022cd3212bf756f491e572e3->leave($__internal_8a4bbb329bdc58ea5763a7dc49dd7f828be5c315022cd3212bf756f491e572e3_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/error.json.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ { 'error': { 'code': status_code, 'message': status_text } }|json_encode|raw }}
", "@Twig/Exception/error.json.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\error.json.twig");
    }
}
