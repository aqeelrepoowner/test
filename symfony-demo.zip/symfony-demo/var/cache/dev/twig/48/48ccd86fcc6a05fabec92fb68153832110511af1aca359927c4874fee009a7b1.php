<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_b11224d64d4f4a49035f13d7ebd69d7bdb1657e3952df26f313f0fa60b013e58 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63564fdcdbbf7739faeaa9d0848fe574a1e5ab6ec7c07042efda3d610ae06571 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_63564fdcdbbf7739faeaa9d0848fe574a1e5ab6ec7c07042efda3d610ae06571->enter($__internal_63564fdcdbbf7739faeaa9d0848fe574a1e5ab6ec7c07042efda3d610ae06571_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_391f567331c5248b15e7fd36cdc5dba723772d3802508bf059da589627f5a3b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_391f567331c5248b15e7fd36cdc5dba723772d3802508bf059da589627f5a3b3->enter($__internal_391f567331c5248b15e7fd36cdc5dba723772d3802508bf059da589627f5a3b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_63564fdcdbbf7739faeaa9d0848fe574a1e5ab6ec7c07042efda3d610ae06571->leave($__internal_63564fdcdbbf7739faeaa9d0848fe574a1e5ab6ec7c07042efda3d610ae06571_prof);

        
        $__internal_391f567331c5248b15e7fd36cdc5dba723772d3802508bf059da589627f5a3b3->leave($__internal_391f567331c5248b15e7fd36cdc5dba723772d3802508bf059da589627f5a3b3_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_00cbbdf506720ddbf997d6fc647af2ec89c84857f5543e97587a8bbe76267af2 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_00cbbdf506720ddbf997d6fc647af2ec89c84857f5543e97587a8bbe76267af2->enter($__internal_00cbbdf506720ddbf997d6fc647af2ec89c84857f5543e97587a8bbe76267af2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_4e7ca12a480a2940a2c61e64d86273c73c743c849d56f61065696c8a363dc1fe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4e7ca12a480a2940a2c61e64d86273c73c743c849d56f61065696c8a363dc1fe->enter($__internal_4e7ca12a480a2940a2c61e64d86273c73c743c849d56f61065696c8a363dc1fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_4e7ca12a480a2940a2c61e64d86273c73c743c849d56f61065696c8a363dc1fe->leave($__internal_4e7ca12a480a2940a2c61e64d86273c73c743c849d56f61065696c8a363dc1fe_prof);

        
        $__internal_00cbbdf506720ddbf997d6fc647af2ec89c84857f5543e97587a8bbe76267af2->leave($__internal_00cbbdf506720ddbf997d6fc647af2ec89c84857f5543e97587a8bbe76267af2_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_7ab64aff811ae2b84a5773b1f575dea7c0ebada8d5835d9ad77bd18bffc06c6a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7ab64aff811ae2b84a5773b1f575dea7c0ebada8d5835d9ad77bd18bffc06c6a->enter($__internal_7ab64aff811ae2b84a5773b1f575dea7c0ebada8d5835d9ad77bd18bffc06c6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_80597985930838043a2eab7405a4e91e06018164aa88669b38485f7ecc75e647 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80597985930838043a2eab7405a4e91e06018164aa88669b38485f7ecc75e647->enter($__internal_80597985930838043a2eab7405a4e91e06018164aa88669b38485f7ecc75e647_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_80597985930838043a2eab7405a4e91e06018164aa88669b38485f7ecc75e647->leave($__internal_80597985930838043a2eab7405a4e91e06018164aa88669b38485f7ecc75e647_prof);

        
        $__internal_7ab64aff811ae2b84a5773b1f575dea7c0ebada8d5835d9ad77bd18bffc06c6a->leave($__internal_7ab64aff811ae2b84a5773b1f575dea7c0ebada8d5835d9ad77bd18bffc06c6a_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_90a5e89a622cc600fa50004d60e06777d9161b3300a2ca4a55b6e66917d3a4f6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_90a5e89a622cc600fa50004d60e06777d9161b3300a2ca4a55b6e66917d3a4f6->enter($__internal_90a5e89a622cc600fa50004d60e06777d9161b3300a2ca4a55b6e66917d3a4f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_e15df44101c810fc49129c0d07a7635b67652ef4c6b3464827fd75df9b246920 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e15df44101c810fc49129c0d07a7635b67652ef4c6b3464827fd75df9b246920->enter($__internal_e15df44101c810fc49129c0d07a7635b67652ef4c6b3464827fd75df9b246920_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e15df44101c810fc49129c0d07a7635b67652ef4c6b3464827fd75df9b246920->leave($__internal_e15df44101c810fc49129c0d07a7635b67652ef4c6b3464827fd75df9b246920_prof);

        
        $__internal_90a5e89a622cc600fa50004d60e06777d9161b3300a2ca4a55b6e66917d3a4f6->leave($__internal_90a5e89a622cc600fa50004d60e06777d9161b3300a2ca4a55b6e66917d3a4f6_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
