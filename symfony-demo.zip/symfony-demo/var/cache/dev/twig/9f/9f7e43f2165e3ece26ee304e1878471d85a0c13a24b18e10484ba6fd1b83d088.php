<?php

/* @Twig/Exception/traces.txt.twig */
class __TwigTemplate_3267b264f61039abd51a89a9354bc92022c34cca3920e7da9403abb1e4f0c5c7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_948e00d47a64876da4aefce1292144b4f6d1d04692d513ec85d891d5ceb3cf01 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_948e00d47a64876da4aefce1292144b4f6d1d04692d513ec85d891d5ceb3cf01->enter($__internal_948e00d47a64876da4aefce1292144b4f6d1d04692d513ec85d891d5ceb3cf01_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        $__internal_57c7c9a477af740faf05dde5dabcd3f60fd65c166fca259b52f4f8923438522c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_57c7c9a477af740faf05dde5dabcd3f60fd65c166fca259b52f4f8923438522c->enter($__internal_57c7c9a477af740faf05dde5dabcd3f60fd65c166fca259b52f4f8923438522c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/traces.txt.twig"));

        // line 1
        if (twig_length_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "trace", array()))) {
            // line 2
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "trace", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["trace"]) {
                // line 3
                $this->loadTemplate("@Twig/Exception/trace.txt.twig", "@Twig/Exception/traces.txt.twig", 3)->display(array("trace" => $context["trace"]));
                // line 4
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['trace'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        
        $__internal_948e00d47a64876da4aefce1292144b4f6d1d04692d513ec85d891d5ceb3cf01->leave($__internal_948e00d47a64876da4aefce1292144b4f6d1d04692d513ec85d891d5ceb3cf01_prof);

        
        $__internal_57c7c9a477af740faf05dde5dabcd3f60fd65c166fca259b52f4f8923438522c->leave($__internal_57c7c9a477af740faf05dde5dabcd3f60fd65c166fca259b52f4f8923438522c_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/traces.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 4,  31 => 3,  27 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if exception.trace|length %}
{% for trace in exception.trace %}
{% include '@Twig/Exception/trace.txt.twig' with { 'trace': trace } only %}

{% endfor %}
{% endif %}
", "@Twig/Exception/traces.txt.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\Exception\\traces.txt.twig");
    }
}
