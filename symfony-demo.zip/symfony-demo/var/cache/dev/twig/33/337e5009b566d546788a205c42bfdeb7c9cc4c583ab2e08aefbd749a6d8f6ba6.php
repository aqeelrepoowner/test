<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_1e040d6da1863315657e17e66cf0243fff1901c06a97e26b6a163b5dd5087f62 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2351b67918aaa8df6113e1789549079b6cca869e288d77e2fa0b382dcb5d09bf = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2351b67918aaa8df6113e1789549079b6cca869e288d77e2fa0b382dcb5d09bf->enter($__internal_2351b67918aaa8df6113e1789549079b6cca869e288d77e2fa0b382dcb5d09bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $__internal_8071e99251757930a00bf1d99b945dd0b8f482c9f71f3407e0b66661d48e285c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8071e99251757930a00bf1d99b945dd0b8f482c9f71f3407e0b66661d48e285c->enter($__internal_8071e99251757930a00bf1d99b945dd0b8f482c9f71f3407e0b66661d48e285c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2351b67918aaa8df6113e1789549079b6cca869e288d77e2fa0b382dcb5d09bf->leave($__internal_2351b67918aaa8df6113e1789549079b6cca869e288d77e2fa0b382dcb5d09bf_prof);

        
        $__internal_8071e99251757930a00bf1d99b945dd0b8f482c9f71f3407e0b66661d48e285c->leave($__internal_8071e99251757930a00bf1d99b945dd0b8f482c9f71f3407e0b66661d48e285c_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_07f77de3ad4a4c2cd32192475978ad18c2f22444a412634f4f97546cdbde5484 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_07f77de3ad4a4c2cd32192475978ad18c2f22444a412634f4f97546cdbde5484->enter($__internal_07f77de3ad4a4c2cd32192475978ad18c2f22444a412634f4f97546cdbde5484_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_48dab5699970bb72dff94496cb80829e9efb944bf6ca0128f8c6bf4064a2e6fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_48dab5699970bb72dff94496cb80829e9efb944bf6ca0128f8c6bf4064a2e6fb->enter($__internal_48dab5699970bb72dff94496cb80829e9efb944bf6ca0128f8c6bf4064a2e6fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_48dab5699970bb72dff94496cb80829e9efb944bf6ca0128f8c6bf4064a2e6fb->leave($__internal_48dab5699970bb72dff94496cb80829e9efb944bf6ca0128f8c6bf4064a2e6fb_prof);

        
        $__internal_07f77de3ad4a4c2cd32192475978ad18c2f22444a412634f4f97546cdbde5484->leave($__internal_07f77de3ad4a4c2cd32192475978ad18c2f22444a412634f4f97546cdbde5484_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a2960f652a0ddbaaf39e69d983ce401ca8f399757ec164fd3ecb6d57c65f3a5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2960f652a0ddbaaf39e69d983ce401ca8f399757ec164fd3ecb6d57c65f3a5f->enter($__internal_a2960f652a0ddbaaf39e69d983ce401ca8f399757ec164fd3ecb6d57c65f3a5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_44eb9e8a1fa004f4f6414d7012fcde914a5623d75dbf40e7c8912369deb32939 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_44eb9e8a1fa004f4f6414d7012fcde914a5623d75dbf40e7c8912369deb32939->enter($__internal_44eb9e8a1fa004f4f6414d7012fcde914a5623d75dbf40e7c8912369deb32939_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_44eb9e8a1fa004f4f6414d7012fcde914a5623d75dbf40e7c8912369deb32939->leave($__internal_44eb9e8a1fa004f4f6414d7012fcde914a5623d75dbf40e7c8912369deb32939_prof);

        
        $__internal_a2960f652a0ddbaaf39e69d983ce401ca8f399757ec164fd3ecb6d57c65f3a5f->leave($__internal_a2960f652a0ddbaaf39e69d983ce401ca8f399757ec164fd3ecb6d57c65f3a5f_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_a1dbc62dec696b70e1fccc33537ef962515434498193de4f940296a2272253ac = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a1dbc62dec696b70e1fccc33537ef962515434498193de4f940296a2272253ac->enter($__internal_a1dbc62dec696b70e1fccc33537ef962515434498193de4f940296a2272253ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_a0d9fc58c9d99cd908a10eb133701e96f1e847e71302935cba6176558565eeba = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0d9fc58c9d99cd908a10eb133701e96f1e847e71302935cba6176558565eeba->enter($__internal_a0d9fc58c9d99cd908a10eb133701e96f1e847e71302935cba6176558565eeba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_a0d9fc58c9d99cd908a10eb133701e96f1e847e71302935cba6176558565eeba->leave($__internal_a0d9fc58c9d99cd908a10eb133701e96f1e847e71302935cba6176558565eeba_prof);

        
        $__internal_a1dbc62dec696b70e1fccc33537ef962515434498193de4f940296a2272253ac->leave($__internal_a1dbc62dec696b70e1fccc33537ef962515434498193de4f940296a2272253ac_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "WebProfilerBundle:Collector:router.html.twig", "C:\\wamp\\www\\blog\\symfony-demo\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
