<?php

namespace AppBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * @ORM\Entity
 * @ORM\Table(name="maktab")
 *
 * Defines the properties of the User entity to represent the application users.
 * See http://symfony.com/doc/current/book/doctrine.html#creating-an-entity-class
 *
 * Tip: if you have an existing database, you can generate these entity class automatically.
 * See http://symfony.com/doc/current/cookbook/doctrine/reverse_engineering.html
 *
 * @author Ryan Weaver <weaverryan@gmail.com>
 * @author Javier Eguiluz <javier.eguiluz@gmail.com>
 */
class Maktab
{
    /**
     * @var int
     *
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @var string
     *
     * @ORM\Column(type="string", unique=true)
     *  @Assert\NotBlank(message="Maktab Name should not be empty")
     *  @Assert\Length(max=50, maxMessage="Maktab Name field exceeded number of characters")
     */
    private $maktabName;

    /**
     * @var string
     *
     * @ORM\Column(type="string")
     *  @Assert\NotBlank(message="Maktab Desc should not be empty")
     *  @Assert\Length(max=100, maxMessage="Maktab Desc field exceeded number of characters")
     */
    private $maktabDesc;

    /**
     * @var text
     *
     * @ORM\Column(type="text")
     */
    private $maktabAddress;

    /**
     * @var date
     *
     * @ORM\Column(type="date")
     */
    private $createdOn;

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set courseName
     *
     * @param string $courseName
     *
     * @return Course
     */
    public function setCourseName($courseName)
    {
        $this->courseName = $courseName;

        return $this;
    }

    /**
     * Get courseName
     *
     * @return string
     */
    public function getCourseName()
    {
        return $this->courseName;
    }

    /**
     * Set courseDescription
     *
     * @param string $courseDescription
     *
     * @return Course
     */
    public function setCourseDescription($courseDescription)
    {
        $this->courseDescription = $courseDescription;

        return $this;
    }

    /**
     * Get courseDescription
     *
     * @return string
     */
    public function getCourseDescription()
    {
        return $this->courseDescription;
    }

    /**
     * Set maktabName
     *
     * @param string $maktabName
     *
     * @return Maktab
     */
    public function setMaktabName($maktabName)
    {
        $this->maktabName = $maktabName;

        return $this;
    }

    /**
     * Get maktabName
     *
     * @return string
     */
    public function getMaktabName()
    {
        return $this->maktabName;
    }

    /**
     * Set maktabDesc
     *
     * @param string $maktabDesc
     *
     * @return Maktab
     */
    public function setMaktabDesc($maktabDesc)
    {
        $this->maktabDesc = $maktabDesc;

        return $this;
    }

    /**
     * Get maktabDesc
     *
     * @return string
     */
    public function getMaktabDesc()
    {
        return $this->maktabDesc;
    }

    /**
     * Set maktabAddress
     *
     * @param string $maktabAddress
     *
     * @return Maktab
     */
    public function setMaktabAddress($maktabAddress)
    {
        $this->maktabAddress = $maktabAddress;

        return $this;
    }

    /**
     * Get maktabAddress
     *
     * @return string
     */
    public function getMaktabAddress()
    {
        return $this->maktabAddress;
    }

    /**
     * Set createdOn
     *
     * @param \DateTime $createdOn
     *
     * @return Maktab
     */
    public function setCreatedOn($createdOn)
    {
        $this->createdOn = $createdOn;

        return $this;
    }

    /**
     * Get createdOn
     *
     * @return \DateTime
     */
    public function getCreatedOn()
    {
        return $this->createdOn;
    }
}
