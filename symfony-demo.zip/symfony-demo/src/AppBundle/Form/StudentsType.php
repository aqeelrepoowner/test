<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace AppBundle\Form;

use AppBundle\Entity\Students;
use AppBundle\Form\Type\DateTimePickerType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

/**
 * Defines the form used to create and manipulate blog posts.
 *
 * @author Ryan Weaver <weaverryan@gmail.com>
 * @author Javier Eguiluz <javier.eguiluz@gmail.com>
 */
class StudentsType extends AbstractType
{
    /**
     * {@inheritdoc}
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        // For the full reference of options defined by each form field type
        // see http://symfony.com/doc/current/reference/forms/types.html

        // By default, form fields include the 'required' attribute, which enables
        // the client-side form validation. This means that you can't test the
        // server-side validation errors from the browser. To temporarily disable
        // this validation, set the 'required' attribute to 'false':
        // $builder->add('title', null, ['required' => false, ...]);

        $builder
            ->add('first_name', TextType::class, [
                'attr' => ['autofocus' => true],
                'label' => 'label.student_first_name',
                'required'    => true,
              //  'placeholder' => 'Choose your First Name'
            ])
            ->add('last_name', TextType::class, [
                'label' => 'label.student_last_name',
                'required'    => true,
              //  'placeholder' => 'Choose your Last Name'
            ])
            ->add('email', EmailType::class, [
                'label' => 'label.student_email',
                'required'    => true,
             //   'placeholder' => 'Choose your Email'
            ])
            ->add('fatherName', TextType::class, [
                'label' => 'label.student_fatherName',
                'required'    => true,
              //  'placeholder' => 'Choose your Father Name'
            ])
            ->add('dob', DateType::class, [
                'widget' => 'single_text',
                // do not render as type="date", to avoid HTML5 date pickers
                'html5' => false,
                // add a class that can be selected in JavaScript
                'attr' => ['class' => 'js-datepicker'],
                'label' => 'label.student_dob',
                'required'    => true,
              //  'placeholder' => 'Choose your Date of Birth'
            ])
            ->add('gender', ChoiceType::class, [
                'choices' => [
                    'Male' => 'm',
                    'Female' => 'f'
                ],
                'label' => 'label.student_gender',
                'required'    => true,
               // 'placeholder' => 'Choose your Gender'
            ])
            ->add('registered_date', HiddenType::class, [
                'label' => 'label.student_reg_date',
                'data' => date('Y-m-d'),
            ])
             ->add('contact_no', TextType::class, [
                'label' => 'label.student_contact_no',
                'required'    => true,
              //  'placeholder' => 'Choose your Contact Number'
            ])
            ->add('courseId', EntityType::class, [
                'label' => 'label.student_course_name',
                // query choices from this entity
                'class' => 'AppBundle:Course',
                // use the User.username property as the visible option string
                'choice_label' => 'courseName',
                // used to render a select box, check boxes or radios
                // 'multiple' => true,
                // 'expanded' => true,
                'required'    => true,
                'placeholder' => 'Choose your Course'
            ]) 
            ->add('maktabId', EntityType::class, [
                'label' => 'label.student_maktab_name',
                // query choices from this entity
                'class' => 'AppBundle:Maktab',
                // use the User.username property as the visible option string
                'choice_label' => 'maktabName',
                // used to render a select box, check boxes or radios
                // 'multiple' => true,
                // 'expanded' => true,
                'required'    => true,
                'placeholder' => 'Choose your Maktab'
            ])
            ->add('teacherId', EntityType::class, [
                'label' => 'label.student_teacher_name',
                // query choices from this entity
                'class' => 'AppBundle:Teachers',
                // use the User.username property as the visible option string
                'choice_label' => function ($teachers) {
                    return $teachers->getFirstName()." ".$teachers->getLastName();
                },
                // used to render a select box, check boxes or radios
                // 'multiple' => true,
                // 'expanded' => true,
                'required'    => true,
                'placeholder' => 'Choose your Teacher'
            ]);
    }

    /**
     * {@inheritdoc}
     */
    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'data_class' => Students::class,
        ]);
    }
}
