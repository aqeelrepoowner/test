<?php

/*
 * This file is part of the Symfony package.
 *
 * (c) Fabien Potencier <fabien@symfony.com>
 *
 * For the full copyright and license information, please view the LICENSE
 * file that was distributed with this source code.
 */

namespace AppBundle\Controller\Admin;

use AppBundle\Entity\Students;
use AppBundle\Entity\Course;
use AppBundle\Entity\Maktab;
use AppBundle\Entity\Teachers;
use AppBundle\Form\StudentsType;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Security;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;

/**
 * Controller used to manage students contents in the backend.
 *
 * Please note that the application backend is developed manually for learning
 * purposes. However, in your real Symfony application you should use any of the
 * existing bundles that let you generate ready-to-use backends without effort.
 *
 * See http://knpbundles.com/keyword/admin
 *
 * @Route("/admin/students")
 * @Security("has_role('ROLE_ADMIN')")
 *
 * @author Ryan Weaver <weaverryan@gmail.com>
 * @author Javier Eguiluz <javier.eguiluz@gmail.com>
 */
class StudentsController extends Controller
{
    /**
     * Lists all  student entities.
     *
     * This controller responds to two different routes with the same URL:
     *   * 'admin_ student_index' is the route with a name that follows the same
     *     structure as the rest of the controllers of this class.
     *   * 'admin_index' is a nice shortcut to the backend homepage. This allows
     *     to create simpler links in the templates. Moreover, in the future we
     *     could move this annotation to any other controller while maintaining
     *     the route name and therefore, without breaking any existing link.
     *
     * @Route("/", name="admin_index")
     * @Route("/", name="admin_student_index")
     * @Method("GET")
     */
    public function indexAction()
    {
        $entityManager = $this->getDoctrine()->getManager();
        $students = $entityManager->getRepository(Students::class)->findAll();

        return $this->render('admin/students/index.html.twig', ['students' => $students]);
    }

    /**
     * Creates a new  student entity.
     *
     * @Route("/new", name="admin_student_new")
     * @Method("GET")
     *
     * NOTE: the Method annotation is optional, but it's a recommended practice
     * to constraint the HTTP methods each controller responds to (by default
     * it responds to all methods).
     */
    public function newAction(Request $request)
    {
        //$student = new Students();
        // See http://symfony.com/doc/current/book/forms.html#submitting-forms-with-multiple-buttons
        $form = $this->createForm(StudentsType::class)
         ->add('saveAndCreateNew', SubmitType::class);

        $form->handleRequest($request);

        // the isSubmitted() method is completely optional because the other
        // isValid() method already checks whether the form is submitted.
        // However, we explicitly add it to improve code readability.
        // See http://symfony.com/doc/current/best_practices/forms.html#handling-form-submits
       /* if ($form->isSubmitted() && $form->isValid()) {
          //  $student->setSlug($this->get('slugger')->slugify($student->getTitle()));
            /** @var Comment $comment 
            $student = $form->getData();
            //$student->setCourse($course);
            //$student->setMaktab($maktab);
           // $student->setTeacher($teacher);


            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($student);
            $entityManager->flush();

            // Flash messages are used to notify the user about the result of the
            // actions. They are deleted automatically from the session as soon
            // as they are accessed.
            // See http://symfony.com/doc/current/book/controller.html#flash-messages
            $this->addFlash('success', 'Student created Successfully !');

            if ($form->get('saveAndCreateNew')->isClicked()) {
                return $this->redirectToRoute('admin_student_new');
            }

            return $this->redirectToRoute('admin_student_index');
        }*/

        return $this->render('admin/students/new.html.twig', [
            'form' => $form->createView(),
        ]);
    }

    /**
     * Finds and displays a  student entity.
     *
     * @Route("/{id}", requirements={"id": "\d+"}, name="admin_ student_show")
     * @Method("GET")
     */
    public function showAction(Students $student)
    {
        // This security check can also be performed
        // using an annotation: @Security("is_granted('show',  student)")
        $this->denyAccessUnlessGranted('show', $student, ' students can only be shown to their authors.');

        return $this->render('admin/students/show.html.twig', [
            'students' => $student,
        ]);
    }

    /**
     * Displays a form to edit an existing  student entity.
     *
     * @Route("/{id}/edit", requirements={"id": "\d+"}, name="admin_ student_edit")
     * @Method({"GET", " student"})
     */
    public function editAction(Students $student, Request $request)
    {
        $this->denyAccessUnlessGranted('edit', $student, ' students can only be edited by their authors.');

        $entityManager = $this->getDoctrine()->getManager();

        $form = $this->createForm( studentType::class, $student);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $student->setSlug($this->get('slugger')->slugify($student->getTitle()));
            $entityManager->flush();

            $this->addFlash('success', ' student.updated_successfully');

            return $this->redirectToRoute('admin_ student_edit', ['id' => $student->getId()]);
        }

        return $this->render('admin/students/edit.html.twig', [
            ' student' => $student,
            'form' => $form->createView(),
        ]);
    }

    /**
     * Deletes a  student entity.
     *
     * @Route("/{id}/delete", name="admin_ student_delete")
     * @Method(" student")
     * @Security("is_granted('delete',  student)")
     *
     * The Security annotation value is an expression (if it evaluates to false,
     * the authorization mechanism will prevent the user accessing this resource).
     */
    public function deleteAction(Request $request,Students $student)
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return $this->redirectToRoute('admin_ student_index');
        }

        $entityManager = $this->getDoctrine()->getManager();

        $entityManager->remove($student);
        $entityManager->flush();

        $this->addFlash('success', ' student.deleted_successfully');

        return $this->redirectToRoute('admin_ student_index');
    }
}