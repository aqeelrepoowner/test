<?php
// src/BugRepository.php

use Doctrine\ORM\EntityRepository;

class BugRepository extends EntityRepository
{
    private $entity;
    public function init()
    {
        $entity =  $this->getEntityName();
        $this->entity = new $entity();
    }

    public function createBugs($theReporterId,$theDefaultEngineerId, $productIds)
    {
        $productIds = explode(",", $productIds);
        
        $reporter = $this->getEntityManager()->find("User", $theReporterId);
        $engineer = $this->getEntityManager()->find("User", $theDefaultEngineerId);

        if (!$reporter || !$engineer) {
            echo "No reporter and/or engineer found for the input.\n";
            exit(1);
        }

        $this->entity->setDescription("Something does not work!");
        $this->entity->setCreated(new DateTime("now"));
        $this->entity->setStatus("OPEN");

        foreach ($productIds as $productId) {
            $product = $this->getEntityManager()->find('Product', $productId);
            $this->entity->assignToProduct($product);
        }

        $this->entity->setReporter($reporter);
        $this->entity->setEngineer($engineer);

        $this->getEntityManager()->persist($this->entity);
        $this->getEntityManager()->flush();
        echo "Your new Bug Id: ".$this->entity->getId()."\n";
    }

    public function updateBugs($updateValue)
    {
         $Bug = $this->getEntityManager()->find('Bug', $id);

        if ($Bug === null) {
            echo "Bug $id does not exist.\n";
            exit(1);
        }

        $this->entity->setName($updateValue);

        $this->getEntityManager()->flush();
    }

    public function getRecentBugs($number = 30)
    {
        $dql = "SELECT b, e, r FROM Bug b JOIN b.engineer e JOIN b.reporter r ORDER BY b.created DESC";

        $query = $this->getEntityManager()->createQuery($dql);
        $query->setMaxResults($number);
        return $query->getResult();
    }

    public function getRecentBugsArray($number = 30)
    {
        $dql = "SELECT b, e, r, p FROM Bug b JOIN b.engineer e ".
               "JOIN b.reporter r JOIN b.products p ORDER BY b.created DESC";
        $query = $this->getEntityManager()->createQuery($dql);
        $query->setMaxResults($number);
        return $query->getArrayResult();
    }

    public function getUsersBugs($userId, $number = 15)
    {
        $dql = "SELECT b, e, r FROM Bug b JOIN b.engineer e JOIN b.reporter r ".
               "WHERE b.status = 'OPEN' AND e.id = ?1 OR r.id = ?1 ORDER BY b.created DESC";

        return $this->getEntityManager()->createQuery($dql)
                             ->setParameter(1, $userId)
                             ->setMaxResults($number)
                             ->getResult();
    }

    public function getOpenBugsByProduct()
    {
        $dql = "SELECT p.id, p.name, count(b.id) AS openBugs FROM Bug b ".
               "JOIN b.products p WHERE b.status = 'OPEN' GROUP BY p.id";
        return $this->getEntityManager()->createQuery($dql)->getScalarResult();
    }

    public function getRecentBugsById($bugId)
    {
        $dql = "SELECT b, e, r, p FROM Bug b JOIN b.engineer e ".
               "JOIN b.reporter r JOIN b.products p 
               WHERE b.id = $bugId
               ORDER BY b.created DESC";
        $query = $this->getEntityManager()->createQuery($dql);
        $query->setMaxResults(30);
        return $query->getResult();
    }
}