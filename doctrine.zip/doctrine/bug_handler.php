<?php
// create_Bug.php
require_once "bootstrap.php";

class BugHandler
{
    private $entityManager;
    private $Bug;
    private $product;
    private $bugRepo;

    public function __construct($entityManager)
    {
        $this->entityManager = $entityManager;
        $this->bugRepo =  $this->entityManager->getRepository('Bug');
        $this->bugRepo->init();
    }

    public function createBugs($theReporterId,$theDefaultEngineerId, $productIds) 
    {
        $this->bugRepo->createBugs($theReporterId, $theDefaultEngineerId, $productIds);
    }
    
    public function listBugs($bugId = null)
    {
        $bugs = [];    
       
        if (empty($bugId)) {
             $bugs = $this->bugRepo->getRecentBugs();
        } else {
             $bugs = $this->bugRepo->getRecentBugsById((int) $bugId);
        }
           /* $dql = "SELECT b, e, r FROM Bug b JOIN b.engineer e JOIN b.reporter r ORDER BY b.created DESC";

            $query = $this->entityManager->createQuery($dql);
            $query->setMaxResults(30);
            $bugs = $query->getResult();*/

        if(isset($bugs) &&  is_array($bugs)) {
            foreach ($bugs as $bug) {
                echo $bug->getDescription()." - ".$bug->getCreated()->format('d.m.Y')."\n";
                echo "    Reported by: ".$bug->getReporter()->getName()."\n";
                echo "    Assigned to: ".$bug->getEngineer()->getName()."\n";
                foreach ($bug->getProducts() as $product) {
                    echo "    Platform: ".$product->getName()."\n";
                }
                echo "\n";
            }
        } else {
            exit('No Bugs with provided id found !');
        }
    }

    public function updateBugs($id, $updateValue)
    {
         $this->bugRepo->updateBugs($id, $updateValue);
    }
}

$action = $argv[1];
$BugHandler = new BugHandler($entityManager);
switch($action) 
{
    case 'create':
        $BugHandler->createBugs($argv[2],$argv[3],$argv[4]);
    break;
    case 'update':
        $BugHandler->updateBugs($argv[2],$argv[3]);
    break;
    case 'list':
        $BugHandler->listBugs(isset($argv[2]) ? $argv[2] : null);
    break;
   
}
