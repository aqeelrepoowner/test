<?php
// create_User.php
require_once "bootstrap.php";

class UserHandler
{
    private $entityManager;
    private $User;
    public function __construct($entityManager)
    {
        $this->entityManager = $entityManager;
        $this->User = new User();
    }

    public function createUsers($newUserName) 
    {
        $this->User->setName($newUserName);
        $this->entityManager->persist($this->User);
        $this->entityManager->flush();

        echo "Created User with ID " . $this->User->getId() . "\n";
    }
    
    public function listUsers()
    {        
        $UserRepository = $this->entityManager->getRepository('User');
        $Users = $UserRepository->findAll();

        foreach ($Users as $User) {
            echo sprintf("-%s\n", $User->getName());
        }
    }

    public function updateUsers($id, $updateValue)
    {
        $User = $this->entityManager->find('User', $id);

        if ($User === null) {
            echo "User $id does not exist.\n";
            exit(1);
        }

        $User->setName($updateValue);

        $this->entityManager->flush();
    } 

}

$action = $argv[1];
$UserHandler = new UserHandler($entityManager);
switch($action) 
{
    case 'create':
        $UserHandler->createUsers($argv[2]);
    break;
    case 'update':
        $UserHandler->updateUsers($argv[2],$argv[3]);
    break;
    case 'list':
        $UserHandler->listUsers();
    break;
}
