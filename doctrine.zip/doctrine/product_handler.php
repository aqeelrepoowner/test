<?php
// create_product.php
require_once "bootstrap.php";

class ProductHandler
{
    private $entityManager;
    private $product;
    public function __construct($entityManager)
    {
        $this->entityManager = $entityManager;
        $this->product = new Product();
    }

    public function createProducts($newProductName, $categoryId) 
    {
        $this->product->setName($newProductName);
        $this->product->setCategory($categoryId);
        $this->entityManager->persist($this->product);
        $this->entityManager->flush();

        echo "Created Product with ID " . $this->product->getId() . "\n";
    }
    
    public function listProducts()
    {        
        $productRepository = $this->entityManager->getRepository('Product');
        $products = $productRepository->findAll();

        foreach ($products as $product) {
            echo sprintf("-%s\n", $product->getName());
        }
    }

    public function updateProducts($id, $updateValue)
    {
        $product = $this->entityManager->find('Product', $id);

        if ($product === null) {
            echo "Product $id does not exist.\n";
            exit(1);
        }

        $product->setName($updateValue);

        $this->entityManager->flush();
    } 

}

$action = $argv[1];
$productHandler = new ProductHandler($entityManager);
switch($action) 
{
    case 'create':
        $productHandler->createProducts($argv[2], $argv[3]);
    break;
    case 'update':
        $productHandler->updateProducts($argv[2],$argv[3]);
    break;
    case 'list':
        $productHandler->listProducts();
    break;
}
