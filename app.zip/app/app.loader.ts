// this css loaded separately as a standalone file to speed up the initial styles loading
require('./theme/initial.scss');
