import { Component, OnInit, Input } from '@angular/core';
import {NgClass, NgIf, NgFor, NgSwitch, NgSwitchCase, NgSwitchDefault} from '@angular/common';

@Component({
  selector: 'input-error',
  template: `<span *ngIf="showErrorFlag" class="help-block">
    {{errorMSG}}
               <ng-content></ng-content>
             </span>`
})
export class InputError {

  showErrorFlag:boolean = true;
  @Input() errorMSG = 'Hey input error';
  
  hideError():void {
    this.showErrorFlag = false;
  }

  showError():void {
    this.showErrorFlag = true;
  }

}