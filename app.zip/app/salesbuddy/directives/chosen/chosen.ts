/*
 * Define chosen directive based on jquery chosen
 * Using: <select sb-chosen [options]="listOfOptions" selectOptions="keyAndValueOfOption" (onSelect)="afterSelect($event)"></select>
 */
'use strict';
import {Directive, Input, Output, EventEmitter, ElementRef} from '@angular/core';
declare var $: any;
declare var _: any;
@Directive({
  selector: '[sb-chosen]'
})

export class SbChosen {
	@Input('options') options: Array<any>;
	@Input('selectOptions') selectOptions: Object;
	@Input('initValue') initValue: any;
	@Output('onSelect') onSelect: EventEmitter<any> = new EventEmitter();
	init: Boolean = false;
	constructor(private _elm: ElementRef) { }
	ngOnChanges(changes) {
		if (this.init && (changes['options'] || changes['initValue'])) {
			this.update();
		}
	}
	ngOnDestroy() {
		let elm = $(this._elm.nativeElement);
		$(elm).chosen('destroy');
	}
	ngAfterViewInit() {
		let elm = $(this._elm.nativeElement);
		$(elm).chosen().change(event => {
			this.onSelect.emit(event.target.value);
		});
		this.update();
		$(elm).next('.chosen-container').css({ width: '100%' });
		this.init = true;
	}
	update() {
		let options = this.buildOptions();
		let elm = $(this._elm.nativeElement);
		$(elm).html(options);
		$(elm).val(this.initValue).trigger('chosen:updated');
	}
	buildOptions() {
		let options = this.options || [];
		let key = this.selectOptions['key'];
		let value = this.selectOptions['value'];
		let output = '';
		_.each(options, op => {
			output += '<option value="' + op[key] + '"> ' + op[value] + ' </option>';
		});
		return output;
	}
}
