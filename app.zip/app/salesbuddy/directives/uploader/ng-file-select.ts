/*
 * File selector directive, customize based on https://github.com/jkuri/ng2-uploader
 * Using: <input type="file" ng-file-select [ng-file-options] />
 */
'use strict';
import {Directive, ElementRef, EventEmitter, Input, Output, HostListener} from '@angular/core';
import {Ng2Uploader} from './ng2-uploader';

declare var $: any;

@Directive({
  selector: '[ng-file-select]'
})

export class NgFileSelect {
	@Input('ng-file-options') options: any;
	@Output() onUpload: EventEmitter<any> = new EventEmitter();
  uploader: Ng2Uploader;
  constructor(public el: ElementRef) {
    this.uploader = new Ng2Uploader();
    setTimeout(() => {
      this.uploader.setOptions(this.options);
    });
    this.uploader._emitter.subscribe((data) => {
      this.onUpload.emit(data);
    });
  }
	reset() {
		$(this.el.nativeElement).val('');
	}
	@HostListener('change', ['$event'])
  onFiles(): void {
    let files = this.el.nativeElement.files;
    if (files.length) {
      this.uploader.addFilesToQueue(files);
    }
  }
}
