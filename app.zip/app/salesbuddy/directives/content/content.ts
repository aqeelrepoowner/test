/*
 * Content component
 * Upload/select content
 */
'use strict';
import {Component, ViewEncapsulation, ViewChild, NgZone, Input, Output, EventEmitter} from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import {MODAL_DIRECTIVES} from 'ng2-bs3-modal/ng2-bs3-modal';
import {SbChosen} from './../../directives/chosen/chosen';
import {NgFileSelect} from './../../directives/uploader/ng-file-select';
import {Admin} from './../../services/admin';
import {Config} from './../../config/config';

import {CustomValidators} from './../../helpers/validators';

declare var _: any;

@Component({
  selector: 'sb-content',
	moduleId: module.id,
	styleUrls: ['./content.scss'],
  	templateUrl: './content.html',
	//directives: [NgFileSelect, MODAL_DIRECTIVES, SbChosen],
  encapsulation: ViewEncapsulation.None
})

export class SbContent {
	@Input() allowExternal: any;
	@Input() contentType: any;
	@Input() initId: any;
	@ViewChild('modal') modal: any;
	@ViewChild(NgFileSelect) _file: NgFileSelect;
	@Output('onSetContent') onSetContent: EventEmitter<any> = new EventEmitter();
	contents: Array<any> = [];
	content: any;
	uploading: Boolean = false;
	showExternal: Boolean = false;
	uploadOptions: any;
	contentForm: any;
	contentModel: any = {};
	errors: Object = {};
	otherError: string;
	acceptType: string = '';
	selectedFile: string = '';
	selectOptions: Object = {
		key: 'id',
		value: 'name'
	};
	constructor(private _config: Config,
		private _fb: FormBuilder,
		private _admin: Admin,
		private _zone: NgZone) {
		this.uploadOptions = {
			authToken: localStorage.getItem(this._config.tokenName),
			url: this._config.apiUrl + 'api/admin/contents'
		};
		this.contentForm = this._fb.group({
			name: ['', Validators.required],
			targetUrl: ['', CustomValidators.isUrl]
		});
	}
	ngAfterViewInit() {
		this.modal.init();
		this._file.uploader.setOptions(this.uploadOptions);
		this._file.uploader._emitter.subscribe(event => this.handleUpload(event));
	}
	handleUpload(event) {
		this._zone.run(() => {
			if (event === '_queueChanged') {
				let file = this._file.uploader._queue[0];
				this.selectedFile = file.name;
			} else if (event.done) {
				if (event.status === 200) {
					let response = JSON.parse(event.response);
					this.content = response.data;
					this.setContent();
				}
				this.uploading = false;
			}
		});
	}
	upload() {
		if (!this.showExternal && this._file.uploader._queue.length && this.contentForm.controls.name.valid) {
			this.uploading = true;
			this._file.uploader.setOptions({ data: this.contentModel });
			let file = this._file.uploader._queue[0];
			this._file.uploader.uploadFile(file);
			this._file.uploader.clearQueue();
		} else if (this.showExternal && this.contentForm.controls.name.valid && this.contentForm.controls.targetUrl.valid) {
			this.uploading = true;
			this._admin.createContent(this.contentModel).subscribe(
				response => {
					let res = response.json();
					this.content = res.data;
					this.setContent();
					this.uploading = false;
				},
				err => {
					let error = err.json();
					this.errors = error.errors;
					if (this.errors.hasOwnProperty('msg')) {
						this.otherError = this.errors['msg'];
					}
					this.uploading = false;
				}
			);
		}
	}
	onSelectContent(value) {
		let contents = _.filter(this.contents, { id: parseInt(value) });
		this.content = contents[0];
	}
	continue() {
		if ((!this._file || !this._file.uploader._queue[0]) && !this.showExternal) {
			this.setContent();
		} else {
			this.upload();
		}
	}
	setContent() {
		let data = _.assign({}, this.content);
		this.onSetContent.emit(data);
		this.content = null;
	}
	getContents(params?) {
		let extParams = {};
		if (this.contentType) {
			extParams['type'] = (this.contentType === 'image' || this.contentType === 'photo') ? 'image' : this.contentType;
		}
		params = _.assign(params || {}, extParams);
		return new Promise((resolve, reject) => {
			this._admin.getContens(params).subscribe(
				response => {
					let res = response.json();
					this.contents = res.data.contents;
					this.onSelectContent(this.initId);
					resolve(true);
				},
				error => reject(error)
			);
		});
	}
	validUpload(): boolean {
		return this._file.uploader._queue.length > 0;
	}
	closeModal() {
		this.errors = {};
		this.otherError = '';
		this.resetForm();
		this.reset();
		if (this._file) this._file.reset();
		this.modal.dismiss();
	}
	openModal() {
		if (this.contentType) {
			let acceptType = '.png,.jpg,.jpeg';
			let allowExternal = true;
			switch (this.contentType) {
				case 'image':
					allowExternal = false;
					break;
				case 'pdf':
					acceptType = '.pdf';
					break;
				case 'video':
					acceptType = 'video/*';
					break;
				default:
					break;
			}
			this.acceptType = acceptType;
			this.allowExternal = allowExternal;
		}
		this.getContents().then(
			() => {
				this.modal.open('md');
			}
		);
	}
	checkForm() {
		let disabled = true;
		if (!this.showExternal) {
			if (this._file && this._file.uploader._queue[0] && this.contentForm.controls.name.valid) {
				disabled = false;
			}
			if ((!this._file || !this._file.uploader._queue[0]) && this.content) {
				disabled = false;
			}
		} else if (this.contentForm.controls.name.valid && this.contentForm.controls.targetUrl.valid) {
			disabled = false;
		}
		return disabled;
	}
	reset() {
		this.contentModel = {};
		this.content = null;
		this.showExternal = false;
		this.selectedFile = '';
	}
	resetForm() {
		for (let key in this.contentForm.controls) {
			this.contentForm.controls[key]._dirty = false;
			this.contentForm.controls[key]._pristine = true;
			this.contentForm.controls[key]._touched = false;
			this.contentForm.controls[key]._untouched = true;
		}
	}
}
