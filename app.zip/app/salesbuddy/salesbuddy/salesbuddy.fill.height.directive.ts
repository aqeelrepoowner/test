import { Directive, ElementRef, HostListener, Input, Renderer } from '@angular/core';
@Directive({
  selector: '[sbFillHeight]'
})
export class SalesBuddyFillHeightDirective {
  
  constructor(private el: ElementRef, private renderer: Renderer) { }
  
  ngAfterViewInit() {
    this.doResize();
  } 

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    
    this.doResize();

  }

  doResize() {

    var windowHeight = window.innerHeight;
      var clientRect = this.el.nativeElement.getBoundingClientRect();
      let elemHeight = windowHeight - clientRect.top - 78;
      this.renderer.setElementStyle(this.el.nativeElement, 'height', elemHeight+'px');
      //this.renderer.setElementStyle(this.el.nativeElement, 'background-color', 'red');
      this.renderer.setElementStyle(this.el.nativeElement, 'overflow-y', 'auto');

  }

}