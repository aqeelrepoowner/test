import {Component} from '@angular/core';

@Component({
  selector: 'salesbuddy',
  styles: [],
  template: `<router-outlet></router-outlet>`
})
export class SalesBuddyComponent {

  constructor() {
  }
}