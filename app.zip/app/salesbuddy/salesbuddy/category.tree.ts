/*
 * SalesBuddy Category tree component
 * Show tree list, drag/drop to sort list
 * Using: <sb-tree [env]="environment" [channel]="channelNameOfEvent"></sb-tree>
 */
'use strict';
import {Component, ViewEncapsulation, Input, ElementRef } from '@angular/core';

import {Helper} from './../helpers/helper';
import {Event} from './../helpers/event';

import {Admin} from './../services/admin';
import {Environment} from './../services/environment';
import {TreeView} from './tree';

declare var $: any;
declare var _: any;

@Component({
  selector: 'sb-tree',
	moduleId: module.id,
  templateUrl: './category.tree.html',
	styleUrls: ['./category.tree.scss'],
	//directives: [TreeView],
  encapsulation: ViewEncapsulation.None
})

export class CategoryTree {
	@Input('env') env: any;
	@Input('channel') channel: any;
	flatCategories: Array<any>;
	categories: Array<any>;
	id: Number = 0;
	elm: any;
	constructor(private _admin: Admin, private _env: Environment, private _elm: ElementRef) {
		this.elm = _elm.nativeElement;
	}
	getCategories() {
		this._env.getCategories(this.env['id']).subscribe(
			response => {
				var resp = response.json();
				this.flatCategories = resp.data;
				this.categories = Helper.buildHierarchy(this.flatCategories);
			},
			error => {
				console.log(error);
			}
		);
	}
	ngOnInit() {
		this.listener();
	}
	ngOnChanges(changes) {
		if (changes['env'] instanceof Object && changes['env'].currentValue.hasOwnProperty('id')) {
			if ($(this.elm).length && $(this.elm).find('.sortable').length) {
				$(this.elm).find('.sortable .item').remove();
			}
			this.getCategories();
		}
	}
	ngAfterViewInit() {
		let elm = this._elm.nativeElement;
		$(elm).find('.sortable').nestedSortable({
			listType: 'tree-view',
			handle: '.tHl',
			axis: 'y',
			items: '.item',
			toleranceElement: '> div',
			start: (event, ui) => {
				$(ui.placeholder).css({
					'background-color': '#d9d9d9',
					'visibility': 'visible',
					'border-radius': '3px'
				});
			},
			update: this.updatePostion.bind(this)
		}).disableSelection();
	}
	updatePostion() {
		let arr = this.toArray();
		let data = [];
		arr.forEach(a => {
			data.push({ id: parseInt(a.id), lft: a.left, rgt: a.right, parentId: a.parent_id || 0 });
		});
		this._admin.updateCategoriesPosition(data).subscribe(
			() => {
				for (var i in this.flatCategories) {
					let idx = _.findIndex(data, d => {
						return d.id === this.flatCategories[i].id;
					});
					if (idx !== -1) {
						this.flatCategories[i] = _.merge(this.flatCategories[i], data[idx]);
					}
				}
				this.flatCategories = _.sortBy(this.flatCategories, 'lft');
			},
			error => {
				console.log(error);
			}
		);
	}
	addNewCategory(parentId?) {
		let parent = parentId || 0;
		let body = {
			parentId: parent,
			environmentId: this.env.id
		};
		this._admin.createCategory(body).subscribe(
			response => {
				let resp = response.json();
				this.flatCategories.push(resp.data);
				this.categories = Helper.buildHierarchy(this.flatCategories);
				setTimeout(this.updatePostion.bind(this), 250);
				this.reSelect();
			},
			error => {
				console.log(error);
			}
		);
	}
	deleteCategory(id) {
		this._admin.deleteCategory(id).subscribe(
			(response) => {
				let resp = response.json();
				_.remove(this.flatCategories, (c) => {
					return resp.data.ids.indexOf(c.id) !== -1;
				});
				Event.get(this.channel).emit({ action: 'onDelete', data: resp.data.ids });
				this.categories = Helper.buildHierarchy(this.flatCategories);
				setTimeout(this.updatePostion.bind(this), 250);
				this.reSelect();
			},
			error => {
				console.log(error);
			}
		);
	}
	listener() {
		Event.get(this.channel).subscribe(event => {
			switch (event.action) {
				case 'show':
					this.id = event.data;
					break;
				case 'add':
					this.addNewCategory(event.data);
					break;
				case 'delete':
					let confirm = window.confirm('Are you sure to delete?');
					if (confirm) {
						this.deleteCategory(event.data);
					}
					break;
				case 'onUpdate':
					let idx = _.findIndex(this.flatCategories, c => {
						return c.id === event.data.id;
					});
					if (idx !== -1) {
						this.flatCategories[idx] = _.merge(this.flatCategories[idx], event.data);
						this.categories = Helper.buildHierarchy(this.flatCategories);
						this.reSelect();
					}
					break;
				default:
					break;
			}
		});
	}
	toArray() {
		return $(this.elm).find('.sortable').nestedSortable('toArray', { excludeRoot: true, startDepthCount: 0 });
	}
	reSelect() {
		setTimeout(() => {
			Event.get(this.channel).emit({ action: 'show', data: this.id });
		}, 250);
	}
}
