import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';

import { ReactiveFormsModule, FormsModule }   from '@angular/forms';

import { NgaModule } from '../../theme/nga.module';

import { DropdownModule, ModalModule } from 'ng2-bootstrap/ng2-bootstrap';

import { routing }       from './salesbuddy.routing';


import {SalesBuddyComponent} from './salesbuddy.component';

import {SalesBuddyCategoriesComponent} from './salesbuddy.categories.component';
import {SalesBuddyPresentationsComponent} from './salesbuddy.presentations.component';
import {SalesBuddyDesignComponent} from './salesbuddy.design.component';

import {SalesBuddyFillHeightDirective} from './salesbuddy.fill.height.directive';
import {DragulaModule} from 'ng2-dragula/ng2-dragula';


/*
import {CategoryTree} from './category.tree';
import {CategoryDetail} from './category.detail';
import {TreeView} from './tree';
*/



@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgaModule,
    DropdownModule,
    ModalModule,
    FormsModule,
    routing,
    DragulaModule
  ],
  declarations: [
    SalesBuddyComponent, SalesBuddyCategoriesComponent, SalesBuddyPresentationsComponent, SalesBuddyDesignComponent, SalesBuddyFillHeightDirective/*, 
    CategoryTree, CategoryDetail, TreeView*/
  ],
  providers: [
  ]
})

export default class SalesBuddyModule {}
