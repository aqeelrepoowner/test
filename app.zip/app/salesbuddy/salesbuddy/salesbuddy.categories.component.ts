/*
 * SalesBuddy Category component
 * Parent of category tree and category detail
 * Using: <sb-category [env]="environment"></sb-category>
 */
'use strict';
import {Component, ViewEncapsulation, Input } from '@angular/core';

//import { Routes, RouterModule }  from '@angular/router';

//import {CategoryTree} from './category.tree';
//import {CategoryDetail} from './category.detail';


import {Category} from './../crud/model/model.category';
import {Content} from './../crud/model/model.content';
import { EnvironmentSetting } from './../crud/model/model.environment.setting';

import {ModelProvider} from './../crud/model/model.provider';
import {DragulaService} from 'ng2-dragula/ng2-dragula';



@Component({
  selector: 'sb-category',
  styleUrls: ['./salesbuddy.category.scss', '../../../../node_modules/dragula/dist/dragula.css'],
  templateUrl: './salesbuddy.categories.html',
  encapsulation: ViewEncapsulation.None,
  viewProviders: [DragulaService]
})
export class SalesBuddyCategoriesComponent {
	@Input('env') env: any;
	categories : Category[];
  environmentSettings : EnvironmentSetting[];
  documents : any[];
	channel: String = 'sb_category';
  selected : Category = null;

	constructor(private dragulaService: DragulaService) {

    dragulaService.setOptions('category-bag', {
      removeOnSpill: false,

      accepts: function (el, target, source, sibling) {

        if(source.classList.contains('parent-item')){
          return target.classList == source.classList;
        }

        if(source.classList.contains('child-item')){
          return true;
        }

      }

    });

    dragulaService.drop.subscribe((value) => {
      console.log(value);
      console.log(this.categories);

    });
	 
 
  }

  ngOnInit() {
  
    this.environmentSettings = ModelProvider.getEnvironmentSettings();
    this.categories = ModelProvider.getRootCategories('0');
    if(this.categories.length>0) {
      this.selected = this.categories[0];
    }
  }

  getSubCategories(subcat : Category) : Category[] {
    let subcats : Category[] = [];
    subcats = ModelProvider.getSubCategories(subcat);
    return subcats;
  }

  getPhotos(cat:Category) : Content[] {
    return ModelProvider.getPhotosByCategory(cat);
  }

  getDocs(cat:Category) : Content[] {
    this.documents = ModelProvider.getDocumentsByCategory(cat);
    return this.documents;
  }

  getVideos(cat:Category) : Content[] {
    return ModelProvider.getVideosByCategory(cat);
  }

  onCategoryClicked(cat:Category) {
    this.selected = cat;
  }

  addSubCategory(cat:Category){
    alert('add: ' + cat.title);
  }

  removeCategory(cat : Category){
    alert('delete: ' + cat.title);
  }

  private onDrag(args) {
    let [e, el] = args;
    // do something
    console.log(args);
  }

}