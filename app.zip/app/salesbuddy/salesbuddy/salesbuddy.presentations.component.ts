import {Component} from '@angular/core';

@Component({
  selector: 'design',
  styles: [],
  template: `Hello Presentation`
})
export class SalesBuddyPresentationsComponent {

  constructor() {
  }
}