import {Component} from '@angular/core';

@Component({
  selector: 'design',
  styles: [],
  template: `Hello Design`
})
export class SalesBuddyDesignComponent {

  constructor() {
  }
}