/*
 * Build tree from Hierarchy Array
 * Using <tree-view [data]="hierarchyArray" [channel]="channelNameOfEvent"></tree-view>
 */
'use strict';
import {Component, Input, ViewEncapsulation} from '@angular/core';

import {Event} from './../helpers/event';

@Component({
	selector: 'tree-view',
	moduleId: module.id,
	templateUrl: './tree.html',
	encapsulation: ViewEncapsulation.None,
	//directives: [TreeView]
})
export class TreeView {
	@Input() data: Array<any>;
	@Input() channel: string;
	id: Number = 0;
	ngOnInit() {
		this.listener();
	}
	do(e, action, data) {
		e.preventDefault();
		if (action === 'show') {
			this.id = data;
		}
		Event.get(this.channel).emit({ action: action, data: data });
	}
	listener() {
		Event.get(this.channel).subscribe(event => {
			if (event.action === 'show') {
				this.id = event.data;
			}
		});
	}
}
