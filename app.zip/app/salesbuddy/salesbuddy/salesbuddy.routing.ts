import { Routes, RouterModule }  from '@angular/router';

import { SalesBuddyComponent } from './salesbuddy.component';
import {SalesBuddyCategoriesComponent} from './salesbuddy.categories.component';
import {SalesBuddyPresentationsComponent} from './salesbuddy.presentations.component';
import {SalesBuddyDesignComponent} from './salesbuddy.design.component';


// noinspection TypeScriptValidateTypes
const routes: Routes = [
  {
    path: '',
    component: SalesBuddyComponent,
    

    children: [
      {
	    path: 'categories',
	    component: SalesBuddyCategoriesComponent,
	    children: [
	    ]
	  },
	  {
	    path: 'presentations',
	    component: SalesBuddyPresentationsComponent,
	    children: [
	    ]
	  },
	  {
	    path: 'design',
	    component: SalesBuddyDesignComponent,
	    children: [
	    ]
	  },
    ]
  },
];

export const routing = RouterModule.forChild(routes);
