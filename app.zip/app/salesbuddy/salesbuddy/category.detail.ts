/*
 * Show/update category detail
 * Using: <sb-category-detail [channel]="channelNameOfEvent"></sb-category-detail>
 */
'use strict';
import {Component, ViewEncapsulation, Input, ViewChild} from '@angular/core';
import {NotificationsService} from 'angular2-notifications/components';
import {MODAL_DIRECTIVES} from 'ng2-bs3-modal/ng2-bs3-modal';
import {Event} from './../helpers/event';
import {Category} from './../services/category';
import {Admin} from './../services/admin';
import {NgFileSelect} from './../directives/uploader/ng-file-select';
import {SbContent} from './../directives/content/content';
import {ImagePreviewPipe} from './../pipes/image-preview';

declare var _: any;

@Component({
  selector: 'sb-category-detail',
	moduleId: module.id,
  templateUrl: './category.detail.html',
	styleUrls: ['./category.detail.scss'],
  	encapsulation: ViewEncapsulation.None,
	//TODO Billmark directives: [NgFileSelect, MODAL_DIRECTIVES, SbContent],
	//TODO Billmark pipes: [ImagePreviewPipe]
})

export class CategoryDetail {
	@Input() channel: any;
	@ViewChild(SbContent) _content: SbContent;
	uploading: Boolean = false;
	allowExternal: Boolean = false;
	showExternal: Boolean = false;
	model: any = {};
	originalModel: any = {};
	contentModel: any = {};
	content: any = {
		image: {},
		pdf: [],
		photo: [],
		video: []
	};
	contentTmp: Object;
	contentType: string = 'image';
	acceptType: string = '';
	categories: Array<any> = [];
	contents: Array<any> = [];
	presentations: Array<any> = [];
	selectOptions: Object = {
		key: 'id',
		value: 'name'
	};
	uploadOptions: Object;
	contentForm: any;
	errors: Object = {};
	otherError: string;
	constructor(private _category: Category, private _admin: Admin/*, private _ntf: NotificationsService*/) { } //TODO Billmark
	ngOnInit() {
		this.listener();
	}
	setContent(event) {
		let content = event;
		let key = this.contentType;
		if (this.content[key]) {
			if (key === 'image') {
				this.content[key] = _.assign({}, content);
				this.model.categoryImage = this.content[key].id;
				this._content.closeModal();
			} else {
				let body = {
					categoryId: this.model.id,
					contentId: content['id'],
					displayName: content['name'],
					description: content['description']
				};
				this._admin.createCategoryContent(body).subscribe(
					response => {
						let res = response.json();
						this.content[key].unshift(res.data);
						this._content.closeModal();
					},
					() => {
						this._content.closeModal();
					}
				);
			}
		} else {
			this._content.closeModal();
		}
	}
	openModal(e, contentType) {
		e.preventDefault();
		if (!this.hasModel()) {
			return false;
		}
		this.contentType = contentType;
		let _this = this;
		setTimeout(() => _this._content.openModal(), 250);
	}
	listener() {
		Event.get(this.channel).subscribe(event => {
			// switch for multiple events
			switch (event.action) {
				case 'show':
					if (event.data > 0) {
						this.getCategoryDetail(event.data);
					}
					break;
				case 'onDelete':
					if (event.data.indexOf(this.model.id) !== -1) {
						this.model = {};
					}
					break;
				default:
					break;
			}
		});
	}
	clearCategoryImage() {
		this.model.categoryImage = this.originalModel.categoryImage;
		this.content.image = {};
	}
	getCategoryDetail(id) {
		if (id === this.model.id) {
			return false;
		}
		this.clearCategoryImage();
		this.model.id = id;
		this.resetContent();
		this.getCategoryContents();
		this.getPresentations();
		this._category.show(id).subscribe(
			response => {
				let resp = response.json();
				this.model = _.assign({}, resp.data);
				this.originalModel = _.assign({}, resp.data);
			},
			() => this.model = {}
		);
	}
	getCategoryContents() {
		this.content.pdf = [];
		this.content.photo = [];
		this.content.video = [];
		this._category.getCategoryContents(this.model.id).subscribe(
			response => {
				let res = response.json();
				let key;
				_.each(res.data, (item) => {
					if (item.content && item.content.type) {
						if (/^image\//.test(item.content.type)) {
							key = 'photo';
						}
						if (/^video\//.test(item.content.type)) {
							key = 'video';
						}
						if (item.content.type === 'application/pdf') {
							key = 'pdf';
						}
						this.content[key].push(item);
					}
				});
			}
		);
	}
	deleteCategoryContent(e, id) {
		e.preventDefault();
		let conf = window.confirm('Are you sure want to delete ?');
		if (!conf) {
			return false;
		}
		this._admin.deleteCategoryContent(id).subscribe(
			() => {
				this.getCategoryContents();
			}
		);
	}
	getPresentations() {
		this._admin.getPresentations().subscribe(
			response => {
				let res = response.json();
				this.presentations = res.data;
			}
		);
	}
	update() {
		let body = _.pick(this.model, this._category.attributes);
		this._admin.updateCategory(this.model.id, body).subscribe(
			(response) => {
				let res = response.json();
				this.model = _.assign({}, res.data);
				this.originalModel = _.assign({}, res.data);
				//TODO Billmark this._ntf.success('Message', 'Update was successful.');
				Event.get(this.channel).emit({ action: 'onUpdate', data: _.pick(res.data, ['id', 'name']) });
			},
			error => console.log(error)
		);
	}
	hasModel() {
		return this.model.hasOwnProperty('id') || this.uploading;
	}
	cancel() {
		Event.get(this.channel).emit({ action: 'show', data: 0 });
		this.model = {};
		this.resetContent();
	}
	resetContent() {
		this.content.image = {};
		this.content.pdf = [];
		this.content.photo = [];
		this.content.video = [];
	}
}
