import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[error]'
})

export class AlertDirective {
    @Input('error') errorStr: string;

    displayErrors(err) 
    {
            
    }
}
