import { Component, OnInit, Input } from '@angular/core';

import { AlertService } from './services/alert.service';

@Component({
    moduleId: module.id,
    selector: 'errMessage',
    templateUrl: 'alert.component.html'
})

export class AlertComponent {
    @Input() errorMsg :string;
    @Input() successMsg ='successzzz';

    constructor(private alertService: AlertService) {
        //this.errorMsg = 'Error really occurred';
     }

    ngOnInit() {
        console.log('called alert service');
        let alerts:any;
       
    }

    ngOnChanges(changes:any):void {
        console.log(changes.inputErrors.currentValue);
        var errors:any = changes.inputErrors.currentValue;
        this.errorMsg = 'Error ';    
   }

    displayErrors(errHandler, errObj) {

        let fetchErrors = JSON.parse(errObj["_body"]);
        let messages = fetchErrors["errors"];
        let tempMessages = [];
        let i = 0;
        for (let eachObj in messages)
        {
          if (true === errHandler.hasOwnProperty(eachObj) && messages[eachObj].msg !== '') {
                errHandler.form.controls[eachObj].setErrors({ valid:false,message: messages[eachObj].msg });
                //this.errorMsg = {element:eachObj,msg:messages[eachObj].msg};
                tempMessages.push({element:eachObj,msg:messages[eachObj].msg});
                //this.error.push(messages[eachObj].msg);
                i++;
           } 
          
        }
        //this.error = tempMessages;
        this.errorMsg = 'Error sakfj';
        console.log(this.errorMsg);

    }
}