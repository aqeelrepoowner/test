import { Component, OnInit, Input, ContentChildren,QueryList,OnChanges  } from '@angular/core';
import { InputError } from './inputerror.component';

@Component({
  selector: 'extended-input',
  template: `<div class="form-group"
                  [ngClass]="{'has-error':isError}"> 
                        <label class="control-label">{{labelText}}
                            <ng-content select="input"></ng-content>
                        </label>
                         <ng-content select="input-error"></ng-content>
             </div>`,
             entryComponents : [InputError]
})
export class Extended implements OnChanges {
  @Input()
  labelText:string = 'Error ASSAF';
  @Input()
  isError:boolean = false;
   @ContentChildren(InputError)
  errors:QueryList<InputError>;
  @Input()
  inputErrors:any;

  ngOnChanges(changes:any):void {
   // var errors:any = changes.inputErrors.currentValue;
    //this.errorMessage = '';
  // console.log(errors); 
  
  }
}