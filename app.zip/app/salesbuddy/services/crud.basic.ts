/*
 * SalesBuddy Crud Basic Service Template
 */
'use strict';
import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Config} from './../config/config';

@Injectable()
export class CrudBasic {
	api: string;
	
	constructor(private _http: Http,private _config: Config) {
		this.api=this._config.apiUrl;
		this._http['_defaultOptions'].headers.append('Content-Type','application/json; charset=utf-8');
		console.log('Crud Basic Sevice Is Initialized');
	}
	
	setServiceUri(uri:string){
		this.api = this.api+uri;
		console.log('service is set for '+this.api);
	}

	get(page?) {
		//let api = page ? this.api + '?p=' + page : this.api;
		console.log('get Called with '+this.api);
		return this._http.get(this.api);
	}
	create(data) {
		return this._http.post(this.api, JSON.stringify(data));
	}
	update(data) {
		return this._http.put(this.api + '/' + data.id, JSON.stringify(data));
	}
	delete(id) {
		return this._http.delete(this.api + '/' + id);
	}
}
