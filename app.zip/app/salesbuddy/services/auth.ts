/*
 * SalesBuddy Auth Service
 */
 'use strict';
import {Injectable} from '@angular/core';
import {Config} from './../config/config';
import { Http, Response } from '@angular/http';
import {User} from './user';

@Injectable()
export class Auth {
	api: string;
	token: string = '';
	authUser: any;
	constructor(private _http: Http, private _user: User, private _config: Config) {
		this.api = this._config.apiUrl + 'auth/local';
		this._http['_defaultOptions'].headers.append('Content-Type','application/json; charset=utf-8');
		if (localStorage.getItem(this._config.tokenName)) {
			this.setToken(localStorage.getItem(this._config.tokenName));
		}
	}
	login(email: string, password: string) {
		return this._http.post(this.api, JSON.stringify({ email: email, password: password }));
	}
	setToken(token: string): boolean {
		if (!token || token === '') {
			return false;
		}
		localStorage.setItem(this._config.tokenName, token);
		this.token = token;
		if (!this._http['_defaultOptions'].headers.has('Authorization')) {
			this._http['_defaultOptions'].headers.append('Authorization', 'Bearer ' + this.token);
		} else {
			this._http['_defaultOptions'].headers.set('Authorization', 'Bearer ' + this.token);
		}
		return true;
	}
	getToken(): string {
		return this.token;
	}
	removeToken(): void {
		this.token = null;
		localStorage.removeItem(this._config.tokenName);
		this._http['_defaultOptions'].headers.delete('Authorization');
	}
	getAuthUserFromServer() {
		return new Promise((resolve, reject) => {
			this._user.get('').subscribe(
				user => {
					var data = user.json();
					this.setAuthUser(data);
					resolve(data);
				},
				err => {
					this.setAuthUser(null);
					this.removeToken();
					reject(err);
				}
			);
		});
	}
	getAuthUser(): any {
		return this.authUser;
	}
	setAuthUser(user: any) {
		this.authUser = user;
	}
	logout(): boolean {
		this.removeToken();
		return true;
	}
}
