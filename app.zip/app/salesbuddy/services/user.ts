/*
 * SalesBuddy User Service
 * Request User API
 */
'use strict';
import {Injectable} from '@angular/core';
import {Config} from './../config/config';
import { Http, Response } from '@angular/http';

@Injectable()
export class User {
	public SUPERADMIN_ROLE: string = 'superadmin';
	public ADMIN_ROLE: string = 'admin';
	public USER_ROLE: string = 'user';
	api: string;
	constructor(private _http: Http, private _config: Config) {
		this.api = this._config.apiUrl + 'api/users';
	}
	get(id: string) {
		if (!id) {
			id = 'me';
		}
		return this._http.get(this.api + '/' + id);
	}
	create(params: any) {
		return this._http.post(this.api, JSON.stringify(params));
	}
	isSuperAdmin(user): Boolean {
		return user.role === this.SUPERADMIN_ROLE;
	}
	isAdmin(user): Boolean {
		return user.role === this.ADMIN_ROLE;
	}
}
