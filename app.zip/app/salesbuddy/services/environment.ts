/*
 * SalesBuddy Environment Service
 * Request Environment API
 */
 'use strict';
import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Config} from './../config/config';

@Injectable()
export class Environment {
	api: any;
	constructor(private _http: Http, private _config: Config) {
		this.api = this._config.apiUrl + 'api/environments';
	}
	getThemes() {
		return this._http.get(this.api + '/themes');
	}
	getCategories(id) {
		return this._http.get(this.api + '/' + id + '/categories');
	}
	getPresentations(id) {
		return this._http.get(this.api + '/' + id + '/presentations');
	}
}
