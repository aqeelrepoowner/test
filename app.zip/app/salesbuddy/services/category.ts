/*
 * SalesBuddy Category Service
 * Request Category API
 */
 'use strict';
import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Config} from './../config/config';

@Injectable()
export class Category {
	api: string;
	attributes: Array<any> = [
		'categoryImage',
		'categoryUrl',
		'description',
		'homeImage',
		'name',
		'parentId',
		'environmentId',
		'themeCategoryId',
		'thumbImage'
		];
	constructor(private _http: Http, private _config: Config) {
		this.api = this._config.apiUrl + 'api/categories';
	}
	get(page?) {
		let api = page ? this.api + '?p=' + page : this.api;
		return this._http.get(api);
	}
	show(id) {
		return this._http.get(this.api + '/' + id);
	}
	getCategoryContents(id) {
		return this._http.get(this.api + '/' + id + '/contents');
	}
}
