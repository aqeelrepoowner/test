/*
 * SalesBuddy Account Service
 * Request Account API
 */
'use strict';
import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Config} from './../config/config';
import {CrudBasic} from './crud.basic';

@Injectable()
export class Account extends CrudBasic {
	
	// get(page?) {
	// 	let api = page ? this.api + '?p=' + page : this.api;
	// 	return this._http.get(api);
	// }
	// create(data) {
	// 	return this._http.post(this.api, JSON.stringify(data));
	// }
	// update(data) {
	// 	return this._http.put(this.api + '/' + data.id, JSON.stringify(data));
	// }
	// delete(id) {
	// 	return this._http.delete(this.api + '/' + id);
	// }
}
