/*
 * SalesBuddy Admin Service
 * Request Admin API
 */
'use strict';
import {Injectable} from '@angular/core';
import {Http} from '@angular/http';
import {Config} from './../config/config';
import {Helper} from './../helpers/helper';

@Injectable()
export class Admin {
	api: any;
	constructor(private _http: Http, private _config: Config) {
		this.api = this._config.apiUrl + 'api/admin';
	}
	setTheme(body) {
		return this._http.post(this.api + '/theme', JSON.stringify(body));
	}
	createCategory(body) {
		return this._http.post(this.api + '/categories', JSON.stringify(body));
	}
	updateCategory(id, body) {
		return this._http.put(this.api + '/categories/' + id, JSON.stringify(body));
	}
	deleteCategory(id) {
		return this._http.delete(this.api + '/categories/' + id);
	}
	updateCategoriesPosition(body) {
		return this._http.put(this.api + '/categories/position', JSON.stringify(body));
	}
	getEnvironments() {
		return this._http.get(this.api + '/environments');
	}
	getEnvironment(id) {
		return this._http.get(this.api + '/environments/' + id);
	}
	updateEnvironment(id, body) {
		return this._http.put(this.api + '/environments/' + id, JSON.stringify(body));
	}
	createContent(body) {
		return this._http.post(this.api + '/contents', JSON.stringify(body));
	}
	getContens(params?) {
		let url = this.api + '/contents';
		if (params && Object.keys(params).length) {
			url = url + '?' + Helper.serialize(params);
		}
		return this._http.get(url);
	}
	createCategoryContent(body) {
		return this._http.post(this.api + '/categories/contents', JSON.stringify(body));
	}
	deleteCategoryContent(id) {
		return this._http.delete(this.api + '/categories/contents/' + id);
	}
	createPresentation(body) {
		return this._http.post(this.api + '/presentations', JSON.stringify(body));
	}
	getPresentations() {
		return this._http.get(this.api + '/presentations');
	}
	getPresentationDetail(id) {
		return this._http.get(this.api + '/presentations/' + id);
	}
	getPresentationContent(id) {
		return this._http.get(this.api + '/presentations/' + id + '/contents');
	}
	createPresentationContent(body) {
		return this._http.post(this.api + '/presentations/contents', JSON.stringify(body));
	}
	updatePresentationContent(id, body) {
		return this._http.put(this.api + '/presentations/contents/' + id, JSON.stringify(body));
	}
	deletePresentationContent(id) {
		return this._http.delete(this.api + '/presentations/contents/' + id);
	}
	deletePresentation(id) {
		return this._http.delete(this.api + '/presentations/' + id);
	}
	updatePresentationContentPosition(body) {
		return this._http.put(this.api + '/presentations/contents/position', JSON.stringify(body));
	}
}
