import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';

@Injectable()
export class ProductService 
{
    getProductDetails(id:number):any
    {
         return {
            _id:1,name:'Product 1',description:'Product 1 Description',cost:300,price:350
        };
    }
}