import { Injectable } from '@angular/core';
import { Router, NavigationStart } from '@angular/router';
import {ProductService} from './product.service';

@Injectable()
export class CartService 
{
     private cartItems = {};    

     constructor(private _productService:ProductService)
     {

     }

     public getCartItems()
     {
         return this.cartItems;
     }
    
     public setCartItems(productId, qty)
     {
       let productDetails = this._productService.getProductDetails(productId);
       
       this.cartItems['products'] = productDetails;
       this.calculateCartTotal();
     }
     
     public calculateCartTotal()
     {
        let total:number;
        for (let each of this.cartItems['products']) {
            total += parseInt(each.qty) * parseInt(each.price);
        }
         this.cartItems['cartTotal'] = total;
     }

}