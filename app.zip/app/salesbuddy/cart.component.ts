import {Component, Input, ContentChild} from '@angular/core';
import { Observable } from 'rxjs/Observable';
import {CartService} from './services/cart.service';

@Component({
  selector: 'cart',
  template: `
  <div class="form-group">
     <div class="col-sm-9">
        <div *ngFor="let item of cartItems['products'];">{{item.name}}</div>
        <ng-content></ng-content>
     </div>
  </div>
  `,
  providers:[CartService]
})
export class CartComponent {

  @Input()
  private cartItems = {
  };
  
  constructor(private _cartService:CartService) {
      this.cartItems = this._cartService.getCartItems();
  }

  ngOnInit() {
    this.cartItems = this._cartService.getCartItems();
    this.addItems(1,1);
  }

  addItems(productId, qty) {
    this._cartService.setCartItems(productId,qty);
  }

}