/*
 * Define Image Preview filter
 * Using: {{ imageUrl |  imagePreview}}
 */
'use strict';
import {Pipe, PipeTransform} from '@angular/core';

import {Config} from '../config/config';

@Pipe({
  name: 'imagePreview'
})
// The work of the pipe is handled in the tranform method with our pipe's class
export class ImagePreviewPipe implements PipeTransform {
    constructor(private _config: Config) { }
    
    transform(value: any, args: any[]) {
        if (typeof value === 'string') {
            return /^http(s)?:\/\//.test(value) ? value : (this._config.apiUrl + value);
        }
        if (typeof value === 'object' && /^image/.test(value.type)) {
            return URL.createObjectURL(value);
        }
        return '';
    }
}
