import {Component} from '@angular/core';

@Component({
  selector: 'crud',
  styles: [],
  template: `<router-outlet></router-outlet>`
})
export class CrudComponent {

  constructor() {
  }
}
