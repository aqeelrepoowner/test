import {Injectable, Pipe, PipeTransform} from '@angular/core';
import { ModelDisplayProperty } from './model/model.interface';


@Pipe({
	name: 'summaryfilter',
	pure:false,
})

@Injectable()
export class SummaryFilterPipe implements PipeTransform {
	transform(items: ModelDisplayProperty[], args: any[]): any {

		return items.filter(function(item){
			return item.summary;
		});
	}
}

