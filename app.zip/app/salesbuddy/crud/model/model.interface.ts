

export interface IModelDisplay {

	getId() : string;
	getSingleName() : string;
	getPluralName() : string;
	getProperties() : ModelDisplayProperty[];
	update() : void;
	getDisplayProperty() : string;
}

export abstract class BaseModel implements IModelDisplay {

	protected id : string = '';
	protected  properties : ModelDisplayProperty[] = null;

	public getId() : string {
		return this.id;
	}

	abstract getSingleName() : string;
	abstract getPluralName() : string;
	abstract getProperties() : ModelDisplayProperty[];
	abstract update() : void;
	abstract getDisplayProperty() : string;
}

export enum ModelDisplayPropertyType {
	Input,
	TextArea,
	Select,
	Date,
	Phone,
	Email,
	Color,
	Address,
	RelatedTo
}

export class ModelDisplayProperty {
	public name : string;
	public type : ModelDisplayPropertyType = ModelDisplayPropertyType.Input;
	public value : any;  //TODO should this be any?
	public index : number = 0;
	public summary : boolean = false;
	public validators : any[] = [];
}

export enum RelatedModelType {
	One2One,
	One2Many,
	Many2One,
	Many2Many
}

export class RelatedModel {
	model : string = '';
	type : RelatedModelType = RelatedModelType.One2One;
	data : IModelDisplay[] = [];
	display : string = 'name';
	id : string = '';

	constructor(model:string, type:RelatedModelType, display:string, id:string = '') {
		this.model = model;
		this.type = type;
		this.display = display;
		this.id = id;
	}

	public setId(id:string) {
		this.id = id;
	}

	public getId() : string {
		return this.id;
	}

	public setValue(value:IModelDisplay) {
		this.setId(value.getId());
		this.data = [value];
	}


}

export enum ModelRecordStatus {
	Active = 0,
	Inactive = 1,
	Suspended = 2,
	Deleted = 3
}


