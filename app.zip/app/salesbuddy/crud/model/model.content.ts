
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType } from './model.interface';

import {ModelProvider, kCategoryName} from './model.provider';

import { Validators } from '@angular/forms';

import  { RegExpUtil } from '../util/app.util';

export enum ContentType {
	ContentTypeDoc,
	ContentTypePhoto,
	ContentTypeVideo,
	ContentTypePresentation
}


export class ContentAttribute {
		id:string = ''; 
		title:string = ''; 
		url:string = '';
		type : ContentType = ContentType.ContentTypeDoc;
};

export class Content extends BaseModel {



	public title : string = '';
	public url : string = '';
	public type : ContentType = ContentType.ContentTypeDoc;

	constructor(content:ContentAttribute = null) {
        super();
        if(content != null) {
	        this.id = content.id;
	        this.title = content.title;
	        this.url = content.url;
	        this.type = content.type;
	    }
    }

    public getSingleName() : string{
    	return 'Content';
    }

    public getPluralName() : string{
    	return 'Content';
    }

	public getProperties() : ModelDisplayProperty [] {

		if(this.properties == null) {
			this.properties = [
				{'name':'title', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'url', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index' :0, 'summary':true, 'validators':[]} 			]
		}

		this.properties[0].value = this.title;
		this.properties[1].value = this.url;

		return this.properties;
	}

	public update() {

	}


}

