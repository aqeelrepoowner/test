
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModelType, RelatedModel, ModelRecordStatus } from './model.interface';

import {ModelProvider, kAccountName} from './model.provider';

import { Validators } from '@angular/forms';

export class ProductsAndServicesAttribute {
		id:string = '';
		name:string = '';
		itemCategory:string = '';
		price:number=0;
		description:string='';
};

export class ProductsAndServices extends BaseModel {


	private name : string = '';
	private itemCategory : string = '';
	private price : number = 0;
	private description : string = '';


	constructor(attr:ProductsAndServicesAttribute = null) {
        super();
        if(attr != null) {
        	this.id = attr.id;
        	this.name = attr.name;
        	this.itemCategory = attr.itemCategory;
		    this.price = attr.price;
			this.description = attr.description;
    	}
    }

    public getSingleName() : string {
    	return 'Product';
    }

    public getPluralName() : string {
    	return 'Products';
    }

	public getProperties() : ModelDisplayProperty [] {


		if(this.properties == null) {
			this.properties = [
				{'name':'itemCategory', 'type' : ModelDisplayPropertyType.Select, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'name', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'description', 'type' : ModelDisplayPropertyType.TextArea, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
				{'name':'price', 'type' : ModelDisplayPropertyType.TextArea, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
			]
		}

		this.properties[0].value = this.itemCategory;
		this.properties[1].value = this.name;
		this.properties[2].value = this.description;
		this.properties[3].value = this.price;

		return this.properties;
	}


	public update() {

	}

	public getDisplayProperty():string{
		return this.name;
	}
}

