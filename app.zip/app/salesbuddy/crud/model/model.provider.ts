import { Injectable } from '@angular/core';

import { IModelDisplay, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType, ModelRecordStatus } from './model.interface';

//import { Account, Contact } from './';
import { Account,AccountAttribute } from './model.account';
import { Contact, ContactAttribute } from './model.contact';
import { Opportunity,OpportunityAttribute } from './model.opportunity';
import { ProductsAndServices,ProductsAndServicesAttribute } from './model.productsandservices';
import { Category } from './model.category';
import { Content, ContentType} from './model.content';
import { CategoryContentLink } from './model.category.content.link';
import { Environment } from './model.environment';
import { EnvironmentSetting } from './model.environment.setting';

export const kAccountName: string = 'account';
export const kContactName: string = 'contact';
export const kOpportunitytName: string = 'opportunity';
export const kCategoryName: string = 'category';
export const kContentName: string = 'content';
export const kCategoryContentName: string = 'categorycontent';
export const kEnvironmentName: string = 'environment';
export const kEnvironmentSettingName: string = 'environmentsetting';

export class SBNameValue {
  name:string = '';
  value:string = '';
}

@Injectable()
export class ModelProvider {

  static accounts : Account [] = [
    new Account({ id:'0', companyName:'CompanyName1', address:'Address1', city:'City1', state : 'State1', zip:'Zip1', contactId : '','contact':null}),
    new Account({ id:'1', companyName:'CompanyName2', address:'Address2', city:'City2', state : 'State2', zip:'Zip2', contactId : '','contact':null}),
    new Account({ id:'2', companyName:'CompanyName3', address:'Address3', city:'City3', state : 'State3', zip:'Zip3', contactId : '','contact':null}),
    new Account({ id:'3', companyName:'CompanyName4', address:'Address4', city:'City4', state : 'State4', zip:'Zip4', contactId : '','contact':null}),
  ];

  static contacts : Contact [] = [
    new Contact({ id:'0', firstName:'Contact1', lastName:'last', phone:'Phone1', email:'Email1', accountId : '1','account':null}),
    new Contact({ id:'1', firstName:'Contact2', lastName:'last', phone:'Phone2', email:'Email2', accountId : '1','account':null}),
    new Contact({ id:'2', firstName:'Contact3', lastName:'last', phone:'Phone3', email:'Email3', accountId : '3','account':null}),
    new Contact({ id:'3', firstName:'Contact4', lastName:'last', phone:'Phone4', email:'Email4', accountId : '3','account':null})
  ];

  static opportunities : Opportunity [] = [
    new Opportunity({ id:'0', name:'Opportunity1',  description:'Description1', status:ModelRecordStatus.Active, accountId : '1','account':null}),
    new Opportunity({ id:'1', name:'Opportunity2',  description:'Description2', status:ModelRecordStatus.Active, accountId : '1','account':null}),
    new Opportunity({ id:'2', name:'Opportunity3',  description:'Description3', status:ModelRecordStatus.Active, accountId : '3','account':null}),
    new Opportunity({ id:'3', name:'Opportunity4',  description:'Description4', status:ModelRecordStatus.Active, accountId : '3','account':null})
  ];

  static environmentSettings : EnvironmentSetting [] = [
    new EnvironmentSetting({id:'0', name:'Default', description:'Default Settings'}),
    new EnvironmentSetting({id:'1', name:'Test', description:'Test 1'})
  ];

  static environment : Environment [] = [
    new Environment({id:'0', name:'Staging', enviromentSettingId:'0'}),
    new Environment({id:'1', name:'Production', enviromentSettingId:'0'})
  ];

  static conent : Content [] = [
    new Content({id:'0', title:'Cont 1', url:'http://www.w3schools.com/html/html5.gif', type:ContentType.ContentTypePhoto}),
    new Content({id:'1', title:'Cont 2', url:'http://www.w3schools.com/html/pic_mountain.jpg', type:ContentType.ContentTypePhoto}),
    new Content({id:'2', title:'Cont 3', url:'http://www.w3schools.com/html/pic_graph.png', type:ContentType.ContentTypePhoto}),
    new Content({id:'3', title:'Cont 4', url:'http://www.w3schools.com/html/html5.gif', type:ContentType.ContentTypeDoc}),
    new Content({id:'4', title:'Cont 5', url:'http://www.w3schools.com/html/pic_mountain.jpg', type:ContentType.ContentTypeDoc}),
    new Content({id:'5', title:'Cont 6', url:'http://www.w3schools.com/html/pic_graph.png', type:ContentType.ContentTypeVideo})
  ];
 
  static categories : Category [] = [
    new Category({id:'0', title:'Cat 1', description:'Cat 1 Description', categoryId:null, categoryImageId:'0', categoryUrl:'http://www.yahoo.com', homeImageId:'0', environmentId:'0'}),
    new Category({id:'1', title:'Cat 2', description:'Cat 2 Description', categoryId:null, categoryImageId:'0', categoryUrl:'http://www.yahoo.com', homeImageId:'0', environmentId:'0'}),
    new Category({id:'2', title:'Cat 3', description:'Cat 3 Description', categoryId:null, categoryImageId:'0', categoryUrl:'http://www.yahoo.com', homeImageId:'0', environmentId:'0'}),
    new Category({id:'3', title:'Cat 1 Sub 1', description:'Cat 1 Sub 1 Description', categoryId:'0', categoryImageId:'0', categoryUrl:'http://www.yahoo.com', homeImageId:'0', environmentId:'0'}),
    new Category({id:'4', title:'Cat 1 Sub 2', description:'Cat 1 Sub 2 Description', categoryId:'0', categoryImageId:'0', categoryUrl:'http://www.yahoo.com', homeImageId:'0', environmentId:'0'}),
  ];

  static categoryContentLinks : CategoryContentLink [] = [
    new CategoryContentLink({ id:'0', categoryId:'0', contentId:'0'}),
    new CategoryContentLink({ id:'1', categoryId:'0', contentId:'1'}),
    new CategoryContentLink({ id:'2', categoryId:'0', contentId:'2'}),
    new CategoryContentLink({ id:'3', categoryId:'0', contentId:'3'}),
    new CategoryContentLink({ id:'4', categoryId:'0', contentId:'4'}),
    new CategoryContentLink({ id:'5', categoryId:'0', contentId:'5'})
  ];

  public static testDataMap : any  = {

    'account' : {'data':ModelProvider.accounts, 'create': function(){ return new Account() }},
    'contact' : {'data':ModelProvider.contacts, 'create': function(){ return new Contact() }},
    'opportunity' : {'data':ModelProvider.opportunities, 'create': function(){ return new Opportunity() }},
    'category' : {'data':ModelProvider.categories, 'create': function(){ return new Category() }},
    'content' : {'data':ModelProvider.categories, 'create': function(){ return new Content() }},
    'categorycontent' : {'data':ModelProvider.categoryContentLinks, 'create': function(){ return new CategoryContentLink() }},
    'environment' : {'data':ModelProvider.environment, 'create': function(){ return new Environment() }},
    'environmentsetting' : {'data':ModelProvider.environment, 'create': function(){ return new EnvironmentSetting() }},

  };

  public static findByProperties(type:string, properies:SBNameValue[]) : IModelDisplay {
    
    let returnItem : IModelDisplay = null;
    let data:IModelDisplay[] = ModelProvider.testDataMap[type].data;

    for(let i = 0; i < data.length; i++) {
      
      let item : IModelDisplay = data[i];

      let found : boolean = true;

      for(let nv = 0; nv < properies.length; nv++) {

        if(item[properies[nv].name] instanceof RelatedModel) {

           if( item[properies[nv].name].getId() != properies[nv].value) {
              found = false;
            }

        }
        else {
          
          if( item[properies[nv].name] != properies[nv].value) {
            found = false;
          }

        }
      }

      if(found) {
        returnItem = item;
        break;
      } 
    }

    return returnItem;
  }

   public static create(name:string):IModelDisplay {
    let model : IModelDisplay = null;
    if(typeof ModelProvider.testDataMap[name] != 'undefined') {
      model = ModelProvider.testDataMap[name].create();
    }
    return model;
  }

  public static getEnvironmentSettings() : EnvironmentSetting[] {
    return ModelProvider.environmentSettings;
  }

  //TODO Billmark - pass in envrionment
  public static getRootCategories(environmentSettingId:string) : Category[] {

    //let environmentSetting : IModelDisplay = this.findByProperties(kEnvironmentName, [ {name :'name', value:environmentName}]);

    let environment : IModelDisplay = ModelProvider.findByProperties(kEnvironmentName, [ {name :'name', value:'Staging'}, {name :'environmentSetting', value:environmentSettingId}]);

    let categories : Category[] = ModelProvider.categories.filter(function(cat){
      return (cat.category.getId() == null || cat.category.getId() == "") && cat.environment.getId() == environment.getId();
    });

    return categories;
  }

  /*
  public static getRootCategories(environmentSettingId:string) : Category[] {

    let categories : Category[] = ModelProvider.categories.filter(function(cat){
      return cat.category.getId() == null || cat.category.getId() == "";
    });

    return categories;
  }
  */

  public static getSubCategories(category:Category) : Category[] {

    let categories : Category[] = ModelProvider.categories.filter(function(cat){
      return cat.category.getId() == category.getId();
    });

    return categories;
  }

  public static getContentByCategory(category:Category, type:ContentType) : Content[] {

    let content : Content[] = [];



    let links = ModelProvider.categoryContentLinks.filter(function(link){
      return link.category.getId() == category.getId();
    });


    let contentMap : any = {};

    for(let i = 0; i < ModelProvider.conent.length; i++) {
      let content: Content = ModelProvider.conent[i];
      if(content.type == type) {
        contentMap[content.getId()] = content;
      }
    }


    for(let i = 0; i <  ModelProvider.categoryContentLinks.length; i++) {
      let link : CategoryContentLink = ModelProvider.categoryContentLinks[i];

      if(link.category.getId() == category.getId() && typeof contentMap[link.content.getId()] != 'undefined') {
         content.push( contentMap[link.content.getId()] );
      }
    }


    return content;

  }

  public static getDocumentsByCategory(category:Category) : Content[] {
    return ModelProvider.getContentByCategory(category, ContentType.ContentTypeDoc);
  }

  public static getPhotosByCategory(category:Category) : Content[] {
    return ModelProvider.getContentByCategory(category, ContentType.ContentTypePhoto);
  }

  public static getVideosByCategory(category:Category) : Content[] {
    return ModelProvider.getContentByCategory(category, ContentType.ContentTypeVideo);
  }

  public static findModelById(modelList:IModelDisplay[], id:string) : IModelDisplay {
    //let modelList : IModelDisplay [] =  objs;

    /*let model : IModelDisplay [] = modelList.filter(function(model){
       model.getId()==id;
    });

 if(model.length>0) {
      return model[0];
    } else {
      return null;
    }
    */
    for (let i = 0; i < modelList.length; i++) {
            if (modelList[i].getId() == id) {
                return modelList[i];
            }
        }

  }

  public static resolveRelationship(relationship : RelatedModel) : void {

    switch (relationship.type ) {

      case RelatedModelType.One2One:
      case RelatedModelType.Many2One:
      case RelatedModelType.One2Many:

        let modelList : IModelDisplay [] =  ModelProvider.testDataMap[relationship.model];

        relationship.data = [];
        for(let i = 0; i < modelList.length; i++) {

          let model : IModelDisplay = modelList[i];
          if(model.getId() == relationship.id) {
            relationship.data.push(model);
            //break;
          }
        }

        break;

      case RelatedModelType.Many2Many:

        break;

      default:
        // code...
        break;
    }

  }

  public static resolveModelRelationships(model : IModelDisplay) : void {

    let properties : ModelDisplayProperty[] = model.getProperties();
    for(let i = 0; i < properties.length; i++) {
      let prop : ModelDisplayProperty = properties[i];
      if(prop.type == ModelDisplayPropertyType.RelatedTo) {
         ModelProvider.resolveRelationship(prop.value);
      }
    }
  }

  public static getList(type:string) : IModelDisplay[] {

    let items : IModelDisplay[] = [];
    switch (type) {
      case kAccountName:
        items = ModelProvider.accounts;
        for(let i = 0; i < items.length; i++) {
          ModelProvider.resolveModelRelationships(items[i]);
        }
        break;

      case kContactName:
        items = ModelProvider.contacts;
        for(let i = 0; i < items.length; i++) {
          ModelProvider.resolveModelRelationships(items[i]);
        }
        break;

        case kOpportunitytName:
        items = ModelProvider.opportunities;
        for(let i = 0; i < items.length; i++) {
          ModelProvider.resolveModelRelationships(items[i]);
        }
        break;


      default:
        // code...
        break;
    }
    return items;
  }


  public static modelMap : any  = {

    'account' : {'create': function(obj){ return new Account(<AccountAttribute>obj) }},
    'contact' : {'create': function(obj){ return new Contact(<ContactAttribute>obj) }},
    'opportunity' : {'create': function(obj){ return new Opportunity(<OpportunityAttribute>obj) }},
    'product' : {'create': function(obj){ return new ProductsAndServices(<ProductsAndServicesAttribute>obj) }},
    'category' : {'data':ModelProvider.categories, 'create': function(obj){ return new Category() }},
    'content' : {'data':ModelProvider.categories, 'create': function(obj){ return new Content() }},
    'categorycontent' : {'data':ModelProvider.categoryContentLinks, 'create': function(obj){ return new CategoryContentLink() }},
    'environment' : {'data':ModelProvider.environment, 'create': function(obj){ return new Environment() }},
    'environmentsetting' : {'data':ModelProvider.environment, 'create': function(obj){ return new EnvironmentSetting() }},

  };

   /**
   * This method returns list of IModeDisplay by extracting it from the service response
   */
  public static getPopulatedModelObjects(type:string,obj):IModelDisplay[]{
    let modelObjs:IModelDisplay[]=[];
    if(Array.isArray(obj)){
      for(let i=0;i<obj.length;i++){
        modelObjs.push(this.createModel(type,obj[i]));
      }
    }else{
      modelObjs.push(this.createModel(type,obj));
    }
    return modelObjs;    
  }

  /**
   * This method returns the model object depending the type of model and relation passed.
   *The newly created model object properties are also populated here.
   */
  public static createModel(type:string,obj?:Object,isRelated:boolean=false):IModelDisplay{
    let model:IModelDisplay=null;
    if(ModelProvider.modelMap[type]!=undefined){
      model=ModelProvider.modelMap[type].create(obj);
    }
    return model;
  }


}
