
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType } from './model.interface';

import {ModelProvider, kCategoryName, kContentName, kCategoryContentName} from './model.provider';

import { Validators } from '@angular/forms';

import  { RegExpUtil } from '../util/app.util';

export class EnvironmentAttribute {
		id:string = ''; 
		name:string = ''; 
		description:string = '';
};

export class EnvironmentSetting extends BaseModel {



	public name : string = '';
	public description : string = '';
	

	constructor(attr : EnvironmentAttribute = null) {
        super();

        if(attr != null) {
	        this.id = attr.id;
	        this.name = attr.name;
	        this.description = attr.description;
	    }
    }

    public getSingleName() : string {
    	return 'Environment Setting';
    }

    public getPluralName() : string {
    	return 'Environment Settings';
    }

	public getProperties() : ModelDisplayProperty [] {

		if(this.properties == null) {
			this.properties = [
				{'name':'name', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'description', 'type' : ModelDisplayPropertyType.TextArea, 'value' : null, 'index' :0, 'summary':true, 'validators':[]}
 			]
		}

		this.properties[0].value = this.name;
		this.properties[1].value = this.description;

		return this.properties;
	}

	public update() {

	}


}

