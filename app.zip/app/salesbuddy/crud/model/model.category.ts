
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType } from './model.interface';

import {ModelProvider, kCategoryName, kContentName, kCategoryContentName, kEnvironmentName} from './model.provider';

import { Validators } from '@angular/forms';

import  { RegExpUtil } from '../util/app.util';

export class CategoryAttribute {
		id:string = ''; 
		title:string = ''; 
		description:string = '';
		categoryId:string = '';
		categoryImageId:string = '';
		categoryUrl:string = '';
		homeImageId:string = '';
		environmentId:string = '';
};

export class Category extends BaseModel {

	public title : string = '';
	public description : string = '';
	public category : RelatedModel = new RelatedModel(kCategoryName, RelatedModelType.Many2Many, 'title');
	
	public categoryImage : RelatedModel = new RelatedModel(kContentName, RelatedModelType.Many2One, 'title');
	public categoryUrl : string = '';
	public homeImage : RelatedModel = new RelatedModel(kContentName, RelatedModelType.Many2One, 'title');
	//public images : RelatedModel = new RelatedModel(kCategoryContentName, RelatedModelType.One2One, 'title');
	public environment : RelatedModel = new RelatedModel(kEnvironmentName, RelatedModelType.Many2One, 'name');

	constructor(cat:CategoryAttribute = null) {
        super();

        if(cat != null) {
	        this.id = cat.id;
	        this.title = cat.title;
	        this.description = cat.description;
	        this.category.setId(cat.categoryId);
	        this.categoryImage.setId(cat.categoryImageId);
	        this.categoryUrl = cat.categoryUrl;
	        this.homeImage.setId(cat.homeImageId);
	        this.environment.setId(cat.environmentId);
    	}

    }

    public getSingleName() : string {
    	return 'Category';
    }

    public getPluralName() : string {
    	return 'Categories';
    }

	public getProperties() : ModelDisplayProperty [] {

		if(this.properties == null) {
			this.properties = [
				{'name':'title', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'description', 'type' : ModelDisplayPropertyType.TextArea, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
       			{'name':kCategoryName, 'type' : ModelDisplayPropertyType.RelatedTo, 'value' : {}, 'index' :0, 'summary':false, 'validators':[]}
 			]
		}

		this.properties[0].value = this.title;
		this.properties[1].value = this.description;
    	this.properties[2].value = this.category;

		return this.properties;
	}

	public update() {

	}


}

