
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType } from './model.interface';

import {ModelProvider, kEnvironmentSettingName} from './model.provider';

import { Validators } from '@angular/forms';

import  { RegExpUtil } from '../util/app.util';

export class EnvironmentAttribute {
		id:string = ''; 
		name:string = ''; 
		enviromentSettingId:string = '';
};

export class Environment extends BaseModel {



	public name : string = '';
	public environmentSetting : RelatedModel = new RelatedModel(kEnvironmentSettingName, RelatedModelType.One2Many, 'name');
	

	constructor(env:EnvironmentAttribute = null) {
        super();
        if(env != null) {
	        this.id = env.id;
	        this.name = env.name;
	        this.environmentSetting.setId(env.enviromentSettingId);
	    }
    }

    public getSingleName() : string {
    	return 'Environment';
    }

    public getPluralName() : string {
    	return 'Environments';
    }

	public getProperties() : ModelDisplayProperty [] {

		if(this.properties == null) {
			this.properties = [
				{'name':'name', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'environmentSetting', 'type' : ModelDisplayPropertyType.RelatedTo, 'value' : null, 'index' :0, 'summary':true, 'validators':[]}
 			]
		}

		this.properties[0].value = this.name;
		this.properties[1].value = this.environmentSetting;

		return this.properties;
	}

	public update() {

	}


}

