
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType } from './model.interface';

import {ModelProvider, kContactName} from './model.provider';

import { Validators } from '@angular/forms';

import  { RegExpUtil } from '../util/app.util';

import { ContactAttribute, Contact } from './model.contact';

export class AccountAttribute {
		id:string = ''; 
		companyName:string = ''; 
		address:string = ''; 
		city:string = '';
		state : string = '';
		zip : string = '';
		contactId : string = '';
		contact : ContactAttribute = new ContactAttribute(); 
};

export class Account extends BaseModel {

	private companyName : string = '';
	private address : string = '';
	private city : string = '';
	private state : string = '';
	private zip : string = '';
  	private contact : RelatedModel = new RelatedModel(kContactName, RelatedModelType.Many2One, 'firstName');

	constructor(attr:AccountAttribute = null) {
        super();
        if(attr != null) {
	        this.id = attr.id;
	        this.companyName = attr.companyName;
	        this.address = attr.address;
	        this.city = attr.city;
	        this.state = attr.state;
	        this.zip= attr.zip;
	        //this.contact.setId(attr.contactId);
			this.contact.setValue(new Contact(<ContactAttribute>attr.contact));
	    }
    }

    public getSingleName() : string {
    	return 'Account';
    }

    public getPluralName() : string {
    	return 'Accounts';
    }

	public getProperties() : ModelDisplayProperty [] {

		if(this.properties == null) {
			this.properties = [
				{'name':'companyName', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'address', 'type' : ModelDisplayPropertyType.Address, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
				{'name':'city', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
				{'name':'state', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
				{'name':'zip', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
        {'name':kContactName, 'type' : ModelDisplayPropertyType.RelatedTo, 'value' : {}, 'index' :0, 'summary':false, 'validators':[]}
 			]
		}

		this.properties[0].value = this.companyName;
		this.properties[1].value = this.address;
		this.properties[2].value = this.city;
		this.properties[3].value = this.state;
		this.properties[4].value = this.zip;
    	this.properties[5].value = this.contact;

		return this.properties;
	}

	public update() {

	}

	public getDisplayProperty(){
		return this.companyName;
	}

}

