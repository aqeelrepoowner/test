
import {IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModelType, RelatedModel } from './model.interface';

import {ModelProvider, kAccountName} from './model.provider';

import { Validators } from '@angular/forms';

import  { RegExpUtil } from '../util/app.util';

import { Account,AccountAttribute } from './model.account';

export class ContactAttribute {
		id:string = ''; 
		firstName:string = ''; 
		lastName:string='';
		phone:string = ''; 
		email:string = '';
		accountId : string = '';
		account : AccountAttribute = new AccountAttribute();
};

export class Contact extends BaseModel {


	private firstName : string = '';
	private lastName : string = '';
	private phone : string = '';
	private email : string = '';
	private account : RelatedModel = new RelatedModel(kAccountName, RelatedModelType.Many2One, 'companyName');


	constructor(contact:ContactAttribute = null) {
		super();
		console.log(JSON.stringify(contact));
        if(contact != null) {
	        this.id = contact.id;
	        this.firstName = contact["firstName"];
			this.lastName = contact["lastName"];
	        this.phone = contact.phone;
	        this.email = contact.email;
	        //this.account.setId(contact.accountId);
			this.account.setValue(new Account(<AccountAttribute>contact.account));
	    }
    }

    public getSingleName() : string {
    	return 'Contact';
    }

    public getPluralName() : string {
    	return 'Contacts';
    }

	public getProperties() : ModelDisplayProperty [] {


		if(this.properties == null) {
			this.properties = [
				{'name':'firstName', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[Validators.minLength(4), Validators.required]},
				{'name':'lastName', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[Validators.minLength(4), Validators.required]},
				{'name':'phone', 'type' : ModelDisplayPropertyType.Phone, 'value' : null, 'index' :0, 'summary':true, 'validators':[Validators.minLength(10), Validators.required]},
				{'name':'email', 'type' : ModelDisplayPropertyType.Email, 'value' : null, 'index' :0, 'summary':true, 'validators':[Validators.required, Validators.pattern(RegExpUtil.Email)]},
				{'name':kAccountName, 'type' : ModelDisplayPropertyType.RelatedTo, 'value' : {}, 'index' :0, 'summary':true, 'validators':[]}
			]
		}

		this.properties[0].value = this.firstName;
		this.properties[1].value = this.lastName;
		this.properties[2].value = this.phone;
		this.properties[3].value = this.email;
		this.properties[4].value = this.account;

		return this.properties;
	}

	public update() {

	}

	public getDisplayProperty(){
		return this.firstName+' '+this.lastName;
	}

}

