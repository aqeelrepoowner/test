
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType } from './model.interface';

import {ModelProvider, kCategoryName, kContentName} from './model.provider';


import {Category} from './model.category';
import {Content} from './model.content';


import { Validators } from '@angular/forms';

import  { RegExpUtil } from '../util/app.util';


export class CategoryContentLinkAttribute {
		id:string = ''; 
		categoryId:string = ''; 
		contentId:string = '';
};

export class CategoryContentLink extends BaseModel {



	public category : RelatedModel = new RelatedModel(kContentName, RelatedModelType.Many2One, 'title');
	public content : RelatedModel = new RelatedModel(kContentName, RelatedModelType.Many2One, 'title');

	constructor(link:CategoryContentLinkAttribute = null) {
        super();

        if(link != null) {
	        this.id = link.id;
	        this.category.setId(link.categoryId);
	        this.content.setId(link.contentId);
	    }
    }

    public getSingleName() : string {
    	return 'Content';
    }

    public getPluralName() : string {
    	return 'Content';
    }

	public getProperties() : ModelDisplayProperty [] {

		if(this.properties == null) {
			this.properties = [
				{'name':'category', 'type' : ModelDisplayPropertyType.RelatedTo, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'content', 'type' : ModelDisplayPropertyType.RelatedTo, 'value' : null, 'index' :0, 'summary':true, 'validators':[]} 			]
		}

		this.properties[0].value = this.category;
		this.properties[1].value = this.content;

		return this.properties;
	}

	public update() {

	}


}

