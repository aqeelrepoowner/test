
import { IModelDisplay, BaseModel, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModelType, RelatedModel, ModelRecordStatus } from './model.interface';

import {ModelProvider, kAccountName} from './model.provider';

import { Validators } from '@angular/forms';

import { Account,AccountAttribute } from './model.account';

export class OpportunityAttribute {
		id:string = ''; 
		name:string = ''; 
		description:string = ''; 
		//opportunityStatus:string = '';
		status : ModelRecordStatus = ModelRecordStatus.Active;
		accountId : string = '';
		account : AccountAttribute = new AccountAttribute();
};

export class Opportunity extends BaseModel {


	private name : string = '';
	private description : string = '';
	private opportunityStatus : string = '';
	private status : ModelRecordStatus = ModelRecordStatus.Active;
	private account : RelatedModel = new RelatedModel(kAccountName, RelatedModelType.Many2One, 'companyName');


	constructor(attr:OpportunityAttribute = null) {
        super();

        if(attr != null) {
        	this.id = attr.id;
        	this.name = attr.name;
        	this.description = attr.description;
		    this.status = attr.status;
    		//this.account.setId(attr.accountId);
			this.account.setValue(new Account(<AccountAttribute>attr.account));
    	}
    }

    public getSingleName() : string {
    	return 'Opportunity';
    }

    public getPluralName() : string {
    	return 'Opportunities';
    }

	public getProperties() : ModelDisplayProperty [] {


		if(this.properties == null) {
			this.properties = [
				{'name':'name', 'type' : ModelDisplayPropertyType.Input, 'value' : null, 'index':0, 'summary':true, 'validators':[]},
				{'name':'description', 'type' : ModelDisplayPropertyType.TextArea, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
				{'name':'status', 'type' : ModelDisplayPropertyType.Select, 'value' : null, 'index' :0, 'summary':true, 'validators':[]},
				{'name':kAccountName, 'type' : ModelDisplayPropertyType.RelatedTo, 'value' : {}, 'index' :0, 'summary':true, 'validators':[]}
			]
		}

		this.properties[0].value = this.name;
		this.properties[1].value = this.description;
		this.properties[2].value = this.status;
		this.properties[3].value = this.account;

		return this.properties;
	}


	public update() {

	}

	public getDisplayProperty(){
		return this.name;
	}

}

