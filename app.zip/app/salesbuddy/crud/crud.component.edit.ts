
import { Component,ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { FormControl, FormGroup, Validators } from '@angular/forms';


import { IModelDisplay, ModelDisplayProperty, ModelDisplayPropertyType , RelatedModel, RelatedModelType} from './model/model.interface';
import { ModelProvider } from './model/model.provider';
import { Crud } from '../services/crud';
import { Config } from '../config/config';

import {SummaryFilterPipe} from './crud.summary.pipe';


@Component({
    moduleId: module.id,
    selector: 'crud',
    templateUrl: 'crud.component.edit.html',
    styleUrls: ['crud.component.css'],
    providers: [Crud, Config]
})
export class CrudEditComponent {

    object : IModelDisplay = null;
    properties : ModelDisplayProperty[];

    complexForm: FormGroup;

    constructor(public route: ActivatedRoute,private crudService:Crud) {



    }


    public isInput(prop:ModelDisplayProperty) : boolean {
      return prop.type == ModelDisplayPropertyType.Input;
    }

    public isTextArea(prop:ModelDisplayProperty) : boolean {
      return prop.type == ModelDisplayPropertyType.TextArea;
    }

    public isPhone(prop:ModelDisplayProperty) : boolean {
      return prop.type == ModelDisplayPropertyType.Phone;
    }

    public isEmail(prop:ModelDisplayProperty) : boolean {
      return prop.type == ModelDisplayPropertyType.Email;
    }

    onSubmit():void{
      console.log('Reactive Form Data: ')
      console.log(this.complexForm.value);
    }

    ngOnInit() {


      this.route
      .data
      .subscribe((data: any) => {

        // your resolved data from route
        let id = this.route.snapshot.params['id'];
        this.object=ModelProvider.createModel(data.type);
        this.crudService.setServiceUri(data.type);
        this.crudService.get().subscribe(
          res=>{
            let response = res.json();
            console.log(JSON.stringify(response));
            
            let modelPluralName = this.object.getPluralName().toLowerCase();
            let objs:IModelDisplay[]= ModelProvider.getPopulatedModelObjects(data.type, response.data[modelPluralName]);
            console.log('--- > '+JSON.stringify(objs));
            this.object=ModelProvider.findModelById(objs,id);
            console.log(JSON.stringify(this.object));
            if (this.object != null) {
              this.properties = this.object.getProperties();
            } else {
              console.log(null);
            }
            for (let i = 0; i < this.properties.length; i++) {

              let prop = this.properties[i];

              //TODO Billmark - need to add better validation
              if (prop.type != ModelDisplayPropertyType.RelatedTo) {
                group[prop.name] = new FormControl('', Validators.compose(prop.validators));
              }

            }
          },
          err=>console.log('Error in getting models from the service....')
        );
        let group: any = {};
        this.complexForm = new FormGroup(group);

      });

    }

public getDisplay(prop:ModelDisplayProperty) : string {

    if(prop.type == ModelDisplayPropertyType.RelatedTo) {

      let relatedModel : RelatedModel = prop.value;
      let data : IModelDisplay[] = relatedModel.data;

      if(data != null && typeof data != 'undefine' && relatedModel.data.length > 0) {
        return relatedModel.data[0][relatedModel.display];
      } else {
        return 'is undefined';
      }

    } else {
      return prop.value;
    }

  }

}
