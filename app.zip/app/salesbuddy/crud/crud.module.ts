import { NgModule }      from '@angular/core';
import { CommonModule }  from '@angular/common';

import { ReactiveFormsModule }   from '@angular/forms';

import { NgaModule } from '../../theme/nga.module';

import { Ng2SmartTableModule } from 'ng2-smart-table';
import { DropdownModule, ModalModule } from 'ng2-bootstrap/ng2-bootstrap';

import { routing }       from './crud.routing';


import {CrudComponent} from './crud.component';
import {CrudListComponent} from './crud.component.list';


import {SummaryFilterPipe} from './crud.summary.pipe';



@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgaModule,
    Ng2SmartTableModule,
    DropdownModule,
    ModalModule,
    routing
  ],
  declarations: [
    CrudListComponent, SummaryFilterPipe, CrudComponent
  ],
  providers: [
  ]
})

/*
import { Tables } from '../tables/tables.component';
import { BasicTables } from '../tables/components/basicTables/basicTables.component';
import { SmartTables } from '../tables/components/smartTables/smartTables.component';
import { BasicTablesService } from '../tables/components/basicTables/basicTables.service';
import { ResponsiveTable } from '../tables/components/basicTables/components/responsiveTable';
import { StripedTable } from '../tables/components/basicTables/components/stripedTable';
import { BorderedTable } from '../tables/components/basicTables/components/borderedTable';
import { HoverTable } from '../tables/components/basicTables/components/hoverTable';
import { CondensedTable } from '../tables/components/basicTables/components/condensedTable';
import { ContextualTable } from '../tables/components/basicTables/components/contextualTable';
import { SmartTablesService } from '../tables/components/smartTables/smartTables.service';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    NgaModule,
    Ng2SmartTableModule,
    routing
  ],
  declarations: [
    Tables,
    BasicTables,
    SmartTables,
    HoverTable,
    BorderedTable,
    CondensedTable,
    StripedTable,
    ContextualTable,
    ResponsiveTable
  ],
  providers: [
    BasicTablesService,
    SmartTablesService
  ]
})
*/
export default class CrudModule {}
