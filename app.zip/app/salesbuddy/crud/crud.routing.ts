import { Routes, RouterModule } from '@angular/router';

import { CrudComponent } from './crud.component';
import { CrudListComponent } from './crud.component.list';

// noinspection TypeScriptValidateTypes
const routes: Routes = [
	{
		path: '',
		component: CrudComponent,
		children: [
			{
				path: 'contacts',
				component: CrudListComponent,
				data: {
					type: 'contact'
				},
				children: [
				]
			},
			{
				path: 'accounts',
				component: CrudListComponent,
				data: {
					type: 'account'
				},
				children: [
				]
			},
			{
				path: 'opportunities',
				component: CrudListComponent,
				data: {
					type: 'opportunity'
				},
				children: [
				]
			},
			{
				path: 'productsandservices',
				component: CrudListComponent,
				data: {
					type: 'product'
				},
				children: [
				]
			},
		]
	},
];

export const routing = RouterModule.forChild(routes);
