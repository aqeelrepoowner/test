
import { Component, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

import { FormControl, FormGroup, Validators } from '@angular/forms';

import { IModelDisplay, ModelDisplayProperty, ModelDisplayPropertyType, RelatedModel, RelatedModelType } from './model/model.interface';
import { ModelProvider } from './model/model.provider';
import { SummaryFilterPipe } from './crud.summary.pipe';
import { Crud } from '../services/crud';
import { Config } from '../config/config';

import { LocalDataSource } from 'ng2-smart-table';
import { ModalDirective } from 'ng2-bootstrap';


@Component({
	moduleId: module.id,
	selector: 'crud',
	encapsulation: ViewEncapsulation.None,
	styles: [require('./crud.component.scss')],
	template: require('./crud.component.listview.html'),
	providers: [Crud, Config]
})
export class CrudListComponent {
	@ViewChild('childModal') childModal: ModalDirective;

	showChildModal(): void {
		this.childModal.show();
	}

	hideChildModal(): void {
		this.childModal.hide();
	}


	public isInput(prop: ModelDisplayProperty): boolean {
		return prop.type == ModelDisplayPropertyType.Input;
	}

	public isTextArea(prop: ModelDisplayProperty): boolean {
		return prop.type == ModelDisplayPropertyType.TextArea;
	}

	public isPhone(prop: ModelDisplayProperty): boolean {
		return prop.type == ModelDisplayPropertyType.Phone;
	}

	public isEmail(prop: ModelDisplayProperty): boolean {
		return prop.type == ModelDisplayPropertyType.Email;
	}

	public isRelatedTo(prop: ModelDisplayProperty): boolean {
		return prop.type == ModelDisplayPropertyType.RelatedTo;
	}

	newForm: FormGroup;


	query: string = '';

	settings = {
		add: {
			addButtonContent: '<i class="ion-ios-plus-outline"></i>',
			createButtonContent: '<i class="ion-checkmark"></i>',
			cancelButtonContent: '<i class="ion-close"></i>',
		},
		edit: {
			editButtonContent: '<i class="ion-edit"></i>',
			saveButtonContent: '<i class="ion-checkmark"></i>',
			cancelButtonContent: '<i class="ion-close"></i>',
		},
		delete: {
			deleteButtonContent: '<i class="ion-trash-a"></i>',
			confirmDelete: true
		},
		columns: {}
	};


	source: LocalDataSource = new LocalDataSource();

	object: IModelDisplay = null;
	properties: ModelDisplayProperty[];
	summary: ModelDisplayProperty[];
	objects: IModelDisplay[] = [];


	onDeleteConfirm(event): void {

		if (window.confirm('Are you sure you want to delete?')) {
			event.confirm.resolve();
		} else {
			event.confirm.reject();
		}
	}

	constructor(public route: ActivatedRoute, private crudService: Crud) {

	}

	ngOnInit() {


		this.route
			.data
			.subscribe((data: any) => {
				// your resolved data from route
				this.object = ModelProvider.createModel(data.type);
				this.crudService.setServiceUri(String(data.type));

				this.properties = this.object.getProperties();
				//this.objects = ModelProvider.getList(data.type);
				this.crudService.get().subscribe(
					res => {
						let response = res.json();
						this.objects = ModelProvider.getPopulatedModelObjects(data.type, response.data[this.object.getPluralName().toLowerCase()]);
						this.source.load(this.objects);
					},
					err => console.error("Get Error Obtained " + err)
				);


				for (let i = 0; i < this.properties.length; i++) {
					let prop = this.properties[i];
					this.settings.columns[prop.name] = { 'title': prop.name, 'type': 'string' };  //TODO Billmark the type should be dynamically set
				}

				this.source.load(this.objects);


				let group: any = {};

				for (let i = 0; i < this.properties.length; i++) {

					let prop = this.properties[i];

					//TODO Billmark - need to add better validation
					if (prop.type != ModelDisplayPropertyType.RelatedTo) {
						group[prop.name] = new FormControl('', Validators.compose(prop.validators));
					} else {
						group[prop.name + 'Id'] = new FormControl('');
					}

				}

				this.newForm = new FormGroup(group);


			});

	}

	public getDisplay(prop: ModelDisplayProperty, obj?: Object): string {

		if (prop.type == ModelDisplayPropertyType.RelatedTo) {

			let relatedModel: RelatedModel = prop.value;
			let data: IModelDisplay[] = relatedModel.data;
			console.log(JSON.stringify(obj));
			if (obj == undefined && data != null && typeof data != 'undefine' && relatedModel.data.length > 0) {
				return relatedModel.data[0][relatedModel.display];
			} else
				if (obj != undefined) {
					console.log('Iam rtrung ' + obj[prop.value.display]);
					return obj[prop.value.display];
				} else {
					return 'is undefined';
				}

		} else {
			return prop.value;
		}

	}
	public relatedModels: Object = {};
	public getRelatedObjectList(name: string) {
		let model: IModelDisplay = ModelProvider.createModel(name);
		this.crudService.setServiceUri(name);
		this.crudService.get().subscribe(
			res => {
				let response = res.json();
				console.log(JSON.stringify(response));
				let modelPluralName = model.getPluralName().toLowerCase();
				this.relatedModels[name] = ModelProvider.getPopulatedModelObjects(name, response.data[modelPluralName]);
				console.log(name + '=======' + JSON.stringify(this.relatedModels));
				console.log(JSON.stringify(this.relatedModels));
			},
			err => console.error("Error Retrieving related Models from service...")
		);
		this.crudService.setServiceUri(this.object.getSingleName().toLowerCase());
	}

	public currentAction: string = null;
	public selectedModel: IModelDisplay = null;
	public openActionModal(action: string, obj?: IModelDisplay) {
		//this.crudService.setServiceUri(obj.getPluralName().toLowerCase());
		this.currentAction = action;
		switch (this.currentAction) {
			case 'create':
				this.initModal();
				break;
			case 'delete':
				this.selectedModel=obj;
				break;
			case 'edit':
				this.initModal();
				this.selectedModel = obj;
				break;
		}
	}
	private initModal(): void {
		let props = this.object.getProperties();
		for (let i = 0; i < props.length; i++) {
			if (props[i].type == ModelDisplayPropertyType.RelatedTo) {
				this.relatedModels[props[i].name] = this.getRelatedObjectList(props[i].name);
			}
		}
		let group: any = {};

		for (let i = 0; i < this.properties.length; i++) {

			let prop = this.properties[i];
			//TODO Billmark - need to add better validation
			if (prop.type != ModelDisplayPropertyType.RelatedTo) {
				group[prop.name] = new FormControl('', Validators.compose(prop.validators));
			} else {
				group[prop.name + 'Id'] = new FormControl('');
			}

		}

		this.newForm = new FormGroup(group);
	}

	public onSubmit(values: Object) {
		switch (this.currentAction) {
			case 'create':
				this.crudService.create(values).subscribe(
					res => {
						let response = res.json();
						alert(Boolean(response.success) ? 'Saved..' : 'Failed');
						this.updateView();
					},
					err => console.error('Error in saving changes...')
				);
				break;
			case 'edit':
				//TODO Cybage Identify better approach
				let prop = this.selectedModel.getProperties();
				for (let i = 0; i < prop.length; i++) {
					if (values[prop[i].name] != undefined && values[prop[i].name].length == 0) {
						values[prop[i].name] = prop[i].value;
					}
				}
				values["id"] = this.selectedModel.getId();
				this.crudService.update(values).subscribe(
					res => {
						let response = res.json();
						alert(Boolean(response.success) ? 'Updated..' : 'Failed');
						this.updateView();
					},
					err => console.log('Error While Updating data...')
				);
				break;
			case 'delete':
				this.crudService.delete(this.selectedModel.getId()).subscribe(
					res => {
						let response = res.json();
						alert('Delete ' + Boolean(response.success) ? 'Successful' : 'Failed');
						this.updateView();
					},
					err => console.log('Error While Deleting....')
				);
				break;
			default:
				break;
		}
		this.selectedModel = null;
		this.currentAction = null;
	}

	public updateView() {
		this.crudService.get().subscribe(
			res => {
				let response = res.json();
				this.objects = ModelProvider.getPopulatedModelObjects(this.object.getSingleName().toLowerCase(), response.data[this.object.getPluralName().toLowerCase()]);
				this.source.load(this.objects);
			},
			err => console.error("Get Error Obtained " + err)
		);
	}
}
