import {Component, Input, ContentChild} from '@angular/core';
import {AlertService} from './services/alert.service';
import { Observable } from 'rxjs/Observable';

export interface AlertMessage {
  type: string;
  message:string;
}

@Component({
  selector: 'errMessage',
  template: `
    <div *ngIf="message" class="form-group">
      <label class="col-sm-3 control-label">{{label}}</label>
      <div class="col-sm-9">
     <div *ngIf="message" [ngClass]="{ 'alert': message, 'alert-success': message.type === 'success', 'alert-danger': message.type === 'error' }">{{message.text}}</div>
        <ng-content></ng-content>
      </div>
    </div>
  `
})
export class AlertComponent {
  @Input()
  private label:string;
  message: any;
  
  constructor(private _alertService : AlertService) {
  }

  ngOnInit() {
    this._alertService.getMessage().subscribe(message => { this.message = message; });
  }

}