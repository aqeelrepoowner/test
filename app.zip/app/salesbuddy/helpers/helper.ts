
declare var _:any;

export class Helper {
	static serialize(obj: Object): string {
		let str = [];
		for (var p in obj)
			if (obj.hasOwnProperty(p)) {
				str.push(encodeURIComponent(p) + '=' + encodeURIComponent(obj[p]));
			}
		return str.join('&');
	}
	static buildHierarchy(arry) {

    let roots = [], children = {};

    // find the top level nodes and hash the children based on parent
    for (let i = 0, len = arry.length; i < len; ++i) {
			let item = _.assign({}, arry[i]),
				p = item.parentId,
				target = !p ? roots : (children[p] || (children[p] = []));

			target.push(item);
    }

    // function to recursively build the tree
    let findChildren = (parent) => {
			if (children[parent.id]) {
				parent.children = children[parent.id];
				for (let i = 0; i < parent.children.length; ++i) {
					findChildren(parent.children[i]);
				}
			}
    };

    // enumerate through to handle the case where there are multiple roots
    for (let i = 0; i < roots.length; ++i) {
			findChildren(roots[i]);
    }

    return roots;
	}

}
