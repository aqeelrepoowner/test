/*
 * Event class, use to emit/listener event of a channel
 */
import {EventEmitter} from '@angular/core';

export class Event {
  private static _emitters: { [channel: string]: EventEmitter<any> } = {};
  static get(channel: string): EventEmitter<any> {
    if (!this._emitters[channel])
      this._emitters[channel] = new EventEmitter();
    return this._emitters[channel];
  }
}
