/*
 * Define custom validators, using as an angula2 validator
 */
export class CustomValidators {
	static isEmail(control) {
		let emailRegex: RegExp = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
		return emailRegex.test(control.value) ? null : { invalidEmail: true };
	}
	static confirm(field) {
		return (control) => {
			if (!control._parent) {
				return null;
			}
			return control.value === control._parent.controls[field].value ? null : { confirm: true };
		};
	}
	static compare(field1, field2) {
		return (controlGroup) => {
			return controlGroup.controls[field1].value === controlGroup.controls[field2].value ? null : { compare: true };
		};
	}
	static isPhoneNumber(control) {
		let phoneRegex: RegExp = /^\+?[0-9]{8,}$/;
		return phoneRegex.test(control.value) ? null : { invalidPhoneNumber: true };
	}
	static isId(control) {
		let idRegex: RegExp = /^[1-9][0-9]*$/;
		return idRegex.test(control.value) ? null : { invalidId: true };
	}
	static isNumber(control) {
		let numberRegex: RegExp = /^[0-9]{1,}$/;
		return numberRegex.test(control.value) ? null : { invalidNumber: true };
	}
	static isPrice(control) {
		return !isNaN(control.value) && parseFloat(control.value) >= 0 ? null : { invalidPrice: true };
	}
	static isUrl(control) {
		let urlRegex: RegExp = /^http(s)?:\/\/.*\.[a-z]/;
		return urlRegex.test(control.value) ? null : { invalidUrl: true };
	}
}
