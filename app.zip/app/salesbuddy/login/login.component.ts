import {Component, ViewEncapsulation} from '@angular/core';
import {FormGroup, AbstractControl, FormBuilder, Validators} from '@angular/forms';

import {Auth} from '../services/auth';
import {User} from '../services/user';
import {Config} from '../config/config'
import {Router} from '@angular/router';

@Component({
  selector: 'login',
  encapsulation: ViewEncapsulation.None,
  styles: [require('./login.scss')],
  template: require('./login.html'),
  providers:[Auth,User,Config]
})
export class Login {

  public form:FormGroup;
  public email:AbstractControl;
  public password:AbstractControl;
  public submitted:boolean = false;

  constructor(fb:FormBuilder,private _auth:Auth,private _user:User,private _router: Router) {
    //Added to check
    if (this._auth.getToken()) {
			this._auth.getAuthUserFromServer()
				.then(() => this._router.navigate(['SalesBuddy', 'Account']))
				.catch(() => this.submitted = false);
				} else {
			this.submitted = false;
		}

    this.form = fb.group({
      'email': ['', Validators.compose([Validators.required, Validators.minLength(4)])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(4)])]
    });

    this.email = this.form.controls['email'];
    this.password = this.form.controls['password'];
  }

  public onSubmit(values:Object):void {
    this.submitted = true;
    if (this.form.valid) {
          this.login();
          //console.log(values);
    }
  }


  login() {
		this._auth.login(this.email.value, this.password.value)
			.subscribe(
			data => this.loginSuccess(data),
			err => this.loginFailed(err)
			);
	}
	loginSuccess(data: any) {
		var response = data.json();
		this._auth.setToken(response.token);
		if (response.profile.role === this._user.ADMIN_ROLE) {
			this._auth.setAuthUser(response.profile);
			this._router.navigate(['SalesBuddy', 'Account']);
		} else {
			this._router.navigate(['SalesBuddy', 'Home']);
		}
	}
	loginFailed(error: any) {
		console.error(error);
		//this.error = 'Invalid username or password';
	}
	gotoRegister(e) {
		e.preventDefault();
		this._router.navigate(['Account', 'Register']);
	}
}