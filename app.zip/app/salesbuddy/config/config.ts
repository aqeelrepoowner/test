/*
 * Defing configuration for application
 */
 'use strict';
import {Injectable} from '@angular/core';

@Injectable()
export class Config {
	apiUrl: string = 'http://172.27.141.144:9000/';
	tokenName: string = 'access_token';
	paging: Number = 5;
	resourceUrl: Object = {
		'account':'api/accounts',
		'contact':'api/contacts',
		'opportunity':'api/opportunities',
		'product':'api/products'
	}
}
