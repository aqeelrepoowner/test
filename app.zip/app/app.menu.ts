import { PAGES_MENU } from './salesbuddy/pages.menu';

export const MENU = [
  ...PAGES_MENU
];
