import {Component} from "@angular/core";

@Component({
  selector: 'input-error',
  template: `<span *ngIf="showErrorFlag" class="help-block">
               <ng-content></ng-content>
             </span>
             `
})
export class InputError {

  showErrorFlag:boolean = true;

  hideError():void {
    this.showErrorFlag = false;
  }

  showError():void {
    this.showErrorFlag = true;
  }

}