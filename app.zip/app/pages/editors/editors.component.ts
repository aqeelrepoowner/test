import {Component} from '@angular/core';

@Component({
  selector: 'editors',
  template: `<router-outlet></router-outlet>`
})
export class Editors {
  constructor() {
  }
}
