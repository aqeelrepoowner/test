require('leaflet-map');
require('style-loader!leaflet/dist/leaflet.css');
