import { Component } from '@angular/core';

@Component({
  selector: 'select-inputs',
  styles: [require('./selectInput.scss')],
  template: require('./selectInputs.html')
})
export class SelectInputs {
  constructor() { }
}
