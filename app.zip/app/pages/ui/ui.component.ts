import {Component} from '@angular/core';

@Component({
  selector: 'ui',
  styles: [],
  template: `<router-outlet></router-outlet>`
})
export class Ui {

  constructor() {
  }
}
