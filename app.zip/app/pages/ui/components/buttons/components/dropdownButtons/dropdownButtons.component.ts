import {Component, HostListener} from '@angular/core';

@Component({
  selector: 'dropdown-buttons',
  template: require('./dropdownButtons.html')
})

// TODO: appendToBody does not implemented yet, waiting for it
export class DropdownButtons {

  constructor() {
  }
}
