<?php
	@session_start();
	
	define("HOST",'localhost');
	define("DBNAME",'darul_huda');
	define("DB_USERNAME",'root');
	define("DB_PASSWORD",'');
	define("APP_HOST",$_SERVER['HTTP_HOST']);
	define("SYSPATH","darulhuda");
	
	define("DHSTUD","mst_students");
	define("DHTEACH","mst_teacher");
	define("DHFEES","mst_fees");
	define("DHEXAM","exam_details");
	define("DHCOURSE","mst_course");
	define("DHATTEND","mst_attendance");
	define("DHBUS","bus_expenses");
	define("DHCHARITY","mst_charity_details");
	define("DHMAKTAB","mst_maktab_details");
	define("DHMARKS","subject_marks");
	define("DHSUBJECT","mst_subject");
	
	define("MAKTAB_LOCATION1","Arshiya");
	
	define("MAKTAB_LOCATION2","Ajmera");
	
	define("STARTYEAR", 2010);
	
	define("ENDYEAR",2050);
	
	define("JAN",31);
	define("MAR",31);
	define("FEB",28);
	define("FEB_LEAP",29);
	define("APR",30);
	define("MAY",31);
	define("JUN",30);
	define("JUL",31);
	define("AUG",31);
	define("SEP",30);
	define("OCT",31);
	define("NOV",30);
	define("DEC",31);
	
	define("SITE_URL","http://localhost/darulhuda/");
	
	define("MENU_ICONS",SITE_URL."images/icons/");

?>