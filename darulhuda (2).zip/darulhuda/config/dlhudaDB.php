<?php
	
	include_once("dlhuda_config.php");	

	
 class dlhudaDB extends mysqli
 {
	static	$instance = "";
	
	private $user = DB_USERNAME; 
	private $pass = DB_PASSWORD;
	private $dbName = DBNAME; 
	private $dbHost = HOST;  
	
	public static function getInstance()
	{
		
		if(self::$instance == null)
			self::$instance = new self();	
			
		return self::$instance;	
		
		
	
	}
	
	private function __construct()
	{	
		parent::__construct($this->dbHost,$this->user,$this->pass,$this->dbName);
	
		
		if(mysqli_connect_error())
		{
		  exit('Connect Error(' . mysqli_connect_errno() .') '
		  .mysqli_connect_error());
		}
		parent::set_charset('utf-8');
		
		
	}
	
	public function updateStudent($studentDetails) {
		extract($studentDetails);
		
		$stmt = $this->stmt_init();
			$prepareStmt = $stmt->prepare();
			
			var_dump($prepareStmt);	
			
			/*$stmt->bind_param($firhiast_name,$last_name,$contact_no,$dob,$gender,$middle_name,$address,$maktab_location,
			$school_name,$school_class,$school_medium,$academic_year,$bus_facility,$teacher_name,$maktab_course,$student_id);
			
			$stmt->execute();
			$stmt->close();		
			$stmt->close();	*/	
	}

	
	
 }
	
 
 
 


?>