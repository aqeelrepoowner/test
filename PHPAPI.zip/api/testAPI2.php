<?php

abstract class API
{

  protected $method;
  protected $endpoint;
  protected $origin;
  protected $args = array();
  protected $file;
  protected $apiclass;

    public function __construct($request) 
    {
        header("Access-Control-Allow-Orgin: *");
        header("Access-Control-Allow-Methods: *");
       //header("Content-Type: application/json");
        $this->origin = array_key_exists('HTTP_ORIGIN', $_SERVER) ? $_SERVER['HTTP_ORIGIN'] : $_SERVER['SERVER_NAME'];
        $this->args = explode('/', ltrim($request['request'], '/'));
        array_splice($this->args,0,1);

        $this->apiclass = array_shift($this->args);

        $this->endpoint = array_shift($this->args);

        $this->method = $_SERVER['REQUEST_METHOD'];

        if ($this->method == 'POST' && array_key_exists('HTTP_X_HTTP_METHOD', $_SERVER)) {
            if ($_SERVER['HTTP_X_HTTP_METHOD'] == 'DELETE') {
                $this->method = 'DELETE';
            } else if ($_SERVER['HTTP_X_HTTP_METHOD'] == 'PUT') {
                $this->method = 'PUT';
            } else {
                throw new Exception("Unexpected Header");
            }
        }

        switch($this->method) {
        case 'DELETE':
        case 'POST':
            $this->request = $this->_cleanInputs($_POST);
            break;
        case 'GET':
            $this->request = $this->_cleanInputs($_GET);
            break;
        case 'PUT':
            $this->request = $this->_cleanInputs($_GET);
            $this->file = file_get_contents("php://input");
            break;
        default:
            $this->_response('Invalid Method', 405);
            break;
        }
        return $this;
    }

    public function processAPI() 
    {
         try {
            if ($this instanceof $this->apiclass === false) {
                throw new \Exception("this is not instance of $this->apiclass");
            }
            if (class_exists($this->apiclass) && method_exists($this->apiclass, $this->endpoint)) {
                return $this->_response($this->{$this->endpoint}($this->args));
            }
            return $this->_response("No Endpoint: $this->endpoint in class $this->apiclass Or class $this->apiclass does not exists", 404);
         } catch (Exception $e) {
             echo($e->getMessage());
         }
    }

    private function _response($data, $status = 200) 
    {
        header("HTTP/1.1 " . $status . " " . $this->_requestStatus($status));
        return json_encode($data);
    }

    private function _cleanInputs($data) 
    {
        $clean_input = Array();
        if (is_array($data)) {
            foreach ($data as $k => $v) {
                $clean_input[$k] = $this->_cleanInputs($v);
            }
        } else {
            $clean_input = trim(strip_tags($data));
        }
        return $clean_input;
    }

    private function _requestStatus($code) 
    {
        $status = array(  
            200 => 'OK',
            404 => 'Not Found',   
            405 => 'Method Not Allowed',
            500 => 'Internal Server Error',
        ); 
        return ($status[$code])?$status[$code]:$status[500]; 
    }
    
    private function isOriginAllowed() 
    { 
        if (isset($this->origin)) {
            header("Access-Control-Allow-Origin: " . $this->origin . "");
            return "Origin Not Allowed!";
        }
    }

}

/*
class users extends API
{
   public function edit($args = null)
   {
      return "user success";
   }

}*/

class course extends API
{
   public function edit($args = null)
   {
      return "course success";
   }

}


class APIhandler 
{
     protected $api;
     public static function processAPI(API $api)
     {
         echo $api->processAPI();
     }
}

echo "<pre>";
$_REQUEST['request'] = $_SERVER['REQUEST_URI']; 