import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Article } from './article';
import { ArticleService } from './article.service';

@Component({
  moduleId: module.id,
  selector: 'my-articles',
  templateUrl: './article.component.html',
  styleUrls: [ './heroes.component.css' ]
})

export class ArticleComponent implements OnInit {
  articles: Article[];
  selectedArticle: Article;

  constructor(
    private router: Router,
    private articleService: ArticleService) {
        
  }
  
  getArticles(): void {
    this.articleService.getArticles().then(Articles => this.articles = Articles);
    
  }

  ngOnInit(): void {
    this.getArticles();
  }

  onSelect(article: Article): void {
    this.selectedArticle = article;
  }

  gotoDetail(): void {
    this.router.navigate(['/article', this.selectedArticle.id]);
  }
}

/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/