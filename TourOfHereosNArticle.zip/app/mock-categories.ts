import { Category } from './category';

export var CATEGORIES: Category[] = [
    {id:1, name:'PHP Session'},
    {id:2, name:'PHP Cookies'}
    ];