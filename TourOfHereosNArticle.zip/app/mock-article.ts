import { Article } from './category';

export var ARTICLES: Article[] = [
    {
        id:1, 
        name:'PHP Session Security', 
        description:'Since PHP 5.5.2, session.use_strict_mode is available. When it is enabled and session save handler supports it, uninitialized session ID is rejected and new session ID is created. This protects attack that forces users to use known session ID. Attacker may paste links or send mail that contains session ID. e.g. http://example.com/page.php?PHPSESSID=123456789 If session.use_trans_sid is enabled, victim will start session using attacker provided session ID. session.use_strict_mode mitigates the risk.',
        category_id:1
    },
    {
         id:2, 
         name:'PHP Cookies',
         description:'PHP cookies description',
         category_id:2
    }
    ];