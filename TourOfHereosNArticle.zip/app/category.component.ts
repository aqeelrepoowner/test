import { Component, OnInit } from '@angular/core';
import { Category } from './category';
import { CategoryService } from './category.service';


@Component({
  moduleId: module.id,
  selector: 'my-category',
  templateUrl: './category.component.html',
  styleUrls: ['./heroes.component.css'],
})

export class CategoryComponent implements OnInit {
  title = 'Categories';
  categories: Category[];
  selectedCategory: Category;
  
  constructor(private categoryService: CategoryService) {}
  
  getCategories():void
  {
    this.categoryService.getCategories().then(categories => this.categories = categories);
  }
  
  onSelect(categoryObj) {
      
      this.selectedCategory = categoryObj;
      //this.categoryService.getCategory().then(selectedCategory => this.selectedCategory = categoryObj);
  }
  
  goToDetail(id) {
      this.categoryService.getCategory(id);
  }
  
  ngOnInit(): void {
   this.getCategories();
  }

}


/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/