export class Article {
  id: number;
  name: string;
  description: string;
  category_id: number;
}