import { Article } from './article';
import { ARTICLES } from './mock-article';
import { Injectable } from '@angular/core';
import { CategoryService } from './category.service';

@Injectable()
export class ArticleService {
    
  constructor(private categoryService: CategoryService)
  {
      
  }
  getArticles(): Promise<Article[]> {
    return Promise.resolve(ARTICLES);
  }

  getArticlesSlowly(): Promise<Article[]> {
    return new Promise(resolve => {
      // Simulate server latency with 2 second delay
      setTimeout(() => resolve(this.getArticles()), 2000);
    });
  }

  getArticle(id: number): Promise<Article> {
    return this.getArticles()
               .then(Articles => Articles.find(Article => Article.id === id));
  }
 
}


/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/