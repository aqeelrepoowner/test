import { Category } from './category';
import { CATEGORIES } from './mock-categories';
import { Injectable } from '@angular/core';

@Injectable()
export class CategoryService {
  getCategories(): Promise<Category[]> {
    return Promise.resolve(CATEGORIES);
  }

  getCategoriesSlowly(): Promise<category[]> {
    return new Promise(resolve => {
      // Simulate server latency with 2 second delay
      setTimeout(() => resolve(this.getCategories()), 2000);
    });
  }

  getCategory(id: number): Promise<category> {
    return this.getCategories()
               .then(categories => categories.find(category => category.id === id));
  }
}


/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/